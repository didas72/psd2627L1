----------------------------------------------------------------------------------
-- Company:
-- Engineer:
--
-- Create Date: 09/13/2016 07:01:44 PM
-- Design Name:
-- Module Name: interface - Behavioral
-- Project Name:
-- Target Devices:
-- Tool Versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;


-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity interface is
  port (
    clk : in  std_logic;  -- 100MHz clock
    btnC, btnU, btnL, btnR, btnD : in  std_logic;  -- buttons
    sw  : in  std_logic_vector(15 downto 0);  -- switches
    led : out std_logic_vector(15 downto 0);  -- leds
    an  : out std_logic_vector(3 downto 0);  -- display selectors
    seg : out std_logic_vector(6 downto 0);  -- display 7-segments
    dp  : out std_logic   -- display point
    );
end interface;

architecture Behavioral of interface is
  -- signal dd3, dd2, dd1, dd0 : std_logic_vector(6 downto 0);
  signal RESULT, REG1                                : std_logic_vector(14 downto 0);
  signal overflow_flag                               : std_logic;
  signal dact                                        : std_logic_vector(3 downto 0);
  -- signal btnRinstr : std_logic_vector(3 downto 0);
  -- signal clk10hz, clk_disp : std_logic;
  signal btn, btnDeBnc                               : std_logic_vector(4 downto 0);
  -- registered input buttons
  signal btnCreg, btnUreg, btnLreg, btnRreg          : std_logic;
  -- registered input switches
  signal sw_reg                                      : std_logic_vector(15 downto 0);
  -- signal to light the decimal point of the display when the circuit overflows
  signal dp_overflow                                 : std_logic;

  -- signal to inform the control unit that an operation button was pressed
  signal oper_avail                                  : std_logic;
  signal OPER                                        : std_logic_vector(1 downto 0);
  signal digit3_aux                                  : std_logic_vector(3 downto 0);
  signal OPER_AUX                                    : std_logic_vector(1 downto 0);
  -- signal to detect the press of the button
  signal btnLreg_prev, btnUreg_prev, btnRreg_prev, btnCreg_prev     : std_logic;
  
  component disp7
    port (
      digit3, digit2, digit1, digit0 : in  std_logic_vector(3 downto 0);
      dp3, dp2, dp1, dp0             : in  std_logic;
      clk                            : in  std_logic;
      dactive                        : in  std_logic_vector(3 downto 0);
      en_disp_l                      : out std_logic_vector(3 downto 0);
      segm_l                         : out std_logic_vector(6 downto 0);
      dp_l                           : out std_logic);
  end component;

  component debouncer
    generic (
      DEBNC_CLOCKS : integer;
      PORT_WIDTH   : integer);
    port (
      signal_i : in  std_logic_vector(4 downto 0);
      clk_i    : in  std_logic;
      signal_o : out std_logic_vector(4 downto 0));
  end component;

  component circuito
    port(
      clk             : in  std_logic;
      rst             : in  std_logic;
      equals          : in  std_logic;
      oper_avail      : in  std_logic;
      OPER            : in  std_logic_vector(1 downto 0);
      VALUE           : in  std_logic_vector(14 downto 0);
      overflow_flag   : out  std_logic;
      RESULT          : out std_logic_vector(14 downto 0)
      );
  end component;

begin
  led <= sw_reg;

  dact <= "1111";

  inst_disp7 : disp7 port map(
    digit3    => digit3_aux,
    digit2    => RESULT(11 downto 8 ),
    digit1    => RESULT(7  downto 4 ),
    digit0    => RESULT(3  downto 0 ),
    dp3       => dp_overflow, 
    dp2       => dp_overflow, 
    dp1       => dp_overflow, 
    dp0       => dp_overflow,
    clk       => clk,
    dactive   => dact,
    en_disp_l => an,
    segm_l    => seg,
    dp_l      => dp);

  inst_circuito : circuito port map(
    clk           => clk,
    rst           => btnCreg,
    equals        => btnRreg,
    oper_avail    => oper_avail,
    OPER          => OPER_AUX,
    VALUE         => sw_reg(14 downto 0),
    RESULT        => RESULT,
    overflow_flag => overflow_flag
    );

  -- Debounces btn signals
  btn <= btnC & btnU & btnL & btnR & btnD;
  Inst_btn_debounce : debouncer
    generic map (
      DEBNC_CLOCKS => (2**20),
      PORT_WIDTH   => 5)
    port map (
      signal_i => btn,
      clk_i    => clk,
      signal_o => btnDeBnc);


  digit3_aux <= "0" & RESULT(14 downto 12);


  process (clk)
  begin
    if rising_edge(clk) then
      btnCreg <= btnDeBnc(4);
      btnUreg <= btnDeBnc(3);
      btnLreg <= btnDeBnc(2);
      btnRreg <= btnDeBnc(1);
      sw_reg  <= sw;
      
      btnLreg_prev <= btnLreg;
      btnUreg_prev <= btnUreg;
      btnRreg_prev <= btnRreg;
      btnCreg_prev <= btnCreg;

      
      if (btnRreg = '1' and btnRreg_prev = '0') then
        dp_overflow <= overflow_flag;
      end if;
      
      if (btnCreg = '1' and btnCreg_prev = '0') then
        dp_overflow <= '0';
      end if;
      
        if (btnLreg = '1' and btnLreg_prev = '0') then
            OPER_AUX   <= sw_reg(15) & "0";
            dp_overflow <= '0';
            oper_avail <= '1';
        elsif (btnUreg = '1' and btnUreg_prev = '0') then
            dp_overflow <= '0';
            OPER_AUX   <= sw_reg(15) & "1";
            oper_avail <= '1';
        else 
            oper_avail <= '0';
        end if;
        


    end if;
  end process;

end Behavioral;
