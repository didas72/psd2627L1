-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (lin64) Build 6299465 Fri Nov 14 12:34:56 MST 2025
-- Date        : Mon Nov  2 17:10:59 2026
-- Host        : fedora running 64-bit Fedora Linux 44 (KDE Plasma Desktop Edition)
-- Command     : write_vhdl -mode funcsim -nolib -force -file
--               /home/garcia/Desktop/faculdade/PSD/psd2627L1/lab2/lab2/lab2.sim/sim_1/impl/func/xsim/circuito_tb_func_impl.vhd
-- Design      : circuito
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity control_unit is
  port (
    Q : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \reg_output_addr_reg[3]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \reg_weight_addr_reg[7]_0\ : out STD_LOGIC_VECTOR ( 7 downto 0 );
    \reg_input_addr_reg[3]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    SR : out STD_LOGIC_VECTOR ( 0 to 0 );
    WEA : out STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_onehot_state_reg[1]_0\ : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_onehot_state_reg[2]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    rst_IBUF : in STD_LOGIC;
    CLK : in STD_LOGIC;
    pwropt : out STD_LOGIC
  );
end control_unit;

architecture STRUCTURE of control_unit is
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[0]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[4]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[0]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[2]\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal plusOp : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \plusOp__0\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal reg_input_addr : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \reg_input_addr[0]_i_1_n_0\ : STD_LOGIC;
  signal \reg_input_addr[1]_i_1_n_0\ : STD_LOGIC;
  signal \reg_input_addr[2]_i_1_n_0\ : STD_LOGIC;
  signal \reg_input_addr[3]_i_2_n_0\ : STD_LOGIC;
  signal \^reg_input_addr_reg[3]_0\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal reg_output_addr : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \reg_output_addr[2]_i_1_n_0\ : STD_LOGIC;
  signal \^reg_output_addr_reg[3]_0\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \reg_weight_addr[7]_i_2_n_0\ : STD_LOGIC;
  signal \^reg_weight_addr_reg[7]_0\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "s_l2_1:00010,s_l2_2:00100,s_l1_0:01000,s_done:10000,s_l2_0:00001";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "s_l2_1:00010,s_l2_2:00100,s_l1_0:01000,s_done:10000,s_l2_0:00001";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "s_l2_1:00010,s_l2_2:00100,s_l1_0:01000,s_done:10000,s_l2_0:00001";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[3]\ : label is "s_l2_1:00010,s_l2_2:00100,s_l1_0:01000,s_done:10000,s_l2_0:00001";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[4]\ : label is "s_l2_1:00010,s_l2_2:00100,s_l1_0:01000,s_done:10000,s_l2_0:00001";
  attribute \PinAttr:I2:HOLD_DETOUR\ : integer;
  attribute \PinAttr:I2:HOLD_DETOUR\ of \reg_input_addr[1]_i_1\ : label is 193;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \reg_input_addr[1]_i_1\ : label is "soft_lutpair3";
  attribute \PinAttr:I3:HOLD_DETOUR\ : integer;
  attribute \PinAttr:I3:HOLD_DETOUR\ of \reg_input_addr[2]_i_1\ : label is 193;
  attribute SOFT_HLUTNM of \reg_input_addr[2]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \reg_output_addr[2]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_output_addr[3]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_weight_addr[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \reg_weight_addr[2]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \reg_weight_addr[3]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_weight_addr[4]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_weight_addr[6]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_weight_addr[7]_i_1\ : label is "soft_lutpair4";
begin
  Q(1 downto 0) <= \^q\(1 downto 0);
  pwropt <= reg_input_addr(0);
  \reg_input_addr_reg[3]_0\(3 downto 0) <= \^reg_input_addr_reg[3]_0\(3 downto 0);
  \reg_output_addr_reg[3]_0\(3 downto 0) <= \^reg_output_addr_reg[3]_0\(3 downto 0);
  \reg_weight_addr_reg[7]_0\(7 downto 0) <= \^reg_weight_addr_reg[7]_0\(7 downto 0);
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F8FFFFFF88888888"
    )
        port map (
      I0 => \FSM_onehot_state[0]_i_2_n_0\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      I2 => \FSM_onehot_state[0]_i_3_n_0\,
      I3 => \^reg_output_addr_reg[3]_0\(2),
      I4 => \^reg_output_addr_reg[3]_0\(3),
      I5 => reg_output_addr(0),
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[0]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \^reg_input_addr_reg[3]_0\(1),
      I1 => \^reg_input_addr_reg[3]_0\(0),
      I2 => \^reg_input_addr_reg[3]_0\(2),
      I3 => \^reg_input_addr_reg[3]_0\(3),
      O => \FSM_onehot_state[0]_i_2_n_0\
    );
\FSM_onehot_state[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \^reg_output_addr_reg[3]_0\(0),
      I1 => \^reg_output_addr_reg[3]_0\(1),
      O => \FSM_onehot_state[0]_i_3_n_0\
    );
\FSM_onehot_state[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000002"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[2]\,
      I1 => \^reg_input_addr_reg[3]_0\(3),
      I2 => \^reg_input_addr_reg[3]_0\(2),
      I3 => \^reg_input_addr_reg[3]_0\(0),
      I4 => \^reg_input_addr_reg[3]_0\(1),
      O => \FSM_onehot_state[3]_i_1_n_0\
    );
\FSM_onehot_state[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^reg_output_addr_reg[3]_0\(1),
      I2 => \^reg_output_addr_reg[3]_0\(0),
      I3 => \^reg_output_addr_reg[3]_0\(2),
      I4 => \^reg_output_addr_reg[3]_0\(3),
      I5 => reg_output_addr(0),
      O => \FSM_onehot_state[4]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \FSM_onehot_state_reg_n_0_[0]\,
      S => rst_IBUF
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \FSM_onehot_state_reg_n_0_[0]\,
      Q => \^q\(0),
      R => rst_IBUF
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \^q\(0),
      Q => \FSM_onehot_state_reg_n_0_[2]\,
      R => rst_IBUF
    );
\FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \FSM_onehot_state[3]_i_1_n_0\,
      Q => reg_output_addr(0),
      R => rst_IBUF
    );
\FSM_onehot_state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \FSM_onehot_state[4]_i_1_n_0\,
      Q => \^q\(1),
      R => rst_IBUF
    );
\MUL1_OUT__0_carry_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(0),
      I1 => rst_IBUF,
      O => \FSM_onehot_state_reg[1]_0\
    );
\REG1[15]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^q\(0),
      I1 => \FSM_onehot_state_reg_n_0_[0]\,
      O => E(0)
    );
\REG_ACCUM[21]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => reg_output_addr(0),
      I1 => rst_IBUF,
      O => SR(0)
    );
\REG_ACCUM[21]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[2]\,
      I1 => \^q\(0),
      O => \FSM_onehot_state_reg[2]_0\(0)
    );
\reg_input_addr[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^reg_input_addr_reg[3]_0\(0),
      O => \reg_input_addr[0]_i_1_n_0\
    );
\reg_input_addr[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^reg_input_addr_reg[3]_0\(1),
      I2 => \^reg_input_addr_reg[3]_0\(0),
      O => \reg_input_addr[1]_i_1_n_0\
    );
\reg_input_addr[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2888"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^reg_input_addr_reg[3]_0\(2),
      I2 => \^reg_input_addr_reg[3]_0\(1),
      I3 => \^reg_input_addr_reg[3]_0\(0),
      O => \reg_input_addr[2]_i_1_n_0\
    );
\reg_input_addr[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^q\(0),
      I1 => reg_output_addr(0),
      O => reg_input_addr(0)
    );
\reg_input_addr[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"28888888"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^reg_input_addr_reg[3]_0\(3),
      I2 => \^reg_input_addr_reg[3]_0\(2),
      I3 => \^reg_input_addr_reg[3]_0\(0),
      I4 => \^reg_input_addr_reg[3]_0\(1),
      O => \reg_input_addr[3]_i_2_n_0\
    );
\reg_input_addr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_input_addr(0),
      D => \reg_input_addr[0]_i_1_n_0\,
      Q => \^reg_input_addr_reg[3]_0\(0),
      R => rst_IBUF
    );
\reg_input_addr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_input_addr(0),
      D => \reg_input_addr[1]_i_1_n_0\,
      Q => \^reg_input_addr_reg[3]_0\(1),
      R => rst_IBUF
    );
\reg_input_addr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_input_addr(0),
      D => \reg_input_addr[2]_i_1_n_0\,
      Q => \^reg_input_addr_reg[3]_0\(2),
      R => rst_IBUF
    );
\reg_input_addr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_input_addr(0),
      D => \reg_input_addr[3]_i_2_n_0\,
      Q => \^reg_input_addr_reg[3]_0\(3),
      R => rst_IBUF
    );
\reg_output_addr[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^reg_output_addr_reg[3]_0\(0),
      O => plusOp(0)
    );
\reg_output_addr[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^reg_output_addr_reg[3]_0\(0),
      I1 => \^reg_output_addr_reg[3]_0\(1),
      O => plusOp(1)
    );
\reg_output_addr[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \^reg_output_addr_reg[3]_0\(1),
      I1 => \^reg_output_addr_reg[3]_0\(0),
      I2 => \^reg_output_addr_reg[3]_0\(2),
      O => \reg_output_addr[2]_i_1_n_0\
    );
\reg_output_addr[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \^reg_output_addr_reg[3]_0\(0),
      I1 => \^reg_output_addr_reg[3]_0\(1),
      I2 => \^reg_output_addr_reg[3]_0\(2),
      I3 => \^reg_output_addr_reg[3]_0\(3),
      O => plusOp(3)
    );
\reg_output_addr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_output_addr(0),
      D => plusOp(0),
      Q => \^reg_output_addr_reg[3]_0\(0),
      R => rst_IBUF
    );
\reg_output_addr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_output_addr(0),
      D => plusOp(1),
      Q => \^reg_output_addr_reg[3]_0\(1),
      R => rst_IBUF
    );
\reg_output_addr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_output_addr(0),
      D => \reg_output_addr[2]_i_1_n_0\,
      Q => \^reg_output_addr_reg[3]_0\(2),
      R => rst_IBUF
    );
\reg_output_addr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => reg_output_addr(0),
      D => plusOp(3),
      Q => \^reg_output_addr_reg[3]_0\(3),
      R => rst_IBUF
    );
\reg_weight_addr[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(0),
      O => \plusOp__0\(0)
    );
\reg_weight_addr[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(0),
      I1 => \^reg_weight_addr_reg[7]_0\(1),
      O => \plusOp__0\(1)
    );
\reg_weight_addr[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(0),
      I1 => \^reg_weight_addr_reg[7]_0\(1),
      I2 => \^reg_weight_addr_reg[7]_0\(2),
      O => \plusOp__0\(2)
    );
\reg_weight_addr[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(1),
      I1 => \^reg_weight_addr_reg[7]_0\(0),
      I2 => \^reg_weight_addr_reg[7]_0\(2),
      I3 => \^reg_weight_addr_reg[7]_0\(3),
      O => \plusOp__0\(3)
    );
\reg_weight_addr[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(2),
      I1 => \^reg_weight_addr_reg[7]_0\(0),
      I2 => \^reg_weight_addr_reg[7]_0\(1),
      I3 => \^reg_weight_addr_reg[7]_0\(3),
      I4 => \^reg_weight_addr_reg[7]_0\(4),
      O => \plusOp__0\(4)
    );
\reg_weight_addr[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(3),
      I1 => \^reg_weight_addr_reg[7]_0\(1),
      I2 => \^reg_weight_addr_reg[7]_0\(0),
      I3 => \^reg_weight_addr_reg[7]_0\(2),
      I4 => \^reg_weight_addr_reg[7]_0\(4),
      I5 => \^reg_weight_addr_reg[7]_0\(5),
      O => \plusOp__0\(5)
    );
\reg_weight_addr[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \reg_weight_addr[7]_i_2_n_0\,
      I1 => \^reg_weight_addr_reg[7]_0\(6),
      O => \plusOp__0\(6)
    );
\reg_weight_addr[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \reg_weight_addr[7]_i_2_n_0\,
      I1 => \^reg_weight_addr_reg[7]_0\(6),
      I2 => \^reg_weight_addr_reg[7]_0\(7),
      O => \plusOp__0\(7)
    );
\reg_weight_addr[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => \^reg_weight_addr_reg[7]_0\(5),
      I1 => \^reg_weight_addr_reg[7]_0\(3),
      I2 => \^reg_weight_addr_reg[7]_0\(1),
      I3 => \^reg_weight_addr_reg[7]_0\(0),
      I4 => \^reg_weight_addr_reg[7]_0\(2),
      I5 => \^reg_weight_addr_reg[7]_0\(4),
      O => \reg_weight_addr[7]_i_2_n_0\
    );
\reg_weight_addr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(0),
      Q => \^reg_weight_addr_reg[7]_0\(0),
      R => rst_IBUF
    );
\reg_weight_addr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(1),
      Q => \^reg_weight_addr_reg[7]_0\(1),
      R => rst_IBUF
    );
\reg_weight_addr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(2),
      Q => \^reg_weight_addr_reg[7]_0\(2),
      R => rst_IBUF
    );
\reg_weight_addr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(3),
      Q => \^reg_weight_addr_reg[7]_0\(3),
      R => rst_IBUF
    );
\reg_weight_addr_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(4),
      Q => \^reg_weight_addr_reg[7]_0\(4),
      R => rst_IBUF
    );
\reg_weight_addr_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(5),
      Q => \^reg_weight_addr_reg[7]_0\(5),
      R => rst_IBUF
    );
\reg_weight_addr_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(6),
      Q => \^reg_weight_addr_reg[7]_0\(6),
      R => rst_IBUF
    );
\reg_weight_addr_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \^q\(0),
      D => \plusOp__0\(7),
      Q => \^reg_weight_addr_reg[7]_0\(7),
      R => rst_IBUF
    );
we_OBUF_inst_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => reg_output_addr(0),
      I1 => rst_IBUF,
      O => WEA(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity datapath is
  port (
    CO : out STD_LOGIC_VECTOR ( 0 to 0 );
    O : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_1\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_2\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_3\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_4\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    DIADI : out STD_LOGIC_VECTOR ( 20 downto 0 );
    DI : in STD_LOGIC_VECTOR ( 2 downto 0 );
    S : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry_i_8_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry_i_8_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry__0_i_3_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL1_OUT__85_carry__0_i_3_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG1_reg[3]_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \REG1_reg[3]_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry__0_i_4_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry__0_i_4_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry__1_i_5\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL1_OUT__85_carry__1_i_5_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL1_OUT__85_carry_i_1_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \MUL1_OUT__85_carry_i_1_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry__0_i_6_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL1_OUT__85_carry__0_i_6_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \REG1_reg[15]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG1_reg[15]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG1_reg[15]_2\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG1_reg[15]_3\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \REG2_reg[2]_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \REG2_reg[2]_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry_i_8_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry_i_8_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry__0_i_3_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL2_OUT__85_carry__0_i_3_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG2_reg[3]_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \REG2_reg[3]_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry__0_i_4_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry__0_i_4_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry__1_i_5\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL2_OUT__85_carry__1_i_5_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL2_OUT__85_carry_i_1_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \MUL2_OUT__85_carry_i_1_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry__0_i_6_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \MUL2_OUT__85_carry__0_i_6_1\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \REG2_reg[15]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG2_reg[15]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG2_reg[15]_2\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG2_reg[15]_3\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    rst_IBUF : in STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    CLK : in STD_LOGIC;
    SR : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG_ACCUM_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
end datapath;

architecture STRUCTURE of datapath is
  signal ADD_OUT : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \ADD_OUT_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__0_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__1_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \ADD_OUT_carry__2_n_0\ : STD_LOGIC;
  signal ADD_OUT_carry_i_1_n_0 : STD_LOGIC;
  signal ADD_OUT_carry_i_2_n_0 : STD_LOGIC;
  signal ADD_OUT_carry_i_3_n_0 : STD_LOGIC;
  signal ADD_OUT_carry_i_4_n_0 : STD_LOGIC;
  signal ADD_OUT_carry_n_0 : STD_LOGIC;
  signal \ADD_OUT_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \ADD_OUT_inferred__0/i__carry__1_n_0\ : STD_LOGIC;
  signal \ADD_OUT_inferred__0/i__carry__2_n_0\ : STD_LOGIC;
  signal \ADD_OUT_inferred__0/i__carry__3_n_0\ : STD_LOGIC;
  signal \ADD_OUT_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal MUL1_OUT : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \MUL1_OUT__0_carry__0_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_n_4\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_n_5\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_n_6\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_n_7\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__1_n_1\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__1_n_6\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__1_n_7\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry_n_4\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_n_4\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_n_5\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_n_6\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_n_7\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry_n_4\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry_n_5\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry_n_6\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry_n_7\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry__0_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry__0_n_7\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry__1_n_6\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry_n_4\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry_n_5\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry_n_6\ : STD_LOGIC;
  signal \MUL1_OUT__59_carry_n_7\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry__0_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_1_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_2_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_3_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_4_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_5_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_6_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_7_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_i_8_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__85_carry_n_0\ : STD_LOGIC;
  signal MUL2_OUT : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \MUL2_OUT__0_carry__0_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_n_4\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_n_5\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_n_6\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_n_7\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__1_n_1\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__1_n_6\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__1_n_7\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry_n_4\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_n_4\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_n_5\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_n_6\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_n_7\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry_n_4\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry_n_5\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry_n_6\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry_n_7\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry__0_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry__0_n_7\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry__1_n_6\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry_n_4\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry_n_5\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry_n_6\ : STD_LOGIC;
  signal \MUL2_OUT__59_carry_n_7\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry__0_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_1_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_2_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_3_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_4_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_5_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_6_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_7_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_i_8_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__85_carry_n_0\ : STD_LOGIC;
  signal \^o\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal PCIN : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal REG1 : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal REG2 : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \REG_ACCUM_reg_n_0_[0]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[10]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[11]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[12]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[13]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[14]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[15]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[16]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[17]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[18]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[19]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[1]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[20]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[21]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[2]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[3]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[4]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[5]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[6]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[7]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[8]\ : STD_LOGIC;
  signal \REG_ACCUM_reg_n_0_[9]\ : STD_LOGIC;
  signal \i__carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__3_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__3_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__3_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__3_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__3_i_5_n_3\ : STD_LOGIC;
  signal \i__carry__4_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__4_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_0\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_2\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_3\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_4\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_ADD_OUT_carry_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ADD_OUT_inferred__0/i__carry__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL1_OUT__0_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__0_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__0_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL1_OUT__0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL1_OUT__30_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__30_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__30_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL1_OUT__30_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL1_OUT__59_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__59_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__59_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL1_OUT__59_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL1_OUT__85_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__85_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL1_OUT__85_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL2_OUT__0_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__0_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__0_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL2_OUT__0_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL2_OUT__30_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__30_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__30_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL2_OUT__30_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL2_OUT__59_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__59_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__59_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_MUL2_OUT__59_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_MUL2_OUT__85_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__85_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_MUL2_OUT__85_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_i__carry__3_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_i__carry__3_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \ADD_OUT_inferred__0/i__carry\ : label is 35;
  attribute ADDER_THRESHOLD of \ADD_OUT_inferred__0/i__carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \ADD_OUT_inferred__0/i__carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \ADD_OUT_inferred__0/i__carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \ADD_OUT_inferred__0/i__carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \ADD_OUT_inferred__0/i__carry__4\ : label is 35;
  attribute OPT_MODIFIED : string;
  attribute OPT_MODIFIED of \MUL1_OUT__0_carry\ : label is "PROPCONST";
  attribute OPT_MODIFIED of \MUL1_OUT__30_carry\ : label is "PROPCONST";
  attribute OPT_MODIFIED of \MUL1_OUT__59_carry\ : label is "PROPCONST";
  attribute ADDER_THRESHOLD of \MUL1_OUT__85_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \MUL1_OUT__85_carry__0\ : label is 35;
  attribute HLUTNM : string;
  attribute HLUTNM of \MUL1_OUT__85_carry__0_i_2\ : label is "lutpair3";
  attribute HLUTNM of \MUL1_OUT__85_carry__0_i_3\ : label is "lutpair2";
  attribute HLUTNM of \MUL1_OUT__85_carry__0_i_4\ : label is "lutpair1";
  attribute HLUTNM of \MUL1_OUT__85_carry__0_i_7\ : label is "lutpair3";
  attribute HLUTNM of \MUL1_OUT__85_carry__0_i_8\ : label is "lutpair2";
  attribute ADDER_THRESHOLD of \MUL1_OUT__85_carry__1\ : label is 35;
  attribute HLUTNM of \MUL1_OUT__85_carry_i_1\ : label is "lutpair0";
  attribute HLUTNM of \MUL1_OUT__85_carry_i_2\ : label is "lutpair8";
  attribute HLUTNM of \MUL1_OUT__85_carry_i_5\ : label is "lutpair1";
  attribute HLUTNM of \MUL1_OUT__85_carry_i_6\ : label is "lutpair0";
  attribute HLUTNM of \MUL1_OUT__85_carry_i_7\ : label is "lutpair8";
  attribute OPT_MODIFIED of \MUL2_OUT__0_carry\ : label is "PROPCONST";
  attribute OPT_MODIFIED of \MUL2_OUT__30_carry\ : label is "PROPCONST";
  attribute OPT_MODIFIED of \MUL2_OUT__59_carry\ : label is "PROPCONST";
  attribute ADDER_THRESHOLD of \MUL2_OUT__85_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \MUL2_OUT__85_carry__0\ : label is 35;
  attribute HLUTNM of \MUL2_OUT__85_carry__0_i_2\ : label is "lutpair7";
  attribute HLUTNM of \MUL2_OUT__85_carry__0_i_3\ : label is "lutpair6";
  attribute HLUTNM of \MUL2_OUT__85_carry__0_i_4\ : label is "lutpair5";
  attribute HLUTNM of \MUL2_OUT__85_carry__0_i_7\ : label is "lutpair7";
  attribute HLUTNM of \MUL2_OUT__85_carry__0_i_8\ : label is "lutpair6";
  attribute ADDER_THRESHOLD of \MUL2_OUT__85_carry__1\ : label is 35;
  attribute HLUTNM of \MUL2_OUT__85_carry_i_1\ : label is "lutpair4";
  attribute HLUTNM of \MUL2_OUT__85_carry_i_2\ : label is "lutpair9";
  attribute HLUTNM of \MUL2_OUT__85_carry_i_5\ : label is "lutpair5";
  attribute HLUTNM of \MUL2_OUT__85_carry_i_6\ : label is "lutpair4";
  attribute HLUTNM of \MUL2_OUT__85_carry_i_7\ : label is "lutpair9";
begin
  O(1 downto 0) <= \^o\(1 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl\(2 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl\(2 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_0\(0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_2\(1 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_2\(1 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_3\(2 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_3\(2 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(0);
ADD_OUT_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => ADD_OUT_carry_n_0,
      CO(2 downto 0) => NLW_ADD_OUT_carry_CO_UNCONNECTED(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => REG2(3 downto 0),
      O(3 downto 0) => PCIN(3 downto 0),
      S(3) => ADD_OUT_carry_i_1_n_0,
      S(2) => ADD_OUT_carry_i_2_n_0,
      S(1) => ADD_OUT_carry_i_3_n_0,
      S(0) => ADD_OUT_carry_i_4_n_0
    );
\ADD_OUT_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => ADD_OUT_carry_n_0,
      CO(3) => \ADD_OUT_carry__0_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => REG2(7 downto 4),
      O(3 downto 0) => PCIN(7 downto 4),
      S(3) => \ADD_OUT_carry__0_i_1_n_0\,
      S(2) => \ADD_OUT_carry__0_i_2_n_0\,
      S(1) => \ADD_OUT_carry__0_i_3_n_0\,
      S(0) => \ADD_OUT_carry__0_i_4_n_0\
    );
\ADD_OUT_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(7),
      I1 => REG1(7),
      O => \ADD_OUT_carry__0_i_1_n_0\
    );
\ADD_OUT_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(6),
      I1 => REG1(6),
      O => \ADD_OUT_carry__0_i_2_n_0\
    );
\ADD_OUT_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(5),
      I1 => REG1(5),
      O => \ADD_OUT_carry__0_i_3_n_0\
    );
\ADD_OUT_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(4),
      I1 => REG1(4),
      O => \ADD_OUT_carry__0_i_4_n_0\
    );
\ADD_OUT_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_carry__0_n_0\,
      CO(3) => \ADD_OUT_carry__1_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_carry__1_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => REG2(11 downto 8),
      O(3 downto 0) => PCIN(11 downto 8),
      S(3) => \ADD_OUT_carry__1_i_1_n_0\,
      S(2) => \ADD_OUT_carry__1_i_2_n_0\,
      S(1) => \ADD_OUT_carry__1_i_3_n_0\,
      S(0) => \ADD_OUT_carry__1_i_4_n_0\
    );
\ADD_OUT_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(11),
      I1 => REG1(11),
      O => \ADD_OUT_carry__1_i_1_n_0\
    );
\ADD_OUT_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(10),
      I1 => REG1(10),
      O => \ADD_OUT_carry__1_i_2_n_0\
    );
\ADD_OUT_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(9),
      I1 => REG1(9),
      O => \ADD_OUT_carry__1_i_3_n_0\
    );
\ADD_OUT_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(8),
      I1 => REG1(8),
      O => \ADD_OUT_carry__1_i_4_n_0\
    );
\ADD_OUT_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_carry__1_n_0\,
      CO(3) => \ADD_OUT_carry__2_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_carry__2_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \ADD_OUT_carry__2_i_1_n_0\,
      DI(2 downto 0) => REG2(14 downto 12),
      O(3 downto 0) => PCIN(15 downto 12),
      S(3) => \ADD_OUT_carry__2_i_2_n_0\,
      S(2) => \ADD_OUT_carry__2_i_3_n_0\,
      S(1) => \ADD_OUT_carry__2_i_4_n_0\,
      S(0) => \ADD_OUT_carry__2_i_5_n_0\
    );
\ADD_OUT_carry__2_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => REG2(15),
      O => \ADD_OUT_carry__2_i_1_n_0\
    );
\ADD_OUT_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(15),
      I1 => REG1(15),
      O => \ADD_OUT_carry__2_i_2_n_0\
    );
\ADD_OUT_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(14),
      I1 => REG1(14),
      O => \ADD_OUT_carry__2_i_3_n_0\
    );
\ADD_OUT_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(13),
      I1 => REG1(13),
      O => \ADD_OUT_carry__2_i_4_n_0\
    );
\ADD_OUT_carry__2_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(12),
      I1 => REG1(12),
      O => \ADD_OUT_carry__2_i_5_n_0\
    );
ADD_OUT_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(3),
      I1 => REG1(3),
      O => ADD_OUT_carry_i_1_n_0
    );
ADD_OUT_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(2),
      I1 => REG1(2),
      O => ADD_OUT_carry_i_2_n_0
    );
ADD_OUT_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(1),
      I1 => REG1(1),
      O => ADD_OUT_carry_i_3_n_0
    );
ADD_OUT_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => REG2(0),
      I1 => REG1(0),
      O => ADD_OUT_carry_i_4_n_0
    );
\ADD_OUT_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ADD_OUT_inferred__0/i__carry_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_inferred__0/i__carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \REG_ACCUM_reg_n_0_[3]\,
      DI(2) => \REG_ACCUM_reg_n_0_[2]\,
      DI(1) => \REG_ACCUM_reg_n_0_[1]\,
      DI(0) => \REG_ACCUM_reg_n_0_[0]\,
      O(3 downto 0) => ADD_OUT(3 downto 0),
      S(3) => \i__carry_i_1_n_0\,
      S(2) => \i__carry_i_2_n_0\,
      S(1) => \i__carry_i_3_n_0\,
      S(0) => \i__carry_i_4_n_0\
    );
\ADD_OUT_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_inferred__0/i__carry_n_0\,
      CO(3) => \ADD_OUT_inferred__0/i__carry__0_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_inferred__0/i__carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \REG_ACCUM_reg_n_0_[7]\,
      DI(2) => \REG_ACCUM_reg_n_0_[6]\,
      DI(1) => \REG_ACCUM_reg_n_0_[5]\,
      DI(0) => \REG_ACCUM_reg_n_0_[4]\,
      O(3 downto 0) => ADD_OUT(7 downto 4),
      S(3) => \i__carry__0_i_1_n_0\,
      S(2) => \i__carry__0_i_2_n_0\,
      S(1) => \i__carry__0_i_3_n_0\,
      S(0) => \i__carry__0_i_4_n_0\
    );
\ADD_OUT_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_inferred__0/i__carry__0_n_0\,
      CO(3) => \ADD_OUT_inferred__0/i__carry__1_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_inferred__0/i__carry__1_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \REG_ACCUM_reg_n_0_[11]\,
      DI(2) => \REG_ACCUM_reg_n_0_[10]\,
      DI(1) => \REG_ACCUM_reg_n_0_[9]\,
      DI(0) => \REG_ACCUM_reg_n_0_[8]\,
      O(3 downto 0) => ADD_OUT(11 downto 8),
      S(3) => \i__carry__1_i_1_n_0\,
      S(2) => \i__carry__1_i_2_n_0\,
      S(1) => \i__carry__1_i_3_n_0\,
      S(0) => \i__carry__1_i_4_n_0\
    );
\ADD_OUT_inferred__0/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_inferred__0/i__carry__1_n_0\,
      CO(3) => \ADD_OUT_inferred__0/i__carry__2_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_inferred__0/i__carry__2_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \REG_ACCUM_reg_n_0_[15]\,
      DI(2) => \REG_ACCUM_reg_n_0_[14]\,
      DI(1) => \REG_ACCUM_reg_n_0_[13]\,
      DI(0) => \REG_ACCUM_reg_n_0_[12]\,
      O(3 downto 0) => ADD_OUT(15 downto 12),
      S(3) => \i__carry__2_i_1_n_0\,
      S(2) => \i__carry__2_i_2_n_0\,
      S(1) => \i__carry__2_i_3_n_0\,
      S(0) => \i__carry__2_i_4_n_0\
    );
\ADD_OUT_inferred__0/i__carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_inferred__0/i__carry__2_n_0\,
      CO(3) => \ADD_OUT_inferred__0/i__carry__3_n_0\,
      CO(2 downto 0) => \NLW_ADD_OUT_inferred__0/i__carry__3_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \REG_ACCUM_reg_n_0_[19]\,
      DI(2) => \REG_ACCUM_reg_n_0_[18]\,
      DI(1) => \REG_ACCUM_reg_n_0_[17]\,
      DI(0) => \REG_ACCUM_reg_n_0_[16]\,
      O(3 downto 0) => ADD_OUT(19 downto 16),
      S(3) => \i__carry__3_i_1_n_0\,
      S(2) => \i__carry__3_i_2_n_0\,
      S(1) => \i__carry__3_i_3_n_0\,
      S(0) => \i__carry__3_i_4_n_0\
    );
\ADD_OUT_inferred__0/i__carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_inferred__0/i__carry__3_n_0\,
      CO(3 downto 0) => \NLW_ADD_OUT_inferred__0/i__carry__4_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \REG_ACCUM_reg_n_0_[20]\,
      O(3 downto 2) => \NLW_ADD_OUT_inferred__0/i__carry__4_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => ADD_OUT(21 downto 20),
      S(3 downto 2) => B"00",
      S(1) => \i__carry__4_i_1_n_0\,
      S(0) => \i__carry__4_i_2_n_0\
    );
\MUL1_OUT__0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL1_OUT__0_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__0_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => DI(2 downto 0),
      DI(0) => '0',
      O(3) => \MUL1_OUT__0_carry_n_4\,
      O(2 downto 0) => MUL1_OUT(2 downto 0),
      S(3 downto 0) => S(3 downto 0)
    );
\MUL1_OUT__0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__0_carry_n_0\,
      CO(3) => \MUL1_OUT__0_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__0_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => \MUL1_OUT__85_carry_i_8_0\(3 downto 0),
      O(3) => \MUL1_OUT__0_carry__0_n_4\,
      O(2) => \MUL1_OUT__0_carry__0_n_5\,
      O(1) => \MUL1_OUT__0_carry__0_n_6\,
      O(0) => \MUL1_OUT__0_carry__0_n_7\,
      S(3 downto 0) => \MUL1_OUT__85_carry_i_8_1\(3 downto 0)
    );
\MUL1_OUT__0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__0_carry__0_n_0\,
      CO(3) => \NLW_MUL1_OUT__0_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \MUL1_OUT__0_carry__1_n_1\,
      CO(1 downto 0) => \NLW_MUL1_OUT__0_carry__1_CO_UNCONNECTED\(1 downto 0),
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => \MUL1_OUT__85_carry__0_i_3_0\(1 downto 0),
      O(3 downto 2) => \NLW_MUL1_OUT__0_carry__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \MUL1_OUT__0_carry__1_n_6\,
      O(0) => \MUL1_OUT__0_carry__1_n_7\,
      S(3 downto 2) => B"01",
      S(1 downto 0) => \MUL1_OUT__85_carry__0_i_3_1\(1 downto 0)
    );
\MUL1_OUT__30_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL1_OUT__30_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__30_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => \REG1_reg[3]_0\(2 downto 0),
      DI(0) => '0',
      O(3) => \MUL1_OUT__30_carry_n_4\,
      O(2) => \MUL1_OUT__30_carry_n_5\,
      O(1) => \MUL1_OUT__30_carry_n_6\,
      O(0) => \MUL1_OUT__30_carry_n_7\,
      S(3 downto 0) => \REG1_reg[3]_1\(3 downto 0)
    );
\MUL1_OUT__30_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__30_carry_n_0\,
      CO(3) => \MUL1_OUT__30_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__30_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => \MUL1_OUT__85_carry__0_i_4_0\(3 downto 0),
      O(3) => \MUL1_OUT__30_carry__0_n_4\,
      O(2) => \MUL1_OUT__30_carry__0_n_5\,
      O(1) => \MUL1_OUT__30_carry__0_n_6\,
      O(0) => \MUL1_OUT__30_carry__0_n_7\,
      S(3 downto 0) => \MUL1_OUT__85_carry__0_i_4_1\(3 downto 0)
    );
\MUL1_OUT__30_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__30_carry__0_n_0\,
      CO(3) => \NLW_MUL1_OUT__30_carry__1_CO_UNCONNECTED\(3),
      CO(2) => CO(0),
      CO(1 downto 0) => \NLW_MUL1_OUT__30_carry__1_CO_UNCONNECTED\(1 downto 0),
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => \MUL1_OUT__85_carry__1_i_5\(1 downto 0),
      O(3 downto 2) => \NLW_MUL1_OUT__30_carry__1_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => \^o\(1 downto 0),
      S(3 downto 2) => B"01",
      S(1 downto 0) => \MUL1_OUT__85_carry__1_i_5_0\(1 downto 0)
    );
\MUL1_OUT__59_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL1_OUT__59_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__59_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => \MUL1_OUT__85_carry_i_1_0\(2 downto 0),
      DI(0) => '0',
      O(3) => \MUL1_OUT__59_carry_n_4\,
      O(2) => \MUL1_OUT__59_carry_n_5\,
      O(1) => \MUL1_OUT__59_carry_n_6\,
      O(0) => \MUL1_OUT__59_carry_n_7\,
      S(3 downto 0) => \MUL1_OUT__85_carry_i_1_1\(3 downto 0)
    );
\MUL1_OUT__59_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__59_carry_n_0\,
      CO(3) => \MUL1_OUT__59_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__59_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => \MUL1_OUT__85_carry__0_i_6_0\(3 downto 0),
      O(3 downto 1) => \^ramb_bl.ramb36_sin_bl.ram36_bl\(2 downto 0),
      O(0) => \MUL1_OUT__59_carry__0_n_7\,
      S(3 downto 0) => \MUL1_OUT__85_carry__0_i_6_1\(3 downto 0)
    );
\MUL1_OUT__59_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__59_carry__0_n_0\,
      CO(3 downto 0) => \NLW_MUL1_OUT__59_carry__1_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \REG1_reg[15]_0\(0),
      O(3 downto 2) => \NLW_MUL1_OUT__59_carry__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \MUL1_OUT__59_carry__1_n_6\,
      O(0) => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(0),
      S(3 downto 1) => B"001",
      S(0) => \REG1_reg[15]_1\(0)
    );
\MUL1_OUT__85_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL1_OUT__85_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__85_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \MUL1_OUT__85_carry_i_1_n_0\,
      DI(2) => \MUL1_OUT__85_carry_i_2_n_0\,
      DI(1) => \MUL1_OUT__85_carry_i_3_n_0\,
      DI(0) => \MUL1_OUT__85_carry_i_4_n_0\,
      O(3 downto 0) => MUL1_OUT(7 downto 4),
      S(3) => \MUL1_OUT__85_carry_i_5_n_0\,
      S(2) => \MUL1_OUT__85_carry_i_6_n_0\,
      S(1) => \MUL1_OUT__85_carry_i_7_n_0\,
      S(0) => \MUL1_OUT__85_carry_i_8_n_0\
    );
\MUL1_OUT__85_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__85_carry_n_0\,
      CO(3) => \MUL1_OUT__85_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL1_OUT__85_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \MUL1_OUT__85_carry__0_i_1_n_0\,
      DI(2) => \MUL1_OUT__85_carry__0_i_2_n_0\,
      DI(1) => \MUL1_OUT__85_carry__0_i_3_n_0\,
      DI(0) => \MUL1_OUT__85_carry__0_i_4_n_0\,
      O(3 downto 0) => MUL1_OUT(11 downto 8),
      S(3) => \MUL1_OUT__85_carry__0_i_5_n_0\,
      S(2) => \MUL1_OUT__85_carry__0_i_6_n_0\,
      S(1) => \MUL1_OUT__85_carry__0_i_7_n_0\,
      S(0) => \MUL1_OUT__85_carry__0_i_8_n_0\
    );
\MUL1_OUT__85_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL1_OUT__59_carry__0_n_7\,
      I1 => \MUL1_OUT__30_carry__0_n_4\,
      I2 => \MUL1_OUT__0_carry__1_n_1\,
      O => \MUL1_OUT__85_carry__0_i_1_n_0\
    );
\MUL1_OUT__85_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_4\,
      I1 => \MUL1_OUT__30_carry__0_n_5\,
      I2 => \MUL1_OUT__0_carry__1_n_6\,
      O => \MUL1_OUT__85_carry__0_i_2_n_0\
    );
\MUL1_OUT__85_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_5\,
      I1 => \MUL1_OUT__30_carry__0_n_6\,
      I2 => \MUL1_OUT__0_carry__1_n_7\,
      O => \MUL1_OUT__85_carry__0_i_3_n_0\
    );
\MUL1_OUT__85_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_6\,
      I1 => \MUL1_OUT__30_carry__0_n_7\,
      I2 => \MUL1_OUT__0_carry__0_n_4\,
      O => \MUL1_OUT__85_carry__0_i_4_n_0\
    );
\MUL1_OUT__85_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__0_carry__1_n_1\,
      I1 => \MUL1_OUT__30_carry__0_n_4\,
      I2 => \MUL1_OUT__59_carry__0_n_7\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl\(0),
      I4 => \^o\(0),
      O => \MUL1_OUT__85_carry__0_i_5_n_0\
    );
\MUL1_OUT__85_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL1_OUT__85_carry__0_i_2_n_0\,
      I1 => \MUL1_OUT__30_carry__0_n_4\,
      I2 => \MUL1_OUT__59_carry__0_n_7\,
      I3 => \MUL1_OUT__0_carry__1_n_1\,
      O => \MUL1_OUT__85_carry__0_i_6_n_0\
    );
\MUL1_OUT__85_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_4\,
      I1 => \MUL1_OUT__30_carry__0_n_5\,
      I2 => \MUL1_OUT__0_carry__1_n_6\,
      I3 => \MUL1_OUT__85_carry__0_i_3_n_0\,
      O => \MUL1_OUT__85_carry__0_i_7_n_0\
    );
\MUL1_OUT__85_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_5\,
      I1 => \MUL1_OUT__30_carry__0_n_6\,
      I2 => \MUL1_OUT__0_carry__1_n_7\,
      I3 => \MUL1_OUT__85_carry__0_i_4_n_0\,
      O => \MUL1_OUT__85_carry__0_i_8_n_0\
    );
\MUL1_OUT__85_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL1_OUT__85_carry__0_n_0\,
      CO(3 downto 0) => \NLW_MUL1_OUT__85_carry__1_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(0),
      DI(1 downto 0) => \REG1_reg[15]_2\(1 downto 0),
      O(3 downto 0) => MUL1_OUT(15 downto 12),
      S(3) => \MUL1_OUT__59_carry__1_n_6\,
      S(2 downto 0) => \REG1_reg[15]_3\(2 downto 0)
    );
\MUL1_OUT__85_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_7\,
      I1 => \MUL1_OUT__30_carry_n_4\,
      I2 => \MUL1_OUT__0_carry__0_n_5\,
      O => \MUL1_OUT__85_carry_i_1_n_0\
    );
\MUL1_OUT__85_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \MUL1_OUT__30_carry_n_5\,
      I1 => \MUL1_OUT__0_carry__0_n_6\,
      O => \MUL1_OUT__85_carry_i_2_n_0\
    );
\MUL1_OUT__85_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \MUL1_OUT__0_carry__0_n_7\,
      I1 => \MUL1_OUT__30_carry_n_6\,
      O => \MUL1_OUT__85_carry_i_3_n_0\
    );
\MUL1_OUT__85_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \MUL1_OUT__0_carry_n_4\,
      I1 => \MUL1_OUT__30_carry_n_7\,
      O => \MUL1_OUT__85_carry_i_4_n_0\
    );
\MUL1_OUT__85_carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_6\,
      I1 => \MUL1_OUT__30_carry__0_n_7\,
      I2 => \MUL1_OUT__0_carry__0_n_4\,
      I3 => \MUL1_OUT__85_carry_i_1_n_0\,
      O => \MUL1_OUT__85_carry_i_5_n_0\
    );
\MUL1_OUT__85_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL1_OUT__59_carry_n_7\,
      I1 => \MUL1_OUT__30_carry_n_4\,
      I2 => \MUL1_OUT__0_carry__0_n_5\,
      I3 => \MUL1_OUT__85_carry_i_2_n_0\,
      O => \MUL1_OUT__85_carry_i_6_n_0\
    );
\MUL1_OUT__85_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => \MUL1_OUT__30_carry_n_5\,
      I1 => \MUL1_OUT__0_carry__0_n_6\,
      I2 => \MUL1_OUT__0_carry__0_n_7\,
      I3 => \MUL1_OUT__30_carry_n_6\,
      O => \MUL1_OUT__85_carry_i_7_n_0\
    );
\MUL1_OUT__85_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \MUL1_OUT__0_carry_n_4\,
      I1 => \MUL1_OUT__30_carry_n_7\,
      I2 => \MUL1_OUT__30_carry_n_6\,
      I3 => \MUL1_OUT__0_carry__0_n_7\,
      O => \MUL1_OUT__85_carry_i_8_n_0\
    );
\MUL2_OUT__0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL2_OUT__0_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__0_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => \REG2_reg[2]_0\(2 downto 0),
      DI(0) => '0',
      O(3) => \MUL2_OUT__0_carry_n_4\,
      O(2 downto 0) => MUL2_OUT(2 downto 0),
      S(3 downto 0) => \REG2_reg[2]_1\(3 downto 0)
    );
\MUL2_OUT__0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__0_carry_n_0\,
      CO(3) => \MUL2_OUT__0_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__0_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => \MUL2_OUT__85_carry_i_8_0\(3 downto 0),
      O(3) => \MUL2_OUT__0_carry__0_n_4\,
      O(2) => \MUL2_OUT__0_carry__0_n_5\,
      O(1) => \MUL2_OUT__0_carry__0_n_6\,
      O(0) => \MUL2_OUT__0_carry__0_n_7\,
      S(3 downto 0) => \MUL2_OUT__85_carry_i_8_1\(3 downto 0)
    );
\MUL2_OUT__0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__0_carry__0_n_0\,
      CO(3) => \NLW_MUL2_OUT__0_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \MUL2_OUT__0_carry__1_n_1\,
      CO(1 downto 0) => \NLW_MUL2_OUT__0_carry__1_CO_UNCONNECTED\(1 downto 0),
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => \MUL2_OUT__85_carry__0_i_3_0\(1 downto 0),
      O(3 downto 2) => \NLW_MUL2_OUT__0_carry__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \MUL2_OUT__0_carry__1_n_6\,
      O(0) => \MUL2_OUT__0_carry__1_n_7\,
      S(3 downto 2) => B"01",
      S(1 downto 0) => \MUL2_OUT__85_carry__0_i_3_1\(1 downto 0)
    );
\MUL2_OUT__30_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL2_OUT__30_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__30_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => \REG2_reg[3]_0\(2 downto 0),
      DI(0) => '0',
      O(3) => \MUL2_OUT__30_carry_n_4\,
      O(2) => \MUL2_OUT__30_carry_n_5\,
      O(1) => \MUL2_OUT__30_carry_n_6\,
      O(0) => \MUL2_OUT__30_carry_n_7\,
      S(3 downto 0) => \REG2_reg[3]_1\(3 downto 0)
    );
\MUL2_OUT__30_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__30_carry_n_0\,
      CO(3) => \MUL2_OUT__30_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__30_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => \MUL2_OUT__85_carry__0_i_4_0\(3 downto 0),
      O(3) => \MUL2_OUT__30_carry__0_n_4\,
      O(2) => \MUL2_OUT__30_carry__0_n_5\,
      O(1) => \MUL2_OUT__30_carry__0_n_6\,
      O(0) => \MUL2_OUT__30_carry__0_n_7\,
      S(3 downto 0) => \MUL2_OUT__85_carry__0_i_4_1\(3 downto 0)
    );
\MUL2_OUT__30_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__30_carry__0_n_0\,
      CO(3) => \NLW_MUL2_OUT__30_carry__1_CO_UNCONNECTED\(3),
      CO(2) => \ramb_bl.ramb36_sin_bl.ram36_bl_1\(0),
      CO(1 downto 0) => \NLW_MUL2_OUT__30_carry__1_CO_UNCONNECTED\(1 downto 0),
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => \MUL2_OUT__85_carry__1_i_5\(1 downto 0),
      O(3 downto 2) => \NLW_MUL2_OUT__30_carry__1_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\(1 downto 0),
      S(3 downto 2) => B"01",
      S(1 downto 0) => \MUL2_OUT__85_carry__1_i_5_0\(1 downto 0)
    );
\MUL2_OUT__59_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL2_OUT__59_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__59_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => \MUL2_OUT__85_carry_i_1_0\(2 downto 0),
      DI(0) => '0',
      O(3) => \MUL2_OUT__59_carry_n_4\,
      O(2) => \MUL2_OUT__59_carry_n_5\,
      O(1) => \MUL2_OUT__59_carry_n_6\,
      O(0) => \MUL2_OUT__59_carry_n_7\,
      S(3 downto 0) => \MUL2_OUT__85_carry_i_1_1\(3 downto 0)
    );
\MUL2_OUT__59_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__59_carry_n_0\,
      CO(3) => \MUL2_OUT__59_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__59_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => \MUL2_OUT__85_carry__0_i_6_0\(3 downto 0),
      O(3 downto 1) => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\(2 downto 0),
      O(0) => \MUL2_OUT__59_carry__0_n_7\,
      S(3 downto 0) => \MUL2_OUT__85_carry__0_i_6_1\(3 downto 0)
    );
\MUL2_OUT__59_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__59_carry__0_n_0\,
      CO(3 downto 0) => \NLW_MUL2_OUT__59_carry__1_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \REG2_reg[15]_0\(0),
      O(3 downto 2) => \NLW_MUL2_OUT__59_carry__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \MUL2_OUT__59_carry__1_n_6\,
      O(0) => \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(0),
      S(3 downto 1) => B"001",
      S(0) => \REG2_reg[15]_1\(0)
    );
\MUL2_OUT__85_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \MUL2_OUT__85_carry_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__85_carry_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \MUL2_OUT__85_carry_i_1_n_0\,
      DI(2) => \MUL2_OUT__85_carry_i_2_n_0\,
      DI(1) => \MUL2_OUT__85_carry_i_3_n_0\,
      DI(0) => \MUL2_OUT__85_carry_i_4_n_0\,
      O(3 downto 0) => MUL2_OUT(7 downto 4),
      S(3) => \MUL2_OUT__85_carry_i_5_n_0\,
      S(2) => \MUL2_OUT__85_carry_i_6_n_0\,
      S(1) => \MUL2_OUT__85_carry_i_7_n_0\,
      S(0) => \MUL2_OUT__85_carry_i_8_n_0\
    );
\MUL2_OUT__85_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__85_carry_n_0\,
      CO(3) => \MUL2_OUT__85_carry__0_n_0\,
      CO(2 downto 0) => \NLW_MUL2_OUT__85_carry__0_CO_UNCONNECTED\(2 downto 0),
      CYINIT => '0',
      DI(3) => \MUL2_OUT__85_carry__0_i_1_n_0\,
      DI(2) => \MUL2_OUT__85_carry__0_i_2_n_0\,
      DI(1) => \MUL2_OUT__85_carry__0_i_3_n_0\,
      DI(0) => \MUL2_OUT__85_carry__0_i_4_n_0\,
      O(3 downto 0) => MUL2_OUT(11 downto 8),
      S(3) => \MUL2_OUT__85_carry__0_i_5_n_0\,
      S(2) => \MUL2_OUT__85_carry__0_i_6_n_0\,
      S(1) => \MUL2_OUT__85_carry__0_i_7_n_0\,
      S(0) => \MUL2_OUT__85_carry__0_i_8_n_0\
    );
\MUL2_OUT__85_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0_n_7\,
      I1 => \MUL2_OUT__30_carry__0_n_4\,
      I2 => \MUL2_OUT__0_carry__1_n_1\,
      O => \MUL2_OUT__85_carry__0_i_1_n_0\
    );
\MUL2_OUT__85_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_4\,
      I1 => \MUL2_OUT__30_carry__0_n_5\,
      I2 => \MUL2_OUT__0_carry__1_n_6\,
      O => \MUL2_OUT__85_carry__0_i_2_n_0\
    );
\MUL2_OUT__85_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_5\,
      I1 => \MUL2_OUT__30_carry__0_n_6\,
      I2 => \MUL2_OUT__0_carry__1_n_7\,
      O => \MUL2_OUT__85_carry__0_i_3_n_0\
    );
\MUL2_OUT__85_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_6\,
      I1 => \MUL2_OUT__30_carry__0_n_7\,
      I2 => \MUL2_OUT__0_carry__0_n_4\,
      O => \MUL2_OUT__85_carry__0_i_4_n_0\
    );
\MUL2_OUT__85_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__0_carry__1_n_1\,
      I1 => \MUL2_OUT__30_carry__0_n_4\,
      I2 => \MUL2_OUT__59_carry__0_n_7\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\(0),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\(0),
      O => \MUL2_OUT__85_carry__0_i_5_n_0\
    );
\MUL2_OUT__85_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL2_OUT__85_carry__0_i_2_n_0\,
      I1 => \MUL2_OUT__30_carry__0_n_4\,
      I2 => \MUL2_OUT__59_carry__0_n_7\,
      I3 => \MUL2_OUT__0_carry__1_n_1\,
      O => \MUL2_OUT__85_carry__0_i_6_n_0\
    );
\MUL2_OUT__85_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_4\,
      I1 => \MUL2_OUT__30_carry__0_n_5\,
      I2 => \MUL2_OUT__0_carry__1_n_6\,
      I3 => \MUL2_OUT__85_carry__0_i_3_n_0\,
      O => \MUL2_OUT__85_carry__0_i_7_n_0\
    );
\MUL2_OUT__85_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_5\,
      I1 => \MUL2_OUT__30_carry__0_n_6\,
      I2 => \MUL2_OUT__0_carry__1_n_7\,
      I3 => \MUL2_OUT__85_carry__0_i_4_n_0\,
      O => \MUL2_OUT__85_carry__0_i_8_n_0\
    );
\MUL2_OUT__85_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \MUL2_OUT__85_carry__0_n_0\,
      CO(3 downto 0) => \NLW_MUL2_OUT__85_carry__1_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(0),
      DI(1 downto 0) => \REG2_reg[15]_2\(1 downto 0),
      O(3 downto 0) => MUL2_OUT(15 downto 12),
      S(3) => \MUL2_OUT__59_carry__1_n_6\,
      S(2 downto 0) => \REG2_reg[15]_3\(2 downto 0)
    );
\MUL2_OUT__85_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_7\,
      I1 => \MUL2_OUT__30_carry_n_4\,
      I2 => \MUL2_OUT__0_carry__0_n_5\,
      O => \MUL2_OUT__85_carry_i_1_n_0\
    );
\MUL2_OUT__85_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \MUL2_OUT__30_carry_n_5\,
      I1 => \MUL2_OUT__0_carry__0_n_6\,
      O => \MUL2_OUT__85_carry_i_2_n_0\
    );
\MUL2_OUT__85_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \MUL2_OUT__0_carry__0_n_7\,
      I1 => \MUL2_OUT__30_carry_n_6\,
      O => \MUL2_OUT__85_carry_i_3_n_0\
    );
\MUL2_OUT__85_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \MUL2_OUT__0_carry_n_4\,
      I1 => \MUL2_OUT__30_carry_n_7\,
      O => \MUL2_OUT__85_carry_i_4_n_0\
    );
\MUL2_OUT__85_carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_6\,
      I1 => \MUL2_OUT__30_carry__0_n_7\,
      I2 => \MUL2_OUT__0_carry__0_n_4\,
      I3 => \MUL2_OUT__85_carry_i_1_n_0\,
      O => \MUL2_OUT__85_carry_i_5_n_0\
    );
\MUL2_OUT__85_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \MUL2_OUT__59_carry_n_7\,
      I1 => \MUL2_OUT__30_carry_n_4\,
      I2 => \MUL2_OUT__0_carry__0_n_5\,
      I3 => \MUL2_OUT__85_carry_i_2_n_0\,
      O => \MUL2_OUT__85_carry_i_6_n_0\
    );
\MUL2_OUT__85_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => \MUL2_OUT__30_carry_n_5\,
      I1 => \MUL2_OUT__0_carry__0_n_6\,
      I2 => \MUL2_OUT__0_carry__0_n_7\,
      I3 => \MUL2_OUT__30_carry_n_6\,
      O => \MUL2_OUT__85_carry_i_7_n_0\
    );
\MUL2_OUT__85_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \MUL2_OUT__0_carry_n_4\,
      I1 => \MUL2_OUT__30_carry_n_7\,
      I2 => \MUL2_OUT__30_carry_n_6\,
      I3 => \MUL2_OUT__0_carry__0_n_7\,
      O => \MUL2_OUT__85_carry_i_8_n_0\
    );
\REG1[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \MUL1_OUT__0_carry_n_4\,
      I1 => \MUL1_OUT__30_carry_n_7\,
      O => MUL1_OUT(3)
    );
\REG1_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(0),
      Q => REG1(0),
      R => rst_IBUF
    );
\REG1_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(10),
      Q => REG1(10),
      R => rst_IBUF
    );
\REG1_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(11),
      Q => REG1(11),
      R => rst_IBUF
    );
\REG1_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(12),
      Q => REG1(12),
      R => rst_IBUF
    );
\REG1_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(13),
      Q => REG1(13),
      R => rst_IBUF
    );
\REG1_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(14),
      Q => REG1(14),
      R => rst_IBUF
    );
\REG1_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(15),
      Q => REG1(15),
      R => rst_IBUF
    );
\REG1_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(1),
      Q => REG1(1),
      R => rst_IBUF
    );
\REG1_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(2),
      Q => REG1(2),
      R => rst_IBUF
    );
\REG1_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(3),
      Q => REG1(3),
      R => rst_IBUF
    );
\REG1_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(4),
      Q => REG1(4),
      R => rst_IBUF
    );
\REG1_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(5),
      Q => REG1(5),
      R => rst_IBUF
    );
\REG1_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(6),
      Q => REG1(6),
      R => rst_IBUF
    );
\REG1_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(7),
      Q => REG1(7),
      R => rst_IBUF
    );
\REG1_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(8),
      Q => REG1(8),
      R => rst_IBUF
    );
\REG1_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL1_OUT(9),
      Q => REG1(9),
      R => rst_IBUF
    );
\REG2[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \MUL2_OUT__0_carry_n_4\,
      I1 => \MUL2_OUT__30_carry_n_7\,
      O => MUL2_OUT(3)
    );
\REG2_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(0),
      Q => REG2(0),
      R => rst_IBUF
    );
\REG2_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(10),
      Q => REG2(10),
      R => rst_IBUF
    );
\REG2_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(11),
      Q => REG2(11),
      R => rst_IBUF
    );
\REG2_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(12),
      Q => REG2(12),
      R => rst_IBUF
    );
\REG2_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(13),
      Q => REG2(13),
      R => rst_IBUF
    );
\REG2_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(14),
      Q => REG2(14),
      R => rst_IBUF
    );
\REG2_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(15),
      Q => REG2(15),
      R => rst_IBUF
    );
\REG2_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(1),
      Q => REG2(1),
      R => rst_IBUF
    );
\REG2_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(2),
      Q => REG2(2),
      R => rst_IBUF
    );
\REG2_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(3),
      Q => REG2(3),
      R => rst_IBUF
    );
\REG2_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(4),
      Q => REG2(4),
      R => rst_IBUF
    );
\REG2_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(5),
      Q => REG2(5),
      R => rst_IBUF
    );
\REG2_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(6),
      Q => REG2(6),
      R => rst_IBUF
    );
\REG2_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(7),
      Q => REG2(7),
      R => rst_IBUF
    );
\REG2_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(8),
      Q => REG2(8),
      R => rst_IBUF
    );
\REG2_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => E(0),
      D => MUL2_OUT(9),
      Q => REG2(9),
      R => rst_IBUF
    );
\REG_ACCUM_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(0),
      Q => \REG_ACCUM_reg_n_0_[0]\,
      R => SR(0)
    );
\REG_ACCUM_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(10),
      Q => \REG_ACCUM_reg_n_0_[10]\,
      R => SR(0)
    );
\REG_ACCUM_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(11),
      Q => \REG_ACCUM_reg_n_0_[11]\,
      R => SR(0)
    );
\REG_ACCUM_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(12),
      Q => \REG_ACCUM_reg_n_0_[12]\,
      R => SR(0)
    );
\REG_ACCUM_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(13),
      Q => \REG_ACCUM_reg_n_0_[13]\,
      R => SR(0)
    );
\REG_ACCUM_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(14),
      Q => \REG_ACCUM_reg_n_0_[14]\,
      R => SR(0)
    );
\REG_ACCUM_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(15),
      Q => \REG_ACCUM_reg_n_0_[15]\,
      R => SR(0)
    );
\REG_ACCUM_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(16),
      Q => \REG_ACCUM_reg_n_0_[16]\,
      R => SR(0)
    );
\REG_ACCUM_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(17),
      Q => \REG_ACCUM_reg_n_0_[17]\,
      R => SR(0)
    );
\REG_ACCUM_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(18),
      Q => \REG_ACCUM_reg_n_0_[18]\,
      R => SR(0)
    );
\REG_ACCUM_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(19),
      Q => \REG_ACCUM_reg_n_0_[19]\,
      R => SR(0)
    );
\REG_ACCUM_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(1),
      Q => \REG_ACCUM_reg_n_0_[1]\,
      R => SR(0)
    );
\REG_ACCUM_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(20),
      Q => \REG_ACCUM_reg_n_0_[20]\,
      R => SR(0)
    );
\REG_ACCUM_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(21),
      Q => \REG_ACCUM_reg_n_0_[21]\,
      R => SR(0)
    );
\REG_ACCUM_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(2),
      Q => \REG_ACCUM_reg_n_0_[2]\,
      R => SR(0)
    );
\REG_ACCUM_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(3),
      Q => \REG_ACCUM_reg_n_0_[3]\,
      R => SR(0)
    );
\REG_ACCUM_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(4),
      Q => \REG_ACCUM_reg_n_0_[4]\,
      R => SR(0)
    );
\REG_ACCUM_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(5),
      Q => \REG_ACCUM_reg_n_0_[5]\,
      R => SR(0)
    );
\REG_ACCUM_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(6),
      Q => \REG_ACCUM_reg_n_0_[6]\,
      R => SR(0)
    );
\REG_ACCUM_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(7),
      Q => \REG_ACCUM_reg_n_0_[7]\,
      R => SR(0)
    );
\REG_ACCUM_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(8),
      Q => \REG_ACCUM_reg_n_0_[8]\,
      R => SR(0)
    );
\REG_ACCUM_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \REG_ACCUM_reg[0]_0\(0),
      D => ADD_OUT(9),
      Q => \REG_ACCUM_reg_n_0_[9]\,
      R => SR(0)
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[7]\,
      I1 => PCIN(7),
      O => \i__carry__0_i_1_n_0\
    );
\i__carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[6]\,
      I1 => PCIN(6),
      O => \i__carry__0_i_2_n_0\
    );
\i__carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[5]\,
      I1 => PCIN(5),
      O => \i__carry__0_i_3_n_0\
    );
\i__carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[4]\,
      I1 => PCIN(4),
      O => \i__carry__0_i_4_n_0\
    );
\i__carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[11]\,
      I1 => PCIN(11),
      O => \i__carry__1_i_1_n_0\
    );
\i__carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[10]\,
      I1 => PCIN(10),
      O => \i__carry__1_i_2_n_0\
    );
\i__carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[9]\,
      I1 => PCIN(9),
      O => \i__carry__1_i_3_n_0\
    );
\i__carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[8]\,
      I1 => PCIN(8),
      O => \i__carry__1_i_4_n_0\
    );
\i__carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[15]\,
      I1 => PCIN(15),
      O => \i__carry__2_i_1_n_0\
    );
\i__carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[14]\,
      I1 => PCIN(14),
      O => \i__carry__2_i_2_n_0\
    );
\i__carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[13]\,
      I1 => PCIN(13),
      O => \i__carry__2_i_3_n_0\
    );
\i__carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[12]\,
      I1 => PCIN(12),
      O => \i__carry__2_i_4_n_0\
    );
\i__carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[19]\,
      I1 => \i__carry__3_i_5_n_3\,
      O => \i__carry__3_i_1_n_0\
    );
\i__carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[18]\,
      I1 => \i__carry__3_i_5_n_3\,
      O => \i__carry__3_i_2_n_0\
    );
\i__carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[17]\,
      I1 => \i__carry__3_i_5_n_3\,
      O => \i__carry__3_i_3_n_0\
    );
\i__carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[16]\,
      I1 => \i__carry__3_i_5_n_3\,
      O => \i__carry__3_i_4_n_0\
    );
\i__carry__3_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \ADD_OUT_carry__2_n_0\,
      CO(3 downto 1) => \NLW_i__carry__3_i_5_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \i__carry__3_i_5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_i__carry__3_i_5_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\i__carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[21]\,
      I1 => \i__carry__3_i_5_n_3\,
      O => \i__carry__4_i_1_n_0\
    );
\i__carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[20]\,
      I1 => \i__carry__3_i_5_n_3\,
      O => \i__carry__4_i_2_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[3]\,
      I1 => PCIN(3),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[2]\,
      I1 => PCIN(2),
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[1]\,
      I1 => PCIN(1),
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[0]\,
      I1 => PCIN(0),
      O => \i__carry_i_4_n_0\
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[20]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(20)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[11]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(11)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[10]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(10)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[9]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(9)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[8]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(8)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[7]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(7)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[6]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(6)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[5]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(5)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[4]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(4)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[3]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(3)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[2]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(2)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[19]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(19)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[1]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(1)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[0]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(0)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[18]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(18)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[17]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(17)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[16]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(16)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[15]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(15)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[14]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(14)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[13]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(13)
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REG_ACCUM_reg_n_0_[12]\,
      I1 => \REG_ACCUM_reg_n_0_[21]\,
      O => DIADI(12)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity unimacro_BRAM_SINGLE_MACRO is
  port (
    DOADO : out STD_LOGIC_VECTOR ( 31 downto 0 );
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_1\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_2\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_3\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_4\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_5\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_6\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_7\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_8\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_9\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_10\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_11\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \MUL1_OUT__59_carry__0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_12\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_13\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_14\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_15\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_16\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_17\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_18\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_19\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_20\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_21\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_22\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_23\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_24\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \MUL2_OUT__59_carry__0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    B : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_25\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_26\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_27\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_28\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_29\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_30\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_31\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_32\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_33\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_34\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL1_OUT__59_carry__1\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \MUL2_OUT__59_carry__1\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    CLK : in STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_35\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    rst_IBUF : in STD_LOGIC;
    \REG2_reg[2]\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    A : in STD_LOGIC_VECTOR ( 6 downto 0 );
    O : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG1_reg[15]\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \REG2_reg[2]_0\ : in STD_LOGIC;
    \REG2_reg[2]_1\ : in STD_LOGIC;
    \REG2_reg[2]_2\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_0\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_1\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_2\ : in STD_LOGIC;
    \REG2_reg[15]\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG2_reg[15]_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \MUL1_OUT__0_carry__0\ : in STD_LOGIC;
    \MUL1_OUT__0_carry__1\ : in STD_LOGIC;
    \MUL1_OUT__30_carry__0\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_3\ : in STD_LOGIC;
    \MUL2_OUT__30_carry__0\ : in STD_LOGIC;
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG1_reg[15]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG2_reg[15]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG2_reg[15]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    pwropt : in STD_LOGIC;
    pwropt_1 : out STD_LOGIC
  );
end unimacro_BRAM_SINGLE_MACRO;

architecture STRUCTURE of unimacro_BRAM_SINGLE_MACRO is
  signal \^doado\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_1\ : STD_LOGIC;
  signal \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_2\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_0\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_1\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_13\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_14\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_15\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_16\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_19\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_2\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_20\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_21\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_22\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_3\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_6\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_7\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_8\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_9\ : STD_LOGIC;
  signal \ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_sig_3\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  attribute IS_CLOCK_GATED : boolean;
  attribute IS_CLOCK_GATED of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is std.standard.true;
  attribute POWER_OPTED_CE : string;
  attribute POWER_OPTED_CE of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is "ENARDEN=NEW";
  attribute box_type : string;
  attribute box_type of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is "PRIMITIVE";
begin
  DOADO(31 downto 0) <= \^doado\(31 downto 0);
  pwropt_1 <= \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_2\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_0\(3 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(3 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_1\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_1\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_13\(3 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_13\(3 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_14\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_14\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_15\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_15\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_16\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_16\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_19\(3 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_19\(3 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_2\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_2\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_20\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_20\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_21\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_21\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_22\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_22\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_3\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_3\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_6\(3 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_6\(3 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_7\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_7\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_8\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_8\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_9\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_9\;
\MUL1_OUT__0_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I1 => A(3),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I3 => A(4),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I5 => A(5),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(3)
    );
\MUL1_OUT__0_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I1 => A(2),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I3 => A(3),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I5 => A(4),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(2)
    );
\MUL1_OUT__0_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I1 => A(1),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I3 => A(2),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I5 => A(3),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(1)
    );
\MUL1_OUT__0_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I1 => A(0),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I3 => A(1),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I5 => A(2),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(0)
    );
\MUL1_OUT__0_carry__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6A95956A956A956A"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_0\(3),
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I2 => A(5),
      I3 => \MUL1_OUT__0_carry__0\,
      I4 => A(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(0)
    );
\MUL1_OUT__0_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000F888F888F888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I1 => A(4),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I3 => A(5),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I5 => A(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0)
    );
\MUL1_OUT__0_carry__1_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02A2FFFF5555FFFF"
    )
        port map (
      I0 => A(5),
      I1 => \^doado\(1),
      I2 => \MUL1_OUT__0_carry__1\,
      I3 => \^doado\(17),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I5 => A(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(1)
    );
\MUL1_OUT__0_carry__1_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2450F30F4BFFC3FF"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I1 => A(4),
      I2 => A(5),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I4 => A(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(0)
    );
\MUL1_OUT__0_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\,
      I1 => A(1),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      I3 => A(0),
      I4 => A(2),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      O => DI(1)
    );
\MUL1_OUT__0_carry_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(18),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(2),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_1\
    );
\MUL1_OUT__0_carry_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(16),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(0),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\
    );
\MUL1_OUT__0_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08F30008080000"
    )
        port map (
      I0 => \^doado\(16),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(0),
      I4 => \REG2_reg[2]\(2),
      I5 => \REG2_reg[2]\(0),
      O => DI(0)
    );
\MUL1_OUT__0_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(17),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(1),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_2\
    );
\MUL1_OUT__30_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I1 => A(3),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I3 => A(4),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      I5 => A(5),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_6\(3)
    );
\MUL1_OUT__30_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I1 => A(2),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I3 => A(3),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      I5 => A(4),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_6\(2)
    );
\MUL1_OUT__30_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I1 => A(1),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I3 => A(2),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      I5 => A(3),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_6\(1)
    );
\MUL1_OUT__30_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I1 => A(0),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I3 => A(1),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      I5 => A(2),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_6\(0)
    );
\MUL1_OUT__30_carry__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6A95956A956A956A"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_6\(3),
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I2 => A(5),
      I3 => \MUL1_OUT__30_carry__0\,
      I4 => A(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_29\(0)
    );
\MUL1_OUT__30_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000F888F888F888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I1 => A(4),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I3 => A(5),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      I5 => A(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_10\(0)
    );
\MUL1_OUT__30_carry__1_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02A2FFFF5555FFFF"
    )
        port map (
      I0 => A(5),
      I1 => \^doado\(4),
      I2 => \MUL1_OUT__0_carry__1\,
      I3 => \^doado\(20),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I5 => A(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_30\(1)
    );
\MUL1_OUT__30_carry__1_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2450F30F4BFFC3FF"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      I1 => A(4),
      I2 => A(5),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I4 => A(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_30\(0)
    );
\MUL1_OUT__30_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I1 => A(1),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      I3 => A(0),
      I4 => A(2),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_5\(1)
    );
\MUL1_OUT__30_carry_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(19),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(3),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\
    );
\MUL1_OUT__30_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08F30008080000"
    )
        port map (
      I0 => \^doado\(19),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(3),
      I4 => \REG2_reg[2]\(2),
      I5 => \REG2_reg[2]\(0),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_5\(0)
    );
\MUL1_OUT__30_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(20),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(4),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\
    );
\MUL1_OUT__30_carry_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(21),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(5),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_7\
    );
\MUL1_OUT__59_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08F30008080000"
    )
        port map (
      I0 => \^doado\(23),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(7),
      I4 => \REG2_reg[2]\(2),
      I5 => \REG2_reg[2]\(0),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_11\(0)
    );
\MUL1_OUT__59_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(23),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(7),
      O => B(1)
    );
\MUL1_OUT__59_carry_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(22),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(6),
      O => B(0)
    );
\MUL1_OUT__85_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => O(1),
      I1 => \REG1_reg[15]\(1),
      O => \MUL1_OUT__59_carry__0\(1)
    );
\MUL1_OUT__85_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => O(0),
      I1 => \REG1_reg[15]\(0),
      O => \MUL1_OUT__59_carry__0\(0)
    );
\MUL1_OUT__85_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => CO(0),
      I1 => \REG1_reg[15]\(2),
      I2 => \REG1_reg[15]_0\(0),
      O => \MUL1_OUT__59_carry__1\(2)
    );
\MUL1_OUT__85_carry__1_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => O(1),
      I1 => \REG1_reg[15]\(1),
      I2 => \REG1_reg[15]\(2),
      I3 => CO(0),
      O => \MUL1_OUT__59_carry__1\(1)
    );
\MUL1_OUT__85_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => O(0),
      I1 => \REG1_reg[15]\(0),
      I2 => \REG1_reg[15]\(1),
      I3 => O(1),
      O => \MUL1_OUT__59_carry__1\(0)
    );
\MUL2_OUT__0_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I1 => \MUL2_OUT__0_carry__0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I3 => \MUL2_OUT__0_carry__0_0\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I5 => \MUL2_OUT__0_carry__0_1\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\(3)
    );
\MUL2_OUT__0_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I1 => \REG2_reg[2]_2\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I3 => \MUL2_OUT__0_carry__0\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I5 => \MUL2_OUT__0_carry__0_0\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\(2)
    );
\MUL2_OUT__0_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I1 => \REG2_reg[2]_1\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I3 => \REG2_reg[2]_2\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I5 => \MUL2_OUT__0_carry__0\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\(1)
    );
\MUL2_OUT__0_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I1 => \REG2_reg[2]_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I3 => \REG2_reg[2]_1\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I5 => \REG2_reg[2]_2\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\(0)
    );
\MUL2_OUT__0_carry__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6A95956A956A956A"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\(3),
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I2 => \MUL2_OUT__0_carry__0_1\,
      I3 => \MUL2_OUT__0_carry__0_3\,
      I4 => \MUL2_OUT__0_carry__0_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_31\(0)
    );
\MUL2_OUT__0_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000F888F888F888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I1 => \MUL2_OUT__0_carry__0_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I3 => \MUL2_OUT__0_carry__0_1\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I5 => \MUL2_OUT__0_carry__0_2\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_17\(0)
    );
\MUL2_OUT__0_carry__1_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02A2FFFF5555FFFF"
    )
        port map (
      I0 => \MUL2_OUT__0_carry__0_1\,
      I1 => \^doado\(25),
      I2 => \MUL1_OUT__0_carry__1\,
      I3 => \^doado\(9),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I5 => \MUL2_OUT__0_carry__0_2\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_32\(1)
    );
\MUL2_OUT__0_carry__1_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2450F30F4BFFC3FF"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I1 => \MUL2_OUT__0_carry__0_0\,
      I2 => \MUL2_OUT__0_carry__0_1\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I4 => \MUL2_OUT__0_carry__0_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_32\(0)
    );
\MUL2_OUT__0_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I1 => \REG2_reg[2]_1\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I3 => \REG2_reg[2]_0\,
      I4 => \REG2_reg[2]_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_12\(1)
    );
\MUL2_OUT__0_carry_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(10),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(26),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\
    );
\MUL2_OUT__0_carry_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(8),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(24),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\
    );
\MUL2_OUT__0_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08F30008080000"
    )
        port map (
      I0 => \^doado\(8),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(24),
      I4 => \REG2_reg[2]\(1),
      I5 => \REG2_reg[2]\(3),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_12\(0)
    );
\MUL2_OUT__0_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(9),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(25),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\
    );
\MUL2_OUT__30_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I1 => \MUL2_OUT__0_carry__0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I3 => \MUL2_OUT__0_carry__0_0\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      I5 => \MUL2_OUT__0_carry__0_1\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\(3)
    );
\MUL2_OUT__30_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I1 => \REG2_reg[2]_2\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I3 => \MUL2_OUT__0_carry__0\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      I5 => \MUL2_OUT__0_carry__0_0\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\(2)
    );
\MUL2_OUT__30_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I1 => \REG2_reg[2]_1\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I3 => \REG2_reg[2]_2\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      I5 => \MUL2_OUT__0_carry__0\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\(1)
    );
\MUL2_OUT__30_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F888800080008000"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I1 => \REG2_reg[2]_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I3 => \REG2_reg[2]_1\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      I5 => \REG2_reg[2]_2\,
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\(0)
    );
\MUL2_OUT__30_carry__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6A95956A956A956A"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\(3),
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I2 => \MUL2_OUT__0_carry__0_1\,
      I3 => \MUL2_OUT__30_carry__0\,
      I4 => \MUL2_OUT__0_carry__0_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_33\(0)
    );
\MUL2_OUT__30_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000F888F888F888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I1 => \MUL2_OUT__0_carry__0_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I3 => \MUL2_OUT__0_carry__0_1\,
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      I5 => \MUL2_OUT__0_carry__0_2\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(0)
    );
\MUL2_OUT__30_carry__1_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02A2FFFF5555FFFF"
    )
        port map (
      I0 => \MUL2_OUT__0_carry__0_1\,
      I1 => \^doado\(28),
      I2 => \MUL1_OUT__0_carry__1\,
      I3 => \^doado\(12),
      I4 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I5 => \MUL2_OUT__0_carry__0_2\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(1)
    );
\MUL2_OUT__30_carry__1_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2450F30F4BFFC3FF"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      I1 => \MUL2_OUT__0_carry__0_0\,
      I2 => \MUL2_OUT__0_carry__0_1\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I4 => \MUL2_OUT__0_carry__0_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(0)
    );
\MUL2_OUT__30_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I1 => \REG2_reg[2]_1\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I3 => \REG2_reg[2]_0\,
      I4 => \REG2_reg[2]_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_18\(1)
    );
\MUL2_OUT__30_carry_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(11),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(27),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_22\
    );
\MUL2_OUT__30_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08F30008080000"
    )
        port map (
      I0 => \^doado\(11),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(27),
      I4 => \REG2_reg[2]\(1),
      I5 => \REG2_reg[2]\(3),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_18\(0)
    );
\MUL2_OUT__30_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(12),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(28),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\
    );
\MUL2_OUT__30_carry_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(13),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(29),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\
    );
\MUL2_OUT__59_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08F30008080000"
    )
        port map (
      I0 => \^doado\(15),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(31),
      I4 => \REG2_reg[2]\(1),
      I5 => \REG2_reg[2]\(3),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0)
    );
\MUL2_OUT__59_carry_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(15),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(31),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_26\
    );
\MUL2_OUT__59_carry_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(14),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(30),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_25\
    );
\MUL2_OUT__85_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REG2_reg[15]\(1),
      I1 => \REG2_reg[15]_0\(1),
      O => \MUL2_OUT__59_carry__0\(1)
    );
\MUL2_OUT__85_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \REG2_reg[15]\(0),
      I1 => \REG2_reg[15]_0\(0),
      O => \MUL2_OUT__59_carry__0\(0)
    );
\MUL2_OUT__85_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \REG2_reg[15]_1\(0),
      I1 => \REG2_reg[15]_0\(2),
      I2 => \REG2_reg[15]_2\(0),
      O => \MUL2_OUT__59_carry__1\(2)
    );
\MUL2_OUT__85_carry__1_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \REG2_reg[15]\(1),
      I1 => \REG2_reg[15]_0\(1),
      I2 => \REG2_reg[15]_0\(2),
      I3 => \REG2_reg[15]_1\(0),
      O => \MUL2_OUT__59_carry__1\(1)
    );
\MUL2_OUT__85_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \REG2_reg[15]\(0),
      I1 => \REG2_reg[15]_0\(0),
      I2 => \REG2_reg[15]_0\(1),
      I3 => \REG2_reg[15]\(1),
      O => \MUL2_OUT__59_carry__1\(0)
    );
\inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_gate_1_cooolDelFlop\: unisim.vcomponents.FDCE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => '1',
      CLR => '0',
      D => pwropt,
      Q => \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_1\
    );
\inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_gate_2_cooolDelFlop\: unisim.vcomponents.FDCE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => '1',
      CLR => '0',
      D => rst_IBUF,
      Q => \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_2\
    );
\ramb_bl.ramb36_sin_bl.ram36_bl\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"B4ED1248FC7BFA4C14D47CF1CFE204C727CE5E04FFF7E53F90D0744017C65E26",
      INIT_01 => X"B3A3C707E664261B03C17919F3BCBC458D7860040B51584F3248FD50F32BB8B2",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      INIT_FILE => "NONE",
      IS_CLKARDCLK_INVERTED => '0',
      IS_CLKBWRCLK_INVERTED => '0',
      IS_ENARDEN_INVERTED => '0',
      IS_ENBWREN_INVERTED => '0',
      IS_RSTRAMARSTRAM_INVERTED => '0',
      IS_RSTRAMB_INVERTED => '0',
      IS_RSTREGARSTREG_INVERTED => '0',
      IS_RSTREGB_INVERTED => '0',
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "PERFORMANCE",
      READ_WIDTH_A => 36,
      READ_WIDTH_B => 0,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "NONE",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "WRITE_FIRST",
      WRITE_MODE_B => "WRITE_FIRST",
      WRITE_WIDTH_A => 36,
      WRITE_WIDTH_B => 0
    )
        port map (
      ADDRARDADDR(15 downto 9) => B"1000000",
      ADDRARDADDR(8 downto 5) => \ramb_bl.ramb36_sin_bl.ram36_bl_35\(3 downto 0),
      ADDRARDADDR(4 downto 0) => B"11111",
      ADDRBWRADDR(15 downto 0) => B"0000000000000000",
      CASCADEINA => '0',
      CASCADEINB => '0',
      CASCADEOUTA => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => CLK,
      CLKBWRCLK => '0',
      DBITERR => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED\,
      DIADI(31 downto 0) => B"00000000000000000000000000000000",
      DIBDI(31 downto 0) => B"00000000000000000000000000000000",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \^doado\(31 downto 0),
      DOBDO(31 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED\(31 downto 0),
      DOPADOP(3 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => \ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_sig_3\,
      ENBWREN => '0',
      INJECTDBITERR => '0',
      INJECTSBITERR => '0',
      RDADDRECC(8 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => '0',
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED\,
      WEA(3 downto 0) => B"0000",
      WEBWE(7 downto 0) => B"00000000"
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_gate_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"e"
    )
        port map (
      I0 => \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_2\,
      I1 => \inst_imemb/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_1\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_sig_3\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \unimacro_BRAM_SINGLE_MACRO__parameterized0\ is
  port (
    DOADO : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_0\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_1\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_2\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_3\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_4\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_5\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_6\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_7\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_8\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_9\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_10\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_11\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_12\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_13\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_14\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_15\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_16\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_17\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_18\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_19\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_20\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_21\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_22\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_23\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_24\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_25\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_26\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    S : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_27\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_28\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_29\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_30\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_31\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_32\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_33\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_34\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_35\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_36\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_37\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_38\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_39\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_40\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_41\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_42\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_43\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    CLK : in STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_44\ : in STD_LOGIC_VECTOR ( 7 downto 0 );
    \MUL2_OUT__59_carry\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rst_IBUF : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    B : in STD_LOGIC_VECTOR ( 7 downto 0 );
    \REG2_reg[2]\ : in STD_LOGIC;
    \MUL2_OUT__59_carry__0\ : in STD_LOGIC;
    \MUL2_OUT__59_carry__0_0\ : in STD_LOGIC;
    \REG2_reg[2]_0\ : in STD_LOGIC;
    \REG2_reg[2]_1\ : in STD_LOGIC;
    \MUL2_OUT__30_carry\ : in STD_LOGIC;
    \MUL2_OUT__30_carry_0\ : in STD_LOGIC;
    \REG2_reg[2]_2\ : in STD_LOGIC;
    \MUL2_OUT__30_carry_1\ : in STD_LOGIC;
    pwropt : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \unimacro_BRAM_SINGLE_MACRO__parameterized0\ : entity is "unimacro_BRAM_SINGLE_MACRO";
end \unimacro_BRAM_SINGLE_MACRO__parameterized0\;

architecture STRUCTURE of \unimacro_BRAM_SINGLE_MACRO__parameterized0\ is
  signal A : STD_LOGIC_VECTOR ( 0 to 0 );
  signal A0 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal A1 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal A2 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal A3 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \^doado\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \MUL1_OUT__0_carry__0_i_14_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_15_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_16_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_17_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_18_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_19_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_20_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_21_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_22_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_23_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry__0_i_24_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__0_carry_i_16_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_10_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_11_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_12_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_13_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_14_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_15_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_16_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_17_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_18_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_19_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry__0_i_20_n_0\ : STD_LOGIC;
  signal \MUL1_OUT__30_carry_i_11_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_14_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_15_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_16_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_17_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_18_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_19_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_20_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_21_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_22_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_23_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry__0_i_24_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry_i_14_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__0_carry_i_15_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_10_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_11_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_12_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_13_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_14_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_15_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_16_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_17_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_18_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_19_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry__0_i_20_n_0\ : STD_LOGIC;
  signal \MUL2_OUT__30_carry_i_11_n_0\ : STD_LOGIC;
  signal \inst_wmema/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_4\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_10\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_11\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_12\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_13\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_14\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_15\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_16\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_17\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_18\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_19\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_20\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_21\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_3\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_4\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_8\ : STD_LOGIC;
  signal \^ramb_bl.ramb36_sin_bl.ram36_bl_9\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_sig_5\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  attribute IS_CLOCK_GATED : boolean;
  attribute IS_CLOCK_GATED of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is std.standard.true;
  attribute POWER_OPTED_CE : string;
  attribute POWER_OPTED_CE of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is "ENARDEN=NEW";
  attribute box_type : string;
  attribute box_type of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is "PRIMITIVE";
begin
  DOADO(3 downto 0) <= \^doado\(3 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_10\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_10\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_11\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_11\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_12\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_12\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_13\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_13\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_14\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_14\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_15\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_15\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_16\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_16\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_17\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_17\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_18\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_18\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_19\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_19\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_20\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_20\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_21\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_21\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_3\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_3\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_4\(1 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(1 downto 0);
  \ramb_bl.ramb36_sin_bl.ram36_bl_8\ <= \^ramb_bl.ramb36_sin_bl.ram36_bl_8\;
  \ramb_bl.ramb36_sin_bl.ram36_bl_9\(1 downto 0) <= \^ramb_bl.ramb36_sin_bl.ram36_bl_9\(1 downto 0);
\MUL1_OUT__0_carry__0_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(5),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(5),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\
    );
\MUL1_OUT__0_carry__0_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(6),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(6),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\
    );
\MUL1_OUT__0_carry__0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(5),
      I1 => A2(5),
      I2 => \MUL2_OUT__59_carry\(2),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(18),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_0\
    );
\MUL1_OUT__0_carry__0_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(7),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(7),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\
    );
\MUL1_OUT__0_carry__0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(5),
      I1 => A2(5),
      I2 => \MUL2_OUT__59_carry\(0),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(16),
      O => \MUL1_OUT__0_carry__0_i_14_n_0\
    );
\MUL1_OUT__0_carry__0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(4),
      I1 => A2(4),
      I2 => \MUL2_OUT__59_carry\(1),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(17),
      O => \MUL1_OUT__0_carry__0_i_15_n_0\
    );
\MUL1_OUT__0_carry__0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(3),
      I1 => A2(3),
      I2 => \MUL2_OUT__59_carry\(2),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(18),
      O => \MUL1_OUT__0_carry__0_i_16_n_0\
    );
\MUL1_OUT__0_carry__0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(5),
      I1 => A2(5),
      I2 => \MUL2_OUT__59_carry\(1),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(17),
      O => \MUL1_OUT__0_carry__0_i_17_n_0\
    );
\MUL1_OUT__0_carry__0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(4),
      I1 => A2(4),
      I2 => \MUL2_OUT__59_carry\(2),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(18),
      O => \MUL1_OUT__0_carry__0_i_18_n_0\
    );
\MUL1_OUT__0_carry__0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(6),
      I1 => A2(6),
      I2 => \MUL2_OUT__59_carry\(0),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(16),
      O => \MUL1_OUT__0_carry__0_i_19_n_0\
    );
\MUL1_OUT__0_carry__0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(4),
      I1 => A2(4),
      I2 => \MUL2_OUT__59_carry\(0),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(16),
      O => \MUL1_OUT__0_carry__0_i_20_n_0\
    );
\MUL1_OUT__0_carry__0_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(3),
      I1 => A2(3),
      I2 => \MUL2_OUT__59_carry\(1),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(17),
      O => \MUL1_OUT__0_carry__0_i_21_n_0\
    );
\MUL1_OUT__0_carry__0_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(2),
      I1 => A2(2),
      I2 => \MUL2_OUT__59_carry\(2),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(18),
      O => \MUL1_OUT__0_carry__0_i_22_n_0\
    );
\MUL1_OUT__0_carry__0_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(2),
      I1 => A2(2),
      I2 => \MUL2_OUT__59_carry\(1),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(17),
      O => \MUL1_OUT__0_carry__0_i_23_n_0\
    );
\MUL1_OUT__0_carry__0_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => \^doado\(0),
      I1 => \^doado\(2),
      I2 => \MUL2_OUT__59_carry\(2),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(18),
      O => \MUL1_OUT__0_carry__0_i_24_n_0\
    );
\MUL1_OUT__0_carry__0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__0_carry__0_i_14_n_0\,
      I1 => \MUL1_OUT__0_carry__0_i_15_n_0\,
      I2 => \MUL1_OUT__0_carry__0_i_16_n_0\,
      I3 => \MUL1_OUT__0_carry__0_i_17_n_0\,
      I4 => \MUL1_OUT__0_carry__0_i_18_n_0\,
      I5 => \MUL1_OUT__0_carry__0_i_19_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_30\(2)
    );
\MUL1_OUT__0_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__0_carry__0_i_20_n_0\,
      I1 => \MUL1_OUT__0_carry__0_i_21_n_0\,
      I2 => \MUL1_OUT__0_carry__0_i_22_n_0\,
      I3 => \MUL1_OUT__0_carry__0_i_15_n_0\,
      I4 => \MUL1_OUT__0_carry__0_i_16_n_0\,
      I5 => \MUL1_OUT__0_carry__0_i_14_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_30\(1)
    );
\MUL1_OUT__0_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__0_carry_i_16_n_0\,
      I1 => \MUL1_OUT__0_carry__0_i_23_n_0\,
      I2 => \MUL1_OUT__0_carry__0_i_24_n_0\,
      I3 => \MUL1_OUT__0_carry__0_i_21_n_0\,
      I4 => \MUL1_OUT__0_carry__0_i_22_n_0\,
      I5 => \MUL1_OUT__0_carry__0_i_20_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_30\(0)
    );
\MUL1_OUT__0_carry__0_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(4),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(4),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\
    );
\MUL1_OUT__0_carry__1_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => B(1),
      I1 => A2(7),
      I2 => \REG2_reg[2]\,
      I3 => A0(7),
      I4 => B(2),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_31\(0)
    );
\MUL1_OUT__0_carry_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(2),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(0),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\
    );
\MUL1_OUT__0_carry_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(3),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(3),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_12\
    );
\MUL1_OUT__0_carry_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(0),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(0),
      O => A(0)
    );
\MUL1_OUT__0_carry_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(3),
      I1 => A2(3),
      I2 => \MUL2_OUT__59_carry\(0),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(16),
      O => \MUL1_OUT__0_carry_i_16_n_0\
    );
\MUL1_OUT__0_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => B(1),
      I1 => \^doado\(2),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(0),
      I4 => B(2),
      I5 => A(0),
      O => DI(0)
    );
\MUL1_OUT__0_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"99C369C399339933"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      I1 => \MUL1_OUT__0_carry_i_16_n_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      I3 => B(1),
      I4 => A(0),
      I5 => B(2),
      O => S(3)
    );
\MUL1_OUT__0_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => A(0),
      I1 => B(2),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      I3 => B(1),
      I4 => B(0),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      O => S(2)
    );
\MUL1_OUT__0_carry_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => B(0),
      I1 => \^doado\(2),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(0),
      I4 => B(1),
      I5 => A(0),
      O => S(1)
    );
\MUL1_OUT__0_carry_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0CCA0A0A000A0A0"
    )
        port map (
      I0 => A0(0),
      I1 => A2(0),
      I2 => \MUL2_OUT__59_carry\(0),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(16),
      O => S(0)
    );
\MUL1_OUT__0_carry_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A2(2),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A0(2),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\
    );
\MUL1_OUT__30_carry__0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(5),
      I1 => A2(5),
      I2 => \MUL2_OUT__59_carry\(3),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(19),
      O => \MUL1_OUT__30_carry__0_i_10_n_0\
    );
\MUL1_OUT__30_carry__0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(4),
      I1 => A2(4),
      I2 => \MUL2_OUT__59_carry\(4),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(20),
      O => \MUL1_OUT__30_carry__0_i_11_n_0\
    );
\MUL1_OUT__30_carry__0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(3),
      I1 => A2(3),
      I2 => \MUL2_OUT__59_carry\(5),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(21),
      O => \MUL1_OUT__30_carry__0_i_12_n_0\
    );
\MUL1_OUT__30_carry__0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(5),
      I1 => A2(5),
      I2 => \MUL2_OUT__59_carry\(4),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(20),
      O => \MUL1_OUT__30_carry__0_i_13_n_0\
    );
\MUL1_OUT__30_carry__0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(4),
      I1 => A2(4),
      I2 => \MUL2_OUT__59_carry\(5),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(21),
      O => \MUL1_OUT__30_carry__0_i_14_n_0\
    );
\MUL1_OUT__30_carry__0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(6),
      I1 => A2(6),
      I2 => \MUL2_OUT__59_carry\(3),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(19),
      O => \MUL1_OUT__30_carry__0_i_15_n_0\
    );
\MUL1_OUT__30_carry__0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(4),
      I1 => A2(4),
      I2 => \MUL2_OUT__59_carry\(3),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(19),
      O => \MUL1_OUT__30_carry__0_i_16_n_0\
    );
\MUL1_OUT__30_carry__0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(3),
      I1 => A2(3),
      I2 => \MUL2_OUT__59_carry\(4),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(20),
      O => \MUL1_OUT__30_carry__0_i_17_n_0\
    );
\MUL1_OUT__30_carry__0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(2),
      I1 => A2(2),
      I2 => \MUL2_OUT__59_carry\(5),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(21),
      O => \MUL1_OUT__30_carry__0_i_18_n_0\
    );
\MUL1_OUT__30_carry__0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(2),
      I1 => A2(2),
      I2 => \MUL2_OUT__59_carry\(4),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(20),
      O => \MUL1_OUT__30_carry__0_i_19_n_0\
    );
\MUL1_OUT__30_carry__0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => \^doado\(0),
      I1 => \^doado\(2),
      I2 => \MUL2_OUT__59_carry\(5),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(21),
      O => \MUL1_OUT__30_carry__0_i_20_n_0\
    );
\MUL1_OUT__30_carry__0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__30_carry__0_i_10_n_0\,
      I1 => \MUL1_OUT__30_carry__0_i_11_n_0\,
      I2 => \MUL1_OUT__30_carry__0_i_12_n_0\,
      I3 => \MUL1_OUT__30_carry__0_i_13_n_0\,
      I4 => \MUL1_OUT__30_carry__0_i_14_n_0\,
      I5 => \MUL1_OUT__30_carry__0_i_15_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_32\(2)
    );
\MUL1_OUT__30_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__30_carry__0_i_16_n_0\,
      I1 => \MUL1_OUT__30_carry__0_i_17_n_0\,
      I2 => \MUL1_OUT__30_carry__0_i_18_n_0\,
      I3 => \MUL1_OUT__30_carry__0_i_11_n_0\,
      I4 => \MUL1_OUT__30_carry__0_i_12_n_0\,
      I5 => \MUL1_OUT__30_carry__0_i_10_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_32\(1)
    );
\MUL1_OUT__30_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL1_OUT__30_carry_i_11_n_0\,
      I1 => \MUL1_OUT__30_carry__0_i_19_n_0\,
      I2 => \MUL1_OUT__30_carry__0_i_20_n_0\,
      I3 => \MUL1_OUT__30_carry__0_i_17_n_0\,
      I4 => \MUL1_OUT__30_carry__0_i_18_n_0\,
      I5 => \MUL1_OUT__30_carry__0_i_16_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_32\(0)
    );
\MUL1_OUT__30_carry__0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(5),
      I1 => A2(5),
      I2 => \MUL2_OUT__59_carry\(5),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(21),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_1\
    );
\MUL1_OUT__30_carry__1_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => B(4),
      I1 => A2(7),
      I2 => \REG2_reg[2]\,
      I3 => A0(7),
      I4 => B(5),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_33\(0)
    );
\MUL1_OUT__30_carry_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(3),
      I1 => A2(3),
      I2 => \MUL2_OUT__59_carry\(3),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(19),
      O => \MUL1_OUT__30_carry_i_11_n_0\
    );
\MUL1_OUT__30_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => B(4),
      I1 => \^doado\(2),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(0),
      I4 => B(5),
      I5 => A(0),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_22\(0)
    );
\MUL1_OUT__30_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"99C369C399339933"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      I1 => \MUL1_OUT__30_carry_i_11_n_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      I3 => B(4),
      I4 => A(0),
      I5 => B(5),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(3)
    );
\MUL1_OUT__30_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => A(0),
      I1 => B(5),
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      I3 => B(4),
      I4 => B(3),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(2)
    );
\MUL1_OUT__30_carry_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => B(3),
      I1 => \^doado\(2),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(0),
      I4 => B(4),
      I5 => A(0),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(1)
    );
\MUL1_OUT__30_carry_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0CCA0A0A000A0A0"
    )
        port map (
      I0 => A0(0),
      I1 => A2(0),
      I2 => \MUL2_OUT__59_carry\(3),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(19),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(0)
    );
\MUL1_OUT__59_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => B(7),
      I1 => A2(5),
      I2 => \REG2_reg[2]\,
      I3 => A0(5),
      I4 => B(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_35\(3)
    );
\MUL1_OUT__59_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => B(7),
      I1 => A2(4),
      I2 => \REG2_reg[2]\,
      I3 => A0(4),
      I4 => B(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_35\(2)
    );
\MUL1_OUT__59_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => B(7),
      I1 => A2(3),
      I2 => \REG2_reg[2]\,
      I3 => A0(3),
      I4 => B(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_35\(1)
    );
\MUL1_OUT__59_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => B(7),
      I1 => A2(2),
      I2 => \REG2_reg[2]\,
      I3 => A0(2),
      I4 => B(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_12\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_35\(0)
    );
\MUL1_OUT__59_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"738CC0C0"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I2 => B(7),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      I4 => B(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(3)
    );
\MUL1_OUT__59_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8C733F3F"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I2 => B(7),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      I4 => B(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(2)
    );
\MUL1_OUT__59_carry__0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8C733F3F"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_12\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\,
      I2 => B(7),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      I4 => B(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(1)
    );
\MUL1_OUT__59_carry__0_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8C733F3F"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_12\,
      I2 => B(7),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_13\,
      I4 => B(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(0)
    );
\MUL1_OUT__59_carry__1_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000757F757F757F"
    )
        port map (
      I0 => B(7),
      I1 => A2(6),
      I2 => \REG2_reg[2]\,
      I3 => A0(6),
      I4 => B(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_2\(0)
    );
\MUL1_OUT__59_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEAE555503F3FFFF"
    )
        port map (
      I0 => B(6),
      I1 => A0(6),
      I2 => \REG2_reg[2]\,
      I3 => A2(6),
      I4 => B(7),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_3\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_36\(0)
    );
\MUL1_OUT__59_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => \^doado\(0),
      I1 => \^doado\(2),
      I2 => \MUL2_OUT__59_carry\(7),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(23),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(1)
    );
\MUL1_OUT__59_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A0(0),
      I1 => A2(0),
      I2 => \MUL2_OUT__59_carry\(7),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(23),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(0)
    );
\MUL1_OUT__59_carry_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"9F606060"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      I2 => B(7),
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_12\,
      I4 => B(6),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(3)
    );
\MUL1_OUT__59_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9A955A5595955555"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_4\(1),
      I1 => \MUL2_OUT__59_carry\(22),
      I2 => \REG2_reg[2]\,
      I3 => \MUL2_OUT__59_carry\(6),
      I4 => A2(2),
      I5 => A0(2),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(2)
    );
\MUL1_OUT__59_carry_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A80757F757F757F"
    )
        port map (
      I0 => B(7),
      I1 => A2(0),
      I2 => \REG2_reg[2]\,
      I3 => A0(0),
      I4 => B(6),
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(1)
    );
\MUL1_OUT__59_carry_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0CCA0A0A000A0A0"
    )
        port map (
      I0 => A0(0),
      I1 => A2(0),
      I2 => \MUL2_OUT__59_carry\(6),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(22),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(0)
    );
\MUL2_OUT__0_carry__0_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(5),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(5),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\
    );
\MUL2_OUT__0_carry__0_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(6),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(6),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\
    );
\MUL2_OUT__0_carry__0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(5),
      I1 => A1(5),
      I2 => \MUL2_OUT__59_carry\(26),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(10),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_5\
    );
\MUL2_OUT__0_carry__0_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(7),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(7),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\
    );
\MUL2_OUT__0_carry__0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(5),
      I1 => A1(5),
      I2 => \MUL2_OUT__59_carry\(24),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(8),
      O => \MUL2_OUT__0_carry__0_i_14_n_0\
    );
\MUL2_OUT__0_carry__0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(4),
      I1 => A1(4),
      I2 => \MUL2_OUT__59_carry\(25),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(9),
      O => \MUL2_OUT__0_carry__0_i_15_n_0\
    );
\MUL2_OUT__0_carry__0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(3),
      I1 => A1(3),
      I2 => \MUL2_OUT__59_carry\(26),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(10),
      O => \MUL2_OUT__0_carry__0_i_16_n_0\
    );
\MUL2_OUT__0_carry__0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(5),
      I1 => A1(5),
      I2 => \MUL2_OUT__59_carry\(25),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(9),
      O => \MUL2_OUT__0_carry__0_i_17_n_0\
    );
\MUL2_OUT__0_carry__0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(4),
      I1 => A1(4),
      I2 => \MUL2_OUT__59_carry\(26),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(10),
      O => \MUL2_OUT__0_carry__0_i_18_n_0\
    );
\MUL2_OUT__0_carry__0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(6),
      I1 => A1(6),
      I2 => \MUL2_OUT__59_carry\(24),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(8),
      O => \MUL2_OUT__0_carry__0_i_19_n_0\
    );
\MUL2_OUT__0_carry__0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(4),
      I1 => A1(4),
      I2 => \MUL2_OUT__59_carry\(24),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(8),
      O => \MUL2_OUT__0_carry__0_i_20_n_0\
    );
\MUL2_OUT__0_carry__0_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(3),
      I1 => A1(3),
      I2 => \MUL2_OUT__59_carry\(25),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(9),
      O => \MUL2_OUT__0_carry__0_i_21_n_0\
    );
\MUL2_OUT__0_carry__0_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(2),
      I1 => A1(2),
      I2 => \MUL2_OUT__59_carry\(26),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(10),
      O => \MUL2_OUT__0_carry__0_i_22_n_0\
    );
\MUL2_OUT__0_carry__0_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(2),
      I1 => A1(2),
      I2 => \MUL2_OUT__59_carry\(25),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(9),
      O => \MUL2_OUT__0_carry__0_i_23_n_0\
    );
\MUL2_OUT__0_carry__0_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => \^doado\(3),
      I1 => \^doado\(1),
      I2 => \MUL2_OUT__59_carry\(26),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(10),
      O => \MUL2_OUT__0_carry__0_i_24_n_0\
    );
\MUL2_OUT__0_carry__0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__0_carry__0_i_14_n_0\,
      I1 => \MUL2_OUT__0_carry__0_i_15_n_0\,
      I2 => \MUL2_OUT__0_carry__0_i_16_n_0\,
      I3 => \MUL2_OUT__0_carry__0_i_17_n_0\,
      I4 => \MUL2_OUT__0_carry__0_i_18_n_0\,
      I5 => \MUL2_OUT__0_carry__0_i_19_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_37\(2)
    );
\MUL2_OUT__0_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__0_carry__0_i_20_n_0\,
      I1 => \MUL2_OUT__0_carry__0_i_21_n_0\,
      I2 => \MUL2_OUT__0_carry__0_i_22_n_0\,
      I3 => \MUL2_OUT__0_carry__0_i_15_n_0\,
      I4 => \MUL2_OUT__0_carry__0_i_16_n_0\,
      I5 => \MUL2_OUT__0_carry__0_i_14_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_37\(1)
    );
\MUL2_OUT__0_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__0_carry_i_15_n_0\,
      I1 => \MUL2_OUT__0_carry__0_i_23_n_0\,
      I2 => \MUL2_OUT__0_carry__0_i_24_n_0\,
      I3 => \MUL2_OUT__0_carry__0_i_21_n_0\,
      I4 => \MUL2_OUT__0_carry__0_i_22_n_0\,
      I5 => \MUL2_OUT__0_carry__0_i_20_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_37\(0)
    );
\MUL2_OUT__0_carry__0_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(4),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(4),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\
    );
\MUL2_OUT__0_carry__1_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => \REG2_reg[2]_0\,
      I1 => A1(7),
      I2 => \REG2_reg[2]\,
      I3 => A3(7),
      I4 => \REG2_reg[2]_1\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_38\(0)
    );
\MUL2_OUT__0_carry_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \^doado\(1),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => \^doado\(3),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\
    );
\MUL2_OUT__0_carry_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(3),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(3),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_18\
    );
\MUL2_OUT__0_carry_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(0),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(0),
      O => \MUL2_OUT__0_carry_i_14_n_0\
    );
\MUL2_OUT__0_carry_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(3),
      I1 => A1(3),
      I2 => \MUL2_OUT__59_carry\(24),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(8),
      O => \MUL2_OUT__0_carry_i_15_n_0\
    );
\MUL2_OUT__0_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => \REG2_reg[2]_0\,
      I1 => \^doado\(1),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(3),
      I4 => \REG2_reg[2]_1\,
      I5 => \MUL2_OUT__0_carry_i_14_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0)
    );
\MUL2_OUT__0_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"99C369C399339933"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\,
      I1 => \MUL2_OUT__0_carry_i_15_n_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I3 => \REG2_reg[2]_0\,
      I4 => \MUL2_OUT__0_carry_i_14_n_0\,
      I5 => \REG2_reg[2]_1\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(3)
    );
\MUL2_OUT__0_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => \MUL2_OUT__0_carry_i_14_n_0\,
      I1 => \REG2_reg[2]_1\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I3 => \REG2_reg[2]_0\,
      I4 => \REG2_reg[2]_2\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(2)
    );
\MUL2_OUT__0_carry_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => \REG2_reg[2]_2\,
      I1 => \^doado\(1),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(3),
      I4 => \REG2_reg[2]_0\,
      I5 => \MUL2_OUT__0_carry_i_14_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(1)
    );
\MUL2_OUT__0_carry_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0CCA0A0A000A0A0"
    )
        port map (
      I0 => A3(0),
      I1 => A1(0),
      I2 => \MUL2_OUT__59_carry\(24),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(8),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(0)
    );
\MUL2_OUT__0_carry_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => A1(2),
      I1 => Q(0),
      I2 => rst_IBUF,
      I3 => A3(2),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\
    );
\MUL2_OUT__30_carry__0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(5),
      I1 => A1(5),
      I2 => \MUL2_OUT__59_carry\(27),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(11),
      O => \MUL2_OUT__30_carry__0_i_10_n_0\
    );
\MUL2_OUT__30_carry__0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(4),
      I1 => A1(4),
      I2 => \MUL2_OUT__59_carry\(28),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(12),
      O => \MUL2_OUT__30_carry__0_i_11_n_0\
    );
\MUL2_OUT__30_carry__0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(3),
      I1 => A1(3),
      I2 => \MUL2_OUT__59_carry\(29),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(13),
      O => \MUL2_OUT__30_carry__0_i_12_n_0\
    );
\MUL2_OUT__30_carry__0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(5),
      I1 => A1(5),
      I2 => \MUL2_OUT__59_carry\(28),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(12),
      O => \MUL2_OUT__30_carry__0_i_13_n_0\
    );
\MUL2_OUT__30_carry__0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(4),
      I1 => A1(4),
      I2 => \MUL2_OUT__59_carry\(29),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(13),
      O => \MUL2_OUT__30_carry__0_i_14_n_0\
    );
\MUL2_OUT__30_carry__0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(6),
      I1 => A1(6),
      I2 => \MUL2_OUT__59_carry\(27),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(11),
      O => \MUL2_OUT__30_carry__0_i_15_n_0\
    );
\MUL2_OUT__30_carry__0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(4),
      I1 => A1(4),
      I2 => \MUL2_OUT__59_carry\(27),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(11),
      O => \MUL2_OUT__30_carry__0_i_16_n_0\
    );
\MUL2_OUT__30_carry__0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(3),
      I1 => A1(3),
      I2 => \MUL2_OUT__59_carry\(28),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(12),
      O => \MUL2_OUT__30_carry__0_i_17_n_0\
    );
\MUL2_OUT__30_carry__0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(2),
      I1 => A1(2),
      I2 => \MUL2_OUT__59_carry\(29),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(13),
      O => \MUL2_OUT__30_carry__0_i_18_n_0\
    );
\MUL2_OUT__30_carry__0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(2),
      I1 => A1(2),
      I2 => \MUL2_OUT__59_carry\(28),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(12),
      O => \MUL2_OUT__30_carry__0_i_19_n_0\
    );
\MUL2_OUT__30_carry__0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => \^doado\(3),
      I1 => \^doado\(1),
      I2 => \MUL2_OUT__59_carry\(29),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(13),
      O => \MUL2_OUT__30_carry__0_i_20_n_0\
    );
\MUL2_OUT__30_carry__0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__30_carry__0_i_10_n_0\,
      I1 => \MUL2_OUT__30_carry__0_i_11_n_0\,
      I2 => \MUL2_OUT__30_carry__0_i_12_n_0\,
      I3 => \MUL2_OUT__30_carry__0_i_13_n_0\,
      I4 => \MUL2_OUT__30_carry__0_i_14_n_0\,
      I5 => \MUL2_OUT__30_carry__0_i_15_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_39\(2)
    );
\MUL2_OUT__30_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__30_carry__0_i_16_n_0\,
      I1 => \MUL2_OUT__30_carry__0_i_17_n_0\,
      I2 => \MUL2_OUT__30_carry__0_i_18_n_0\,
      I3 => \MUL2_OUT__30_carry__0_i_11_n_0\,
      I4 => \MUL2_OUT__30_carry__0_i_12_n_0\,
      I5 => \MUL2_OUT__30_carry__0_i_10_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_39\(1)
    );
\MUL2_OUT__30_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \MUL2_OUT__30_carry_i_11_n_0\,
      I1 => \MUL2_OUT__30_carry__0_i_19_n_0\,
      I2 => \MUL2_OUT__30_carry__0_i_20_n_0\,
      I3 => \MUL2_OUT__30_carry__0_i_17_n_0\,
      I4 => \MUL2_OUT__30_carry__0_i_18_n_0\,
      I5 => \MUL2_OUT__30_carry__0_i_16_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_39\(0)
    );
\MUL2_OUT__30_carry__0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(5),
      I1 => A1(5),
      I2 => \MUL2_OUT__59_carry\(29),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(13),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_6\
    );
\MUL2_OUT__30_carry__1_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => \MUL2_OUT__30_carry\,
      I1 => A1(7),
      I2 => \REG2_reg[2]\,
      I3 => A3(7),
      I4 => \MUL2_OUT__30_carry_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_40\(0)
    );
\MUL2_OUT__30_carry_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(3),
      I1 => A1(3),
      I2 => \MUL2_OUT__59_carry\(27),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(11),
      O => \MUL2_OUT__30_carry_i_11_n_0\
    );
\MUL2_OUT__30_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => \MUL2_OUT__30_carry\,
      I1 => \^doado\(1),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(3),
      I4 => \MUL2_OUT__30_carry_0\,
      I5 => \MUL2_OUT__0_carry_i_14_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_25\(0)
    );
\MUL2_OUT__30_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"99C369C399339933"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\,
      I1 => \MUL2_OUT__30_carry_i_11_n_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I3 => \MUL2_OUT__30_carry\,
      I4 => \MUL2_OUT__0_carry_i_14_n_0\,
      I5 => \MUL2_OUT__30_carry_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_29\(3)
    );
\MUL2_OUT__30_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8777788878887888"
    )
        port map (
      I0 => \MUL2_OUT__0_carry_i_14_n_0\,
      I1 => \MUL2_OUT__30_carry_0\,
      I2 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I3 => \MUL2_OUT__30_carry\,
      I4 => \MUL2_OUT__30_carry_1\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_29\(2)
    );
\MUL2_OUT__30_carry_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F8A808A808A80"
    )
        port map (
      I0 => \MUL2_OUT__30_carry_1\,
      I1 => \^doado\(1),
      I2 => \REG2_reg[2]\,
      I3 => \^doado\(3),
      I4 => \MUL2_OUT__30_carry\,
      I5 => \MUL2_OUT__0_carry_i_14_n_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_29\(1)
    );
\MUL2_OUT__30_carry_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0CCA0A0A000A0A0"
    )
        port map (
      I0 => A3(0),
      I1 => A1(0),
      I2 => \MUL2_OUT__59_carry\(27),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(11),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_29\(0)
    );
\MUL2_OUT__59_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0\,
      I1 => A1(5),
      I2 => \REG2_reg[2]\,
      I3 => A3(5),
      I4 => \MUL2_OUT__59_carry__0_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_42\(3)
    );
\MUL2_OUT__59_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0\,
      I1 => A1(4),
      I2 => \REG2_reg[2]\,
      I3 => A3(4),
      I4 => \MUL2_OUT__59_carry__0_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_42\(2)
    );
\MUL2_OUT__59_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0\,
      I1 => A1(3),
      I2 => \REG2_reg[2]\,
      I3 => A3(3),
      I4 => \MUL2_OUT__59_carry__0_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_42\(1)
    );
\MUL2_OUT__59_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"757F000000000000"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0\,
      I1 => A1(2),
      I2 => \REG2_reg[2]\,
      I3 => A3(2),
      I4 => \MUL2_OUT__59_carry__0_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_18\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_42\(0)
    );
\MUL2_OUT__59_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"738CC0C0"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I2 => \MUL2_OUT__59_carry__0\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      I4 => \MUL2_OUT__59_carry__0_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_26\(3)
    );
\MUL2_OUT__59_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8C733F3F"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I2 => \MUL2_OUT__59_carry__0\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_21\,
      I4 => \MUL2_OUT__59_carry__0_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_26\(2)
    );
\MUL2_OUT__59_carry__0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8C733F3F"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_18\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\,
      I2 => \MUL2_OUT__59_carry__0\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_20\,
      I4 => \MUL2_OUT__59_carry__0_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_26\(1)
    );
\MUL2_OUT__59_carry__0_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8C733F3F"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_18\,
      I2 => \MUL2_OUT__59_carry__0\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_19\,
      I4 => \MUL2_OUT__59_carry__0_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_26\(0)
    );
\MUL2_OUT__59_carry__1_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000757F757F757F"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0\,
      I1 => A1(6),
      I2 => \REG2_reg[2]\,
      I3 => A3(6),
      I4 => \MUL2_OUT__59_carry__0_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_7\(0)
    );
\MUL2_OUT__59_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEAE555503F3FFFF"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0_0\,
      I1 => A3(6),
      I2 => \REG2_reg[2]\,
      I3 => A1(6),
      I4 => \MUL2_OUT__59_carry__0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_43\(0)
    );
\MUL2_OUT__59_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => \^doado\(3),
      I1 => \^doado\(1),
      I2 => \MUL2_OUT__59_carry\(31),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(15),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\(1)
    );
\MUL2_OUT__59_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F335F5F5FFF5F5F"
    )
        port map (
      I0 => A3(0),
      I1 => A1(0),
      I2 => \MUL2_OUT__59_carry\(31),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(15),
      O => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\(0)
    );
\MUL2_OUT__59_carry_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"9F606060"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      I1 => \^ramb_bl.ramb36_sin_bl.ram36_bl_17\,
      I2 => \MUL2_OUT__59_carry__0\,
      I3 => \^ramb_bl.ramb36_sin_bl.ram36_bl_18\,
      I4 => \MUL2_OUT__59_carry__0_0\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_41\(3)
    );
\MUL2_OUT__59_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9A955A5595955555"
    )
        port map (
      I0 => \^ramb_bl.ramb36_sin_bl.ram36_bl_9\(1),
      I1 => \MUL2_OUT__59_carry\(14),
      I2 => \REG2_reg[2]\,
      I3 => \MUL2_OUT__59_carry\(30),
      I4 => A1(2),
      I5 => A3(2),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_41\(2)
    );
\MUL2_OUT__59_carry_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A80757F757F757F"
    )
        port map (
      I0 => \MUL2_OUT__59_carry__0\,
      I1 => A1(0),
      I2 => \REG2_reg[2]\,
      I3 => A3(0),
      I4 => \MUL2_OUT__59_carry__0_0\,
      I5 => \^ramb_bl.ramb36_sin_bl.ram36_bl_16\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_41\(1)
    );
\MUL2_OUT__59_carry_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0CCA0A0A000A0A0"
    )
        port map (
      I0 => A3(0),
      I1 => A1(0),
      I2 => \MUL2_OUT__59_carry\(30),
      I3 => rst_IBUF,
      I4 => Q(0),
      I5 => \MUL2_OUT__59_carry\(14),
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_41\(0)
    );
\inst_wmema/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_gate_5_cooolDelFlop\: unisim.vcomponents.FDCE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => '1',
      CLR => '0',
      D => Q(0),
      Q => \inst_wmema/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_4\
    );
\ramb_bl.ramb36_sin_bl.ram36_bl\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"38AD3D02FCFC000F0714EE3BD416B8CFE506B71715EB20D8543C15E9F6ACD4F7",
      INIT_01 => X"F2B5B40E3422F84626B9EE2DEADCFF3A884F2D2231053B0B376643E8C1193DF6",
      INIT_02 => X"13F84DE6FDEB5338DF07232132B952BE6AF3CA6A0B02BC0029A1EA51EE8C8A6A",
      INIT_03 => X"AF3913CA28CCFFA895DEAA4EF55AE0447901F897533938D6B8D5260EA21F1A67",
      INIT_04 => X"C4C4AB4CBC8EE79916960342F488E5FFD0FE065200C7703EF3D5B2353CE50A3D",
      INIT_05 => X"1FFC926F242C0C50EDFB465158EF26343B9B2B18E4D11B2111A4D75841EC832B",
      INIT_06 => X"F123EC36EE2852FE409DF91FD3BB371D3AB93E8BBAFFFE3811864AE60C281438",
      INIT_07 => X"A5D7612B474BEFA29650FDF2E4D37A6FF6BF8789EE21CF3610E8482104D1DEA3",
      INIT_08 => X"3C2308E64BF96E050C0C0AD878C955D4042FBDE18A8D2B40D1FD20FAB54B41F3",
      INIT_09 => X"E502EC06187863A3EC8DF20002DBE8BCA33BC90318BCA1B00455450BE147B842",
      INIT_0A => X"2E27AD17D618006F24294702E12ECE3BA0542977D5FF08D22249BA9A2ADDD939",
      INIT_0B => X"12BC35FEBF05E2F6322106299F3038F91F47B739227906239F85C0F3D4D004C1",
      INIT_0C => X"00E9D01BB1072D0E10BC15A6EF0804082EFED2657DFC892303C11E5F4FCDFD52",
      INIT_0D => X"7A20E63046BAF713B43D51EC8E78FFA908B4674205F6F24E714D47ADB189FA41",
      INIT_0E => X"8F8347594214A15CDA7DF904DB7D1809039F56FBB10302536BEC91AE3E084F86",
      INIT_0F => X"105D2C1098E5CD7ED171D4D4CA9DB9F63A4B278C8567FAEDC78A316DD103E03B",
      INIT_10 => X"CA1BC1773904C451FA1159FD4A20976F58D1F44651FA512E554E1533A7E01C55",
      INIT_11 => X"FD2E64D9DC26F8766FABA8DA030B16B2C021E8F12FE98EFCA217B836DC0DFB9F",
      INIT_12 => X"F238ECB15D4495049CE2C84F6971CE1F1655BD2AAD584B91F0B6D0509B2AB90B",
      INIT_13 => X"BF9C06272C4FFEB0C0396DB02CE2AFFADD025A3BFAC322E14C1C98E2F12E0BBE",
      INIT_14 => X"FA841A2AADB36E8AC3ACBF35A9233A5A570009E2651D9F3667C451E224399F04",
      INIT_15 => X"150AAB9598DB27D379E32A322ACFA8B80A9A20F7CC38480283E357EAA8C2300A",
      INIT_16 => X"1644091AFF2719ADF7330DDCFBEBD00308B22184F702E506D939483A8E6E4175",
      INIT_17 => X"EC3DF6FCB692B6E85D30DFF02D923122E8C000833074E879230623CFCDE9E682",
      INIT_18 => X"CF0131703204C14B8B04DA63FD07B80FBBA7F21D8DA8D909F52A297A00A80F5C",
      INIT_19 => X"84FB4F12295B04EAFD0C99F9C3F87006D628C03AAD2D7B730C3CB6EE92D3AFC9",
      INIT_1A => X"EDF266301004E241AFEC84212C5559FA1CD3B5DDBE0CED0126D601AAA31DC1E9",
      INIT_1B => X"BB16F395F7B0C544AFF8BDE514F0FE326B4869AB4A264964D2DEFEF973351618",
      INIT_1C => X"30D86519D81219440D1AEF8211F34541E3C2F246BED6E6594EA570E1FBFFA99D",
      INIT_1D => X"4D9ED6E0D6DAD645DAA103DD125E05EAFB8BDACEA69E06C414F24614F71EC808",
      INIT_1E => X"661071DFE75D08FAA013C80416E66485F5F53A9E361C0316045B54004132780F",
      INIT_1F => X"A0EA084D3ABC00E129AED95EF3544CAB32B60420661DDFC36B79FE0E4D40FCF8",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      INIT_FILE => "NONE",
      IS_CLKARDCLK_INVERTED => '0',
      IS_CLKBWRCLK_INVERTED => '0',
      IS_ENARDEN_INVERTED => '0',
      IS_ENBWREN_INVERTED => '0',
      IS_RSTRAMARSTRAM_INVERTED => '0',
      IS_RSTRAMB_INVERTED => '0',
      IS_RSTREGARSTREG_INVERTED => '0',
      IS_RSTREGB_INVERTED => '0',
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "PERFORMANCE",
      READ_WIDTH_A => 36,
      READ_WIDTH_B => 0,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "NONE",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "WRITE_FIRST",
      WRITE_MODE_B => "WRITE_FIRST",
      WRITE_WIDTH_A => 36,
      WRITE_WIDTH_B => 0
    )
        port map (
      ADDRARDADDR(15 downto 13) => B"100",
      ADDRARDADDR(12 downto 5) => \ramb_bl.ramb36_sin_bl.ram36_bl_44\(7 downto 0),
      ADDRARDADDR(4 downto 0) => B"11111",
      ADDRBWRADDR(15 downto 0) => B"0000000000000000",
      CASCADEINA => '0',
      CASCADEINB => '0',
      CASCADEOUTA => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => CLK,
      CLKBWRCLK => '0',
      DBITERR => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED\,
      DIADI(31 downto 0) => B"00000000000000000000000000000000",
      DIBDI(31 downto 0) => B"00000000000000000000000000000000",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 26) => A3(7 downto 2),
      DOADO(25) => \^doado\(3),
      DOADO(24) => A3(0),
      DOADO(23 downto 18) => A2(7 downto 2),
      DOADO(17) => \^doado\(2),
      DOADO(16) => A2(0),
      DOADO(15 downto 10) => A1(7 downto 2),
      DOADO(9) => \^doado\(1),
      DOADO(8) => A1(0),
      DOADO(7 downto 2) => A0(7 downto 2),
      DOADO(1) => \^doado\(0),
      DOADO(0) => A0(0),
      DOBDO(31 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED\(31 downto 0),
      DOPADOP(3 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => \ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_sig_5\,
      ENBWREN => '0',
      INJECTDBITERR => '0',
      INJECTSBITERR => '0',
      RDADDRECC(8 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => '0',
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED\,
      WEA(3 downto 0) => B"0000",
      WEBWE(7 downto 0) => B"00000000"
    );
\ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_gate_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"e"
    )
        port map (
      I0 => pwropt,
      I1 => \inst_wmema/MEM_in/ramb_bl.ramb36_sin_bl.ram36_bl_cooolgate_en_sig_4\,
      O => \ramb_bl.ramb36_sin_bl.ram36_bl_ENARDEN_cooolgate_en_sig_5\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \unimacro_BRAM_SINGLE_MACRO__parameterized1\ is
  port (
    DOADO : out STD_LOGIC_VECTOR ( 31 downto 0 );
    CLK : in STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    DIADI : in STD_LOGIC_VECTOR ( 20 downto 0 );
    WEA : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \unimacro_BRAM_SINGLE_MACRO__parameterized1\ : entity is "unimacro_BRAM_SINGLE_MACRO";
end \unimacro_BRAM_SINGLE_MACRO__parameterized1\;

architecture STRUCTURE of \unimacro_BRAM_SINGLE_MACRO__parameterized1\ is
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  attribute box_type : string;
  attribute box_type of \ramb_bl.ramb36_sin_bl.ram36_bl\ : label is "PRIMITIVE";
begin
\ramb_bl.ramb36_sin_bl.ram36_bl\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"000000000000000000000000000000000F0E0D0C0B0A09080706050403020100",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      INIT_FILE => "NONE",
      IS_CLKARDCLK_INVERTED => '0',
      IS_CLKBWRCLK_INVERTED => '0',
      IS_ENARDEN_INVERTED => '0',
      IS_ENBWREN_INVERTED => '0',
      IS_RSTRAMARSTRAM_INVERTED => '0',
      IS_RSTRAMB_INVERTED => '0',
      IS_RSTREGARSTREG_INVERTED => '0',
      IS_RSTREGB_INVERTED => '0',
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "PERFORMANCE",
      READ_WIDTH_A => 36,
      READ_WIDTH_B => 0,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "NONE",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "WRITE_FIRST",
      WRITE_MODE_B => "WRITE_FIRST",
      WRITE_WIDTH_A => 36,
      WRITE_WIDTH_B => 0
    )
        port map (
      ADDRARDADDR(15 downto 9) => B"1000000",
      ADDRARDADDR(8 downto 5) => \ramb_bl.ramb36_sin_bl.ram36_bl_0\(3 downto 0),
      ADDRARDADDR(4 downto 0) => B"11111",
      ADDRBWRADDR(15 downto 0) => B"0000000000000000",
      CASCADEINA => '0',
      CASCADEINB => '0',
      CASCADEOUTA => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => CLK,
      CLKBWRCLK => '0',
      DBITERR => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED\,
      DIADI(31 downto 21) => B"00000000000",
      DIADI(20 downto 0) => DIADI(20 downto 0),
      DIBDI(31 downto 0) => B"00000000000000000000000000000000",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => DOADO(31 downto 0),
      DOBDO(31 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED\(31 downto 0),
      DOPADOP(3 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => '1',
      ENBWREN => '0',
      INJECTDBITERR => '0',
      INJECTSBITERR => '0',
      RDADDRECC(8 downto 0) => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => '0',
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED\,
      WEA(3) => WEA(0),
      WEA(2) => WEA(0),
      WEA(1) => WEA(0),
      WEA(0) => WEA(0),
      WEBWE(7 downto 0) => B"00000000"
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity IMemB is
  port (
    DOADO : out STD_LOGIC_VECTOR ( 31 downto 0 );
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    B : out STD_LOGIC_VECTOR ( 7 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_1\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_2\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_3\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_4\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \MUL1_OUT__59_carry__0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_5\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_6\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_7\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_8\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_9\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_10\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_11\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_12\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_13\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_14\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_15\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_16\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_17\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \MUL2_OUT__59_carry__0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_18\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_19\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_20\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_21\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_22\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_23\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_24\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_25\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_26\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_27\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \MUL1_OUT__59_carry__1\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \MUL2_OUT__59_carry__1\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    CLK : in STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_28\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    rst_IBUF : in STD_LOGIC;
    \REG2_reg[2]\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    A : in STD_LOGIC_VECTOR ( 6 downto 0 );
    O : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG1_reg[15]\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \REG2_reg[2]_0\ : in STD_LOGIC;
    \REG2_reg[2]_1\ : in STD_LOGIC;
    \REG2_reg[2]_2\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_0\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_1\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_2\ : in STD_LOGIC;
    \REG2_reg[15]\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \REG2_reg[15]_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \MUL1_OUT__0_carry__0\ : in STD_LOGIC;
    \MUL1_OUT__0_carry__1\ : in STD_LOGIC;
    \MUL1_OUT__30_carry__0\ : in STD_LOGIC;
    \MUL2_OUT__0_carry__0_3\ : in STD_LOGIC;
    \MUL2_OUT__30_carry__0\ : in STD_LOGIC;
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG1_reg[15]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG2_reg[15]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REG2_reg[15]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    pwropt : in STD_LOGIC;
    pwropt_1 : out STD_LOGIC
  );
end IMemB;

architecture STRUCTURE of IMemB is
begin
MEM_in: entity work.unimacro_BRAM_SINGLE_MACRO
     port map (
      A(6 downto 0) => A(6 downto 0),
      B(1 downto 0) => B(7 downto 6),
      CLK => CLK,
      CO(0) => CO(0),
      DI(1 downto 0) => DI(1 downto 0),
      DOADO(31 downto 0) => DOADO(31 downto 0),
      \MUL1_OUT__0_carry__0\ => \MUL1_OUT__0_carry__0\,
      \MUL1_OUT__0_carry__1\ => \MUL1_OUT__0_carry__1\,
      \MUL1_OUT__30_carry__0\ => \MUL1_OUT__30_carry__0\,
      \MUL1_OUT__59_carry__0\(1 downto 0) => \MUL1_OUT__59_carry__0\(1 downto 0),
      \MUL1_OUT__59_carry__1\(2 downto 0) => \MUL1_OUT__59_carry__1\(2 downto 0),
      \MUL2_OUT__0_carry__0\ => \MUL2_OUT__0_carry__0\,
      \MUL2_OUT__0_carry__0_0\ => \MUL2_OUT__0_carry__0_0\,
      \MUL2_OUT__0_carry__0_1\ => \MUL2_OUT__0_carry__0_1\,
      \MUL2_OUT__0_carry__0_2\ => \MUL2_OUT__0_carry__0_2\,
      \MUL2_OUT__0_carry__0_3\ => \MUL2_OUT__0_carry__0_3\,
      \MUL2_OUT__30_carry__0\ => \MUL2_OUT__30_carry__0\,
      \MUL2_OUT__59_carry__0\(1 downto 0) => \MUL2_OUT__59_carry__0\(1 downto 0),
      \MUL2_OUT__59_carry__1\(2 downto 0) => \MUL2_OUT__59_carry__1\(2 downto 0),
      O(1 downto 0) => O(1 downto 0),
      Q(0) => Q(0),
      \REG1_reg[15]\(2 downto 0) => \REG1_reg[15]\(2 downto 0),
      \REG1_reg[15]_0\(0) => \REG1_reg[15]_0\(0),
      \REG2_reg[15]\(1 downto 0) => \REG2_reg[15]\(1 downto 0),
      \REG2_reg[15]_0\(2 downto 0) => \REG2_reg[15]_0\(2 downto 0),
      \REG2_reg[15]_1\(0) => \REG2_reg[15]_1\(0),
      \REG2_reg[15]_2\(0) => \REG2_reg[15]_2\(0),
      \REG2_reg[2]\(3 downto 0) => \REG2_reg[2]\(3 downto 0),
      \REG2_reg[2]_0\ => \REG2_reg[2]_0\,
      \REG2_reg[2]_1\ => \REG2_reg[2]_1\,
      \REG2_reg[2]_2\ => \REG2_reg[2]_2\,
      pwropt => pwropt,
      pwropt_1 => pwropt_1,
      \ramb_bl.ramb36_sin_bl.ram36_bl_0\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_1\ => B(2),
      \ramb_bl.ramb36_sin_bl.ram36_bl_10\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_11\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_5\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_13\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_6\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_14\ => \ramb_bl.ramb36_sin_bl.ram36_bl_7\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_15\ => \ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_16\ => \ramb_bl.ramb36_sin_bl.ram36_bl_9\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_10\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_18\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_11\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_19\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_12\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\ => B(1),
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\ => \ramb_bl.ramb36_sin_bl.ram36_bl_13\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\ => \ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\ => \ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_16\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_17\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_25\ => \ramb_bl.ramb36_sin_bl.ram36_bl_18\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_26\ => \ramb_bl.ramb36_sin_bl.ram36_bl_19\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_27\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_20\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_21\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_29\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_22\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\ => B(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_30\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_31\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_32\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_25\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_33\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_26\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_34\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_35\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_0\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_5\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_1\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_2\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_7\ => B(5),
      \ramb_bl.ramb36_sin_bl.ram36_bl_8\ => B(4),
      \ramb_bl.ramb36_sin_bl.ram36_bl_9\ => B(3),
      rst_IBUF => rst_IBUF
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity OMemC is
  port (
    DOADO : out STD_LOGIC_VECTOR ( 31 downto 0 );
    CLK : in STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    DIADI : in STD_LOGIC_VECTOR ( 20 downto 0 );
    WEA : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
end OMemC;

architecture STRUCTURE of OMemC is
begin
MEM_in: entity work.\unimacro_BRAM_SINGLE_MACRO__parameterized1\
     port map (
      CLK => CLK,
      DIADI(20 downto 0) => DIADI(20 downto 0),
      DOADO(31 downto 0) => DOADO(31 downto 0),
      WEA(0) => WEA(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_0\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl\(3 downto 0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity WMemA is
  port (
    \ramb_bl.ramb36_sin_bl.ram36_bl\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_0\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_1\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_2\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_3\ : out STD_LOGIC_VECTOR ( 6 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_4\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_5\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_6\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_7\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_8\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_9\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_10\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_11\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_12\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_13\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_14\ : out STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_15\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_16\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_17\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_18\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_19\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_20\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    S : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_21\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_22\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_23\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_24\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_25\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_26\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_27\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_28\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_29\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_30\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_31\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_32\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_33\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_34\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_35\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_36\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \ramb_bl.ramb36_sin_bl.ram36_bl_37\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    CLK : in STD_LOGIC;
    \ramb_bl.ramb36_sin_bl.ram36_bl_38\ : in STD_LOGIC_VECTOR ( 7 downto 0 );
    DOADO : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rst_IBUF : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    B : in STD_LOGIC_VECTOR ( 7 downto 0 );
    \REG2_reg[2]\ : in STD_LOGIC;
    \MUL2_OUT__59_carry__0\ : in STD_LOGIC;
    \MUL2_OUT__59_carry__0_0\ : in STD_LOGIC;
    \REG2_reg[2]_0\ : in STD_LOGIC;
    \REG2_reg[2]_1\ : in STD_LOGIC;
    \MUL2_OUT__30_carry\ : in STD_LOGIC;
    \MUL2_OUT__30_carry_0\ : in STD_LOGIC;
    \REG2_reg[2]_2\ : in STD_LOGIC;
    \MUL2_OUT__30_carry_1\ : in STD_LOGIC;
    pwropt : in STD_LOGIC
  );
end WMemA;

architecture STRUCTURE of WMemA is
begin
MEM_in: entity work.\unimacro_BRAM_SINGLE_MACRO__parameterized0\
     port map (
      B(7 downto 0) => B(7 downto 0),
      CLK => CLK,
      DI(0) => DI(0),
      DOADO(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl\(3 downto 0),
      \MUL2_OUT__30_carry\ => \MUL2_OUT__30_carry\,
      \MUL2_OUT__30_carry_0\ => \MUL2_OUT__30_carry_0\,
      \MUL2_OUT__30_carry_1\ => \MUL2_OUT__30_carry_1\,
      \MUL2_OUT__59_carry\(31 downto 0) => DOADO(31 downto 0),
      \MUL2_OUT__59_carry__0\ => \MUL2_OUT__59_carry__0\,
      \MUL2_OUT__59_carry__0_0\ => \MUL2_OUT__59_carry__0_0\,
      Q(0) => Q(0),
      \REG2_reg[2]\ => \REG2_reg[2]\,
      \REG2_reg[2]_0\ => \REG2_reg[2]_0\,
      \REG2_reg[2]_1\ => \REG2_reg[2]_1\,
      \REG2_reg[2]_2\ => \REG2_reg[2]_2\,
      S(3 downto 0) => S(3 downto 0),
      pwropt => pwropt,
      \ramb_bl.ramb36_sin_bl.ram36_bl_0\ => \ramb_bl.ramb36_sin_bl.ram36_bl_0\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_1\ => \ramb_bl.ramb36_sin_bl.ram36_bl_1\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_10\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_11\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(1),
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(2),
      \ramb_bl.ramb36_sin_bl.ram36_bl_13\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(3),
      \ramb_bl.ramb36_sin_bl.ram36_bl_14\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(4),
      \ramb_bl.ramb36_sin_bl.ram36_bl_15\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(5),
      \ramb_bl.ramb36_sin_bl.ram36_bl_16\ => \ramb_bl.ramb36_sin_bl.ram36_bl_10\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\ => \ramb_bl.ramb36_sin_bl.ram36_bl_11\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_18\ => \ramb_bl.ramb36_sin_bl.ram36_bl_12\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_19\ => \ramb_bl.ramb36_sin_bl.ram36_bl_13\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_2\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\ => \ramb_bl.ramb36_sin_bl.ram36_bl_14\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\ => \ramb_bl.ramb36_sin_bl.ram36_bl_15\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_16\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_17\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_18\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_25\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_19\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_26\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_20\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_27\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_21\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_22\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_29\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_23\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\ => \ramb_bl.ramb36_sin_bl.ram36_bl_3\(6),
      \ramb_bl.ramb36_sin_bl.ram36_bl_30\(2 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_24\(2 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_31\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_25\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_32\(2 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_26\(2 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_33\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_27\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_34\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_28\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_35\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_29\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_36\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_30\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_37\(2 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_31\(2 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_38\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_32\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_39\(2 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_33\(2 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_4\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_4\(1 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_40\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_34\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_41\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_35\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_42\(3 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_36\(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_43\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_37\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_44\(7 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_38\(7 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_5\ => \ramb_bl.ramb36_sin_bl.ram36_bl_5\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\ => \ramb_bl.ramb36_sin_bl.ram36_bl_6\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_7\(0) => \ramb_bl.ramb36_sin_bl.ram36_bl_7\(0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_8\ => \ramb_bl.ramb36_sin_bl.ram36_bl_8\,
      \ramb_bl.ramb36_sin_bl.ram36_bl_9\(1 downto 0) => \ramb_bl.ramb36_sin_bl.ram36_bl_9\(1 downto 0),
      rst_IBUF => rst_IBUF
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity circuito is
  port (
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    done : out STD_LOGIC;
    we : out STD_LOGIC;
    addr_omemc : out STD_LOGIC_VECTOR ( 9 downto 0 );
    DataOut : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of circuito : entity is true;
  attribute \DesignAttr:ENABLE_AIE_NETLIST_VIEW\ : boolean;
  attribute \DesignAttr:ENABLE_AIE_NETLIST_VIEW\ of circuito : entity is std.standard.true;
  attribute \DesignAttr:ENABLE_NOC_NETLIST_VIEW\ : boolean;
  attribute \DesignAttr:ENABLE_NOC_NETLIST_VIEW\ of circuito : entity is std.standard.true;
  attribute ECO_CHECKSUM : string;
  attribute ECO_CHECKSUM of circuito : entity is "53b3dc98";
  attribute POWER_OPT_BRAM_CDC : integer;
  attribute POWER_OPT_BRAM_CDC of circuito : entity is 0;
  attribute POWER_OPT_BRAM_SR_ADDR : integer;
  attribute POWER_OPT_BRAM_SR_ADDR of circuito : entity is 0;
  attribute POWER_OPT_LOOPED_NET_PERCENTAGE : integer;
  attribute POWER_OPT_LOOPED_NET_PERCENTAGE of circuito : entity is 0;
end circuito;

architecture STRUCTURE of circuito is
  signal A : STD_LOGIC_VECTOR ( 7 downto 1 );
  signal A0 : STD_LOGIC_VECTOR ( 1 to 1 );
  signal A1 : STD_LOGIC_VECTOR ( 1 to 1 );
  signal A2 : STD_LOGIC_VECTOR ( 1 to 1 );
  signal A3 : STD_LOGIC_VECTOR ( 1 to 1 );
  signal B : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal B0 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal B1 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal B2 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal B3 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal DataOut_OBUF : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal RSTP : STD_LOGIC;
  signal addr_omemc_OBUF : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal clk_IBUF : STD_LOGIC;
  signal clk_IBUF_BUFG : STD_LOGIC;
  signal dataIN : STD_LOGIC_VECTOR ( 20 downto 0 );
  signal done_OBUF : STD_LOGIC;
  signal input_addr : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal inst_control_n_20 : STD_LOGIC;
  signal inst_control_n_21 : STD_LOGIC;
  signal inst_control_n_22 : STD_LOGIC;
  signal inst_datapath_n_0 : STD_LOGIC;
  signal inst_datapath_n_1 : STD_LOGIC;
  signal inst_datapath_n_10 : STD_LOGIC;
  signal inst_datapath_n_11 : STD_LOGIC;
  signal inst_datapath_n_12 : STD_LOGIC;
  signal inst_datapath_n_13 : STD_LOGIC;
  signal inst_datapath_n_2 : STD_LOGIC;
  signal inst_datapath_n_3 : STD_LOGIC;
  signal inst_datapath_n_4 : STD_LOGIC;
  signal inst_datapath_n_5 : STD_LOGIC;
  signal inst_datapath_n_6 : STD_LOGIC;
  signal inst_datapath_n_7 : STD_LOGIC;
  signal inst_datapath_n_8 : STD_LOGIC;
  signal inst_datapath_n_9 : STD_LOGIC;
  signal inst_imemb_n_32 : STD_LOGIC;
  signal inst_imemb_n_33 : STD_LOGIC;
  signal inst_imemb_n_34 : STD_LOGIC;
  signal inst_imemb_n_35 : STD_LOGIC;
  signal inst_imemb_n_36 : STD_LOGIC;
  signal inst_imemb_n_37 : STD_LOGIC;
  signal inst_imemb_n_46 : STD_LOGIC;
  signal inst_imemb_n_47 : STD_LOGIC;
  signal inst_imemb_n_48 : STD_LOGIC;
  signal inst_imemb_n_49 : STD_LOGIC;
  signal inst_imemb_n_50 : STD_LOGIC;
  signal inst_imemb_n_51 : STD_LOGIC;
  signal inst_imemb_n_52 : STD_LOGIC;
  signal inst_imemb_n_53 : STD_LOGIC;
  signal inst_imemb_n_54 : STD_LOGIC;
  signal inst_imemb_n_55 : STD_LOGIC;
  signal inst_imemb_n_56 : STD_LOGIC;
  signal inst_imemb_n_57 : STD_LOGIC;
  signal inst_imemb_n_58 : STD_LOGIC;
  signal inst_imemb_n_59 : STD_LOGIC;
  signal inst_imemb_n_60 : STD_LOGIC;
  signal inst_imemb_n_61 : STD_LOGIC;
  signal inst_imemb_n_62 : STD_LOGIC;
  signal inst_imemb_n_63 : STD_LOGIC;
  signal inst_imemb_n_64 : STD_LOGIC;
  signal inst_imemb_n_65 : STD_LOGIC;
  signal inst_imemb_n_66 : STD_LOGIC;
  signal inst_imemb_n_67 : STD_LOGIC;
  signal inst_imemb_n_68 : STD_LOGIC;
  signal inst_imemb_n_69 : STD_LOGIC;
  signal inst_imemb_n_70 : STD_LOGIC;
  signal inst_imemb_n_71 : STD_LOGIC;
  signal inst_imemb_n_72 : STD_LOGIC;
  signal inst_imemb_n_73 : STD_LOGIC;
  signal inst_imemb_n_74 : STD_LOGIC;
  signal inst_imemb_n_75 : STD_LOGIC;
  signal inst_imemb_n_76 : STD_LOGIC;
  signal inst_imemb_n_77 : STD_LOGIC;
  signal inst_imemb_n_78 : STD_LOGIC;
  signal inst_imemb_n_79 : STD_LOGIC;
  signal inst_imemb_n_80 : STD_LOGIC;
  signal inst_imemb_n_81 : STD_LOGIC;
  signal inst_imemb_n_82 : STD_LOGIC;
  signal inst_imemb_n_83 : STD_LOGIC;
  signal inst_imemb_n_84 : STD_LOGIC;
  signal inst_imemb_n_85 : STD_LOGIC;
  signal inst_imemb_n_86 : STD_LOGIC;
  signal inst_imemb_n_87 : STD_LOGIC;
  signal inst_imemb_n_88 : STD_LOGIC;
  signal inst_imemb_n_89 : STD_LOGIC;
  signal inst_imemb_n_90 : STD_LOGIC;
  signal inst_imemb_n_91 : STD_LOGIC;
  signal inst_imemb_n_92 : STD_LOGIC;
  signal inst_imemb_n_93 : STD_LOGIC;
  signal inst_imemb_n_94 : STD_LOGIC;
  signal inst_imemb_n_95 : STD_LOGIC;
  signal inst_imemb_n_96 : STD_LOGIC;
  signal inst_imemb_n_97 : STD_LOGIC;
  signal inst_imemb_n_98 : STD_LOGIC;
  signal inst_imemb_n_99 : STD_LOGIC;
  signal inst_wmema_n_14 : STD_LOGIC;
  signal inst_wmema_n_15 : STD_LOGIC;
  signal inst_wmema_n_16 : STD_LOGIC;
  signal inst_wmema_n_17 : STD_LOGIC;
  signal inst_wmema_n_18 : STD_LOGIC;
  signal inst_wmema_n_19 : STD_LOGIC;
  signal inst_wmema_n_20 : STD_LOGIC;
  signal inst_wmema_n_21 : STD_LOGIC;
  signal inst_wmema_n_22 : STD_LOGIC;
  signal inst_wmema_n_23 : STD_LOGIC;
  signal inst_wmema_n_24 : STD_LOGIC;
  signal inst_wmema_n_25 : STD_LOGIC;
  signal inst_wmema_n_26 : STD_LOGIC;
  signal inst_wmema_n_27 : STD_LOGIC;
  signal inst_wmema_n_28 : STD_LOGIC;
  signal inst_wmema_n_29 : STD_LOGIC;
  signal inst_wmema_n_30 : STD_LOGIC;
  signal inst_wmema_n_31 : STD_LOGIC;
  signal inst_wmema_n_32 : STD_LOGIC;
  signal inst_wmema_n_33 : STD_LOGIC;
  signal inst_wmema_n_34 : STD_LOGIC;
  signal inst_wmema_n_35 : STD_LOGIC;
  signal inst_wmema_n_36 : STD_LOGIC;
  signal inst_wmema_n_37 : STD_LOGIC;
  signal inst_wmema_n_38 : STD_LOGIC;
  signal inst_wmema_n_39 : STD_LOGIC;
  signal inst_wmema_n_4 : STD_LOGIC;
  signal inst_wmema_n_40 : STD_LOGIC;
  signal inst_wmema_n_41 : STD_LOGIC;
  signal inst_wmema_n_42 : STD_LOGIC;
  signal inst_wmema_n_43 : STD_LOGIC;
  signal inst_wmema_n_44 : STD_LOGIC;
  signal inst_wmema_n_45 : STD_LOGIC;
  signal inst_wmema_n_46 : STD_LOGIC;
  signal inst_wmema_n_47 : STD_LOGIC;
  signal inst_wmema_n_48 : STD_LOGIC;
  signal inst_wmema_n_49 : STD_LOGIC;
  signal inst_wmema_n_5 : STD_LOGIC;
  signal inst_wmema_n_50 : STD_LOGIC;
  signal inst_wmema_n_51 : STD_LOGIC;
  signal inst_wmema_n_52 : STD_LOGIC;
  signal inst_wmema_n_53 : STD_LOGIC;
  signal inst_wmema_n_54 : STD_LOGIC;
  signal inst_wmema_n_55 : STD_LOGIC;
  signal inst_wmema_n_56 : STD_LOGIC;
  signal inst_wmema_n_57 : STD_LOGIC;
  signal inst_wmema_n_58 : STD_LOGIC;
  signal inst_wmema_n_59 : STD_LOGIC;
  signal inst_wmema_n_6 : STD_LOGIC;
  signal inst_wmema_n_60 : STD_LOGIC;
  signal inst_wmema_n_61 : STD_LOGIC;
  signal inst_wmema_n_62 : STD_LOGIC;
  signal inst_wmema_n_63 : STD_LOGIC;
  signal inst_wmema_n_64 : STD_LOGIC;
  signal inst_wmema_n_65 : STD_LOGIC;
  signal inst_wmema_n_66 : STD_LOGIC;
  signal inst_wmema_n_67 : STD_LOGIC;
  signal inst_wmema_n_68 : STD_LOGIC;
  signal inst_wmema_n_69 : STD_LOGIC;
  signal inst_wmema_n_70 : STD_LOGIC;
  signal inst_wmema_n_71 : STD_LOGIC;
  signal inst_wmema_n_72 : STD_LOGIC;
  signal inst_wmema_n_73 : STD_LOGIC;
  signal inst_wmema_n_74 : STD_LOGIC;
  signal inst_wmema_n_75 : STD_LOGIC;
  signal inst_wmema_n_76 : STD_LOGIC;
  signal inst_wmema_n_77 : STD_LOGIC;
  signal inst_wmema_n_78 : STD_LOGIC;
  signal inst_wmema_n_79 : STD_LOGIC;
  signal inst_wmema_n_80 : STD_LOGIC;
  signal inst_wmema_n_81 : STD_LOGIC;
  signal inst_wmema_n_82 : STD_LOGIC;
  signal inst_wmema_n_83 : STD_LOGIC;
  signal inst_wmema_n_84 : STD_LOGIC;
  signal inst_wmema_n_85 : STD_LOGIC;
  signal inst_wmema_n_86 : STD_LOGIC;
  signal inst_wmema_n_87 : STD_LOGIC;
  signal inst_wmema_n_88 : STD_LOGIC;
  signal inst_wmema_n_89 : STD_LOGIC;
  signal pwropt : STD_LOGIC;
  signal pwropt_1 : STD_LOGIC;
  signal reg_weight_addr : STD_LOGIC_VECTOR ( 0 to 0 );
  signal rst_IBUF : STD_LOGIC;
  signal we_OBUF : STD_LOGIC;
  signal weight_addr : STD_LOGIC_VECTOR ( 7 downto 0 );
  attribute SPLIT_LOADS_ON_BUFG : boolean;
  attribute SPLIT_LOADS_ON_BUFG of clk_IBUF_BUFG_inst : label is std.standard.true;
begin
\DataOut_OBUF[0]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(0),
      O => DataOut(0)
    );
\DataOut_OBUF[10]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(10),
      O => DataOut(10)
    );
\DataOut_OBUF[11]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(11),
      O => DataOut(11)
    );
\DataOut_OBUF[12]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(12),
      O => DataOut(12)
    );
\DataOut_OBUF[13]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(13),
      O => DataOut(13)
    );
\DataOut_OBUF[14]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(14),
      O => DataOut(14)
    );
\DataOut_OBUF[15]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(15),
      O => DataOut(15)
    );
\DataOut_OBUF[16]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(16),
      O => DataOut(16)
    );
\DataOut_OBUF[17]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(17),
      O => DataOut(17)
    );
\DataOut_OBUF[18]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(18),
      O => DataOut(18)
    );
\DataOut_OBUF[19]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(19),
      O => DataOut(19)
    );
\DataOut_OBUF[1]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(1),
      O => DataOut(1)
    );
\DataOut_OBUF[20]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(20),
      O => DataOut(20)
    );
\DataOut_OBUF[21]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(21),
      O => DataOut(21)
    );
\DataOut_OBUF[22]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(22),
      O => DataOut(22)
    );
\DataOut_OBUF[23]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(23),
      O => DataOut(23)
    );
\DataOut_OBUF[24]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(24),
      O => DataOut(24)
    );
\DataOut_OBUF[25]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(25),
      O => DataOut(25)
    );
\DataOut_OBUF[26]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(26),
      O => DataOut(26)
    );
\DataOut_OBUF[27]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(27),
      O => DataOut(27)
    );
\DataOut_OBUF[28]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(28),
      O => DataOut(28)
    );
\DataOut_OBUF[29]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(29),
      O => DataOut(29)
    );
\DataOut_OBUF[2]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(2),
      O => DataOut(2)
    );
\DataOut_OBUF[30]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(30),
      O => DataOut(30)
    );
\DataOut_OBUF[31]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(31),
      O => DataOut(31)
    );
\DataOut_OBUF[3]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(3),
      O => DataOut(3)
    );
\DataOut_OBUF[4]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(4),
      O => DataOut(4)
    );
\DataOut_OBUF[5]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(5),
      O => DataOut(5)
    );
\DataOut_OBUF[6]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(6),
      O => DataOut(6)
    );
\DataOut_OBUF[7]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(7),
      O => DataOut(7)
    );
\DataOut_OBUF[8]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(8),
      O => DataOut(8)
    );
\DataOut_OBUF[9]_inst\: unisim.vcomponents.OBUF
     port map (
      I => DataOut_OBUF(9),
      O => DataOut(9)
    );
\addr_omemc_OBUF[0]_inst\: unisim.vcomponents.OBUF
     port map (
      I => addr_omemc_OBUF(0),
      O => addr_omemc(0)
    );
\addr_omemc_OBUF[1]_inst\: unisim.vcomponents.OBUF
     port map (
      I => addr_omemc_OBUF(1),
      O => addr_omemc(1)
    );
\addr_omemc_OBUF[2]_inst\: unisim.vcomponents.OBUF
     port map (
      I => addr_omemc_OBUF(2),
      O => addr_omemc(2)
    );
\addr_omemc_OBUF[3]_inst\: unisim.vcomponents.OBUF
     port map (
      I => addr_omemc_OBUF(3),
      O => addr_omemc(3)
    );
\addr_omemc_OBUF[4]_inst\: unisim.vcomponents.OBUF
     port map (
      I => '0',
      O => addr_omemc(4)
    );
\addr_omemc_OBUF[5]_inst\: unisim.vcomponents.OBUF
     port map (
      I => '0',
      O => addr_omemc(5)
    );
\addr_omemc_OBUF[6]_inst\: unisim.vcomponents.OBUF
     port map (
      I => '0',
      O => addr_omemc(6)
    );
\addr_omemc_OBUF[7]_inst\: unisim.vcomponents.OBUF
     port map (
      I => '0',
      O => addr_omemc(7)
    );
\addr_omemc_OBUF[8]_inst\: unisim.vcomponents.OBUF
     port map (
      I => '0',
      O => addr_omemc(8)
    );
\addr_omemc_OBUF[9]_inst\: unisim.vcomponents.OBUF
     port map (
      I => '0',
      O => addr_omemc(9)
    );
clk_IBUF_BUFG_inst: unisim.vcomponents.BUFG
     port map (
      I => clk_IBUF,
      O => clk_IBUF_BUFG
    );
clk_IBUF_inst: unisim.vcomponents.IBUF
     port map (
      I => clk,
      O => clk_IBUF
    );
done_OBUF_inst: unisim.vcomponents.OBUF
     port map (
      I => done_OBUF,
      O => done
    );
inst_control: entity work.control_unit
     port map (
      CLK => clk_IBUF_BUFG,
      E(0) => inst_control_n_21,
      \FSM_onehot_state_reg[1]_0\ => inst_control_n_20,
      \FSM_onehot_state_reg[2]_0\(0) => inst_control_n_22,
      Q(1) => done_OBUF,
      Q(0) => reg_weight_addr(0),
      SR(0) => RSTP,
      WEA(0) => we_OBUF,
      pwropt => pwropt,
      \reg_input_addr_reg[3]_0\(3 downto 0) => input_addr(3 downto 0),
      \reg_output_addr_reg[3]_0\(3 downto 0) => addr_omemc_OBUF(3 downto 0),
      \reg_weight_addr_reg[7]_0\(7 downto 0) => weight_addr(7 downto 0),
      rst_IBUF => rst_IBUF
    );
inst_datapath: entity work.datapath
     port map (
      CLK => clk_IBUF_BUFG,
      CO(0) => inst_datapath_n_0,
      DI(2) => inst_imemb_n_32,
      DI(1) => inst_wmema_n_28,
      DI(0) => inst_imemb_n_33,
      DIADI(20 downto 0) => dataIN(20 downto 0),
      E(0) => inst_control_n_21,
      \MUL1_OUT__85_carry__0_i_3_0\(1) => inst_wmema_n_59,
      \MUL1_OUT__85_carry__0_i_3_0\(0) => inst_imemb_n_46,
      \MUL1_OUT__85_carry__0_i_3_1\(1) => inst_imemb_n_83,
      \MUL1_OUT__85_carry__0_i_3_1\(0) => inst_imemb_n_84,
      \MUL1_OUT__85_carry__0_i_4_0\(3) => inst_imemb_n_49,
      \MUL1_OUT__85_carry__0_i_4_0\(2) => inst_imemb_n_50,
      \MUL1_OUT__85_carry__0_i_4_0\(1) => inst_imemb_n_51,
      \MUL1_OUT__85_carry__0_i_4_0\(0) => inst_imemb_n_52,
      \MUL1_OUT__85_carry__0_i_4_1\(3) => inst_imemb_n_85,
      \MUL1_OUT__85_carry__0_i_4_1\(2) => inst_wmema_n_60,
      \MUL1_OUT__85_carry__0_i_4_1\(1) => inst_wmema_n_61,
      \MUL1_OUT__85_carry__0_i_4_1\(0) => inst_wmema_n_62,
      \MUL1_OUT__85_carry__0_i_6_0\(3) => inst_wmema_n_68,
      \MUL1_OUT__85_carry__0_i_6_0\(2) => inst_wmema_n_69,
      \MUL1_OUT__85_carry__0_i_6_0\(1) => inst_wmema_n_70,
      \MUL1_OUT__85_carry__0_i_6_0\(0) => inst_wmema_n_71,
      \MUL1_OUT__85_carry__0_i_6_1\(3) => inst_wmema_n_30,
      \MUL1_OUT__85_carry__0_i_6_1\(2) => inst_wmema_n_31,
      \MUL1_OUT__85_carry__0_i_6_1\(1) => inst_wmema_n_32,
      \MUL1_OUT__85_carry__0_i_6_1\(0) => inst_wmema_n_33,
      \MUL1_OUT__85_carry__1_i_5\(1) => inst_wmema_n_63,
      \MUL1_OUT__85_carry__1_i_5\(0) => inst_imemb_n_53,
      \MUL1_OUT__85_carry__1_i_5_0\(1) => inst_imemb_n_86,
      \MUL1_OUT__85_carry__1_i_5_0\(0) => inst_imemb_n_87,
      \MUL1_OUT__85_carry_i_1_0\(2) => inst_wmema_n_14,
      \MUL1_OUT__85_carry_i_1_0\(1) => inst_imemb_n_54,
      \MUL1_OUT__85_carry_i_1_0\(0) => inst_wmema_n_15,
      \MUL1_OUT__85_carry_i_1_1\(3) => inst_wmema_n_64,
      \MUL1_OUT__85_carry_i_1_1\(2) => inst_wmema_n_65,
      \MUL1_OUT__85_carry_i_1_1\(1) => inst_wmema_n_66,
      \MUL1_OUT__85_carry_i_1_1\(0) => inst_wmema_n_67,
      \MUL1_OUT__85_carry_i_8_0\(3) => inst_imemb_n_34,
      \MUL1_OUT__85_carry_i_8_0\(2) => inst_imemb_n_35,
      \MUL1_OUT__85_carry_i_8_0\(1) => inst_imemb_n_36,
      \MUL1_OUT__85_carry_i_8_0\(0) => inst_imemb_n_37,
      \MUL1_OUT__85_carry_i_8_1\(3) => inst_imemb_n_82,
      \MUL1_OUT__85_carry_i_8_1\(2) => inst_wmema_n_56,
      \MUL1_OUT__85_carry_i_8_1\(1) => inst_wmema_n_57,
      \MUL1_OUT__85_carry_i_8_1\(0) => inst_wmema_n_58,
      \MUL2_OUT__85_carry__0_i_3_0\(1) => inst_wmema_n_76,
      \MUL2_OUT__85_carry__0_i_3_0\(0) => inst_imemb_n_66,
      \MUL2_OUT__85_carry__0_i_3_1\(1) => inst_imemb_n_89,
      \MUL2_OUT__85_carry__0_i_3_1\(0) => inst_imemb_n_90,
      \MUL2_OUT__85_carry__0_i_4_0\(3) => inst_imemb_n_69,
      \MUL2_OUT__85_carry__0_i_4_0\(2) => inst_imemb_n_70,
      \MUL2_OUT__85_carry__0_i_4_0\(1) => inst_imemb_n_71,
      \MUL2_OUT__85_carry__0_i_4_0\(0) => inst_imemb_n_72,
      \MUL2_OUT__85_carry__0_i_4_1\(3) => inst_imemb_n_91,
      \MUL2_OUT__85_carry__0_i_4_1\(2) => inst_wmema_n_77,
      \MUL2_OUT__85_carry__0_i_4_1\(1) => inst_wmema_n_78,
      \MUL2_OUT__85_carry__0_i_4_1\(0) => inst_wmema_n_79,
      \MUL2_OUT__85_carry__0_i_6_0\(3) => inst_wmema_n_85,
      \MUL2_OUT__85_carry__0_i_6_0\(2) => inst_wmema_n_86,
      \MUL2_OUT__85_carry__0_i_6_0\(1) => inst_wmema_n_87,
      \MUL2_OUT__85_carry__0_i_6_0\(0) => inst_wmema_n_88,
      \MUL2_OUT__85_carry__0_i_6_1\(3) => inst_wmema_n_36,
      \MUL2_OUT__85_carry__0_i_6_1\(2) => inst_wmema_n_37,
      \MUL2_OUT__85_carry__0_i_6_1\(1) => inst_wmema_n_38,
      \MUL2_OUT__85_carry__0_i_6_1\(0) => inst_wmema_n_39,
      \MUL2_OUT__85_carry__1_i_5\(1) => inst_wmema_n_80,
      \MUL2_OUT__85_carry__1_i_5\(0) => inst_imemb_n_76,
      \MUL2_OUT__85_carry__1_i_5_0\(1) => inst_imemb_n_92,
      \MUL2_OUT__85_carry__1_i_5_0\(0) => inst_imemb_n_93,
      \MUL2_OUT__85_carry_i_1_0\(2) => inst_wmema_n_20,
      \MUL2_OUT__85_carry_i_1_0\(1) => inst_imemb_n_77,
      \MUL2_OUT__85_carry_i_1_0\(0) => inst_wmema_n_21,
      \MUL2_OUT__85_carry_i_1_1\(3) => inst_wmema_n_81,
      \MUL2_OUT__85_carry_i_1_1\(2) => inst_wmema_n_82,
      \MUL2_OUT__85_carry_i_1_1\(1) => inst_wmema_n_83,
      \MUL2_OUT__85_carry_i_1_1\(0) => inst_wmema_n_84,
      \MUL2_OUT__85_carry_i_8_0\(3) => inst_imemb_n_59,
      \MUL2_OUT__85_carry_i_8_0\(2) => inst_imemb_n_60,
      \MUL2_OUT__85_carry_i_8_0\(1) => inst_imemb_n_61,
      \MUL2_OUT__85_carry_i_8_0\(0) => inst_imemb_n_62,
      \MUL2_OUT__85_carry_i_8_1\(3) => inst_imemb_n_88,
      \MUL2_OUT__85_carry_i_8_1\(2) => inst_wmema_n_73,
      \MUL2_OUT__85_carry_i_8_1\(1) => inst_wmema_n_74,
      \MUL2_OUT__85_carry_i_8_1\(0) => inst_wmema_n_75,
      O(1) => inst_datapath_n_1,
      O(0) => inst_datapath_n_2,
      \REG1_reg[15]_0\(0) => inst_wmema_n_6,
      \REG1_reg[15]_1\(0) => inst_wmema_n_72,
      \REG1_reg[15]_2\(1) => inst_imemb_n_55,
      \REG1_reg[15]_2\(0) => inst_imemb_n_56,
      \REG1_reg[15]_3\(2) => inst_imemb_n_94,
      \REG1_reg[15]_3\(1) => inst_imemb_n_95,
      \REG1_reg[15]_3\(0) => inst_imemb_n_96,
      \REG1_reg[3]_0\(2) => inst_imemb_n_47,
      \REG1_reg[3]_0\(1) => inst_wmema_n_29,
      \REG1_reg[3]_0\(0) => inst_imemb_n_48,
      \REG1_reg[3]_1\(3) => inst_wmema_n_44,
      \REG1_reg[3]_1\(2) => inst_wmema_n_45,
      \REG1_reg[3]_1\(1) => inst_wmema_n_46,
      \REG1_reg[3]_1\(0) => inst_wmema_n_47,
      \REG2_reg[15]_0\(0) => inst_wmema_n_18,
      \REG2_reg[15]_1\(0) => inst_wmema_n_89,
      \REG2_reg[15]_2\(1) => inst_imemb_n_78,
      \REG2_reg[15]_2\(0) => inst_imemb_n_79,
      \REG2_reg[15]_3\(2) => inst_imemb_n_97,
      \REG2_reg[15]_3\(1) => inst_imemb_n_98,
      \REG2_reg[15]_3\(0) => inst_imemb_n_99,
      \REG2_reg[2]_0\(2) => inst_imemb_n_57,
      \REG2_reg[2]_0\(1) => inst_wmema_n_34,
      \REG2_reg[2]_0\(0) => inst_imemb_n_58,
      \REG2_reg[2]_1\(3) => inst_wmema_n_48,
      \REG2_reg[2]_1\(2) => inst_wmema_n_49,
      \REG2_reg[2]_1\(1) => inst_wmema_n_50,
      \REG2_reg[2]_1\(0) => inst_wmema_n_51,
      \REG2_reg[3]_0\(2) => inst_imemb_n_67,
      \REG2_reg[3]_0\(1) => inst_wmema_n_35,
      \REG2_reg[3]_0\(0) => inst_imemb_n_68,
      \REG2_reg[3]_1\(3) => inst_wmema_n_52,
      \REG2_reg[3]_1\(2) => inst_wmema_n_53,
      \REG2_reg[3]_1\(1) => inst_wmema_n_54,
      \REG2_reg[3]_1\(0) => inst_wmema_n_55,
      \REG_ACCUM_reg[0]_0\(0) => inst_control_n_22,
      S(3) => inst_wmema_n_40,
      S(2) => inst_wmema_n_41,
      S(1) => inst_wmema_n_42,
      S(0) => inst_wmema_n_43,
      SR(0) => RSTP,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(2) => inst_datapath_n_3,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(1) => inst_datapath_n_4,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(0) => inst_datapath_n_5,
      \ramb_bl.ramb36_sin_bl.ram36_bl_0\(0) => inst_datapath_n_6,
      \ramb_bl.ramb36_sin_bl.ram36_bl_1\(0) => inst_datapath_n_7,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(1) => inst_datapath_n_8,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(0) => inst_datapath_n_9,
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\(2) => inst_datapath_n_10,
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\(1) => inst_datapath_n_11,
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\(0) => inst_datapath_n_12,
      \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0) => inst_datapath_n_13,
      rst_IBUF => rst_IBUF
    );
inst_imemb: entity work.IMemB
     port map (
      A(6 downto 0) => A(7 downto 1),
      B(7 downto 0) => B(7 downto 0),
      CLK => clk_IBUF_BUFG,
      CO(0) => inst_datapath_n_0,
      DI(1) => inst_imemb_n_32,
      DI(0) => inst_imemb_n_33,
      DOADO(31 downto 24) => B3(7 downto 0),
      DOADO(23 downto 16) => B2(7 downto 0),
      DOADO(15 downto 8) => B1(7 downto 0),
      DOADO(7 downto 0) => B0(7 downto 0),
      \MUL1_OUT__0_carry__0\ => inst_wmema_n_4,
      \MUL1_OUT__0_carry__1\ => inst_control_n_20,
      \MUL1_OUT__30_carry__0\ => inst_wmema_n_5,
      \MUL1_OUT__59_carry__0\(1) => inst_imemb_n_55,
      \MUL1_OUT__59_carry__0\(0) => inst_imemb_n_56,
      \MUL1_OUT__59_carry__1\(2) => inst_imemb_n_94,
      \MUL1_OUT__59_carry__1\(1) => inst_imemb_n_95,
      \MUL1_OUT__59_carry__1\(0) => inst_imemb_n_96,
      \MUL2_OUT__0_carry__0\ => inst_wmema_n_25,
      \MUL2_OUT__0_carry__0_0\ => inst_wmema_n_26,
      \MUL2_OUT__0_carry__0_1\ => inst_wmema_n_27,
      \MUL2_OUT__0_carry__0_2\ => inst_wmema_n_19,
      \MUL2_OUT__0_carry__0_3\ => inst_wmema_n_16,
      \MUL2_OUT__30_carry__0\ => inst_wmema_n_17,
      \MUL2_OUT__59_carry__0\(1) => inst_imemb_n_78,
      \MUL2_OUT__59_carry__0\(0) => inst_imemb_n_79,
      \MUL2_OUT__59_carry__1\(2) => inst_imemb_n_97,
      \MUL2_OUT__59_carry__1\(1) => inst_imemb_n_98,
      \MUL2_OUT__59_carry__1\(0) => inst_imemb_n_99,
      O(1) => inst_datapath_n_1,
      O(0) => inst_datapath_n_2,
      Q(0) => reg_weight_addr(0),
      \REG1_reg[15]\(2) => inst_datapath_n_3,
      \REG1_reg[15]\(1) => inst_datapath_n_4,
      \REG1_reg[15]\(0) => inst_datapath_n_5,
      \REG1_reg[15]_0\(0) => inst_datapath_n_6,
      \REG2_reg[15]\(1) => inst_datapath_n_8,
      \REG2_reg[15]\(0) => inst_datapath_n_9,
      \REG2_reg[15]_0\(2) => inst_datapath_n_10,
      \REG2_reg[15]_0\(1) => inst_datapath_n_11,
      \REG2_reg[15]_0\(0) => inst_datapath_n_12,
      \REG2_reg[15]_1\(0) => inst_datapath_n_7,
      \REG2_reg[15]_2\(0) => inst_datapath_n_13,
      \REG2_reg[2]\(3) => A3(1),
      \REG2_reg[2]\(2) => A2(1),
      \REG2_reg[2]\(1) => A1(1),
      \REG2_reg[2]\(0) => A0(1),
      \REG2_reg[2]_0\ => inst_wmema_n_22,
      \REG2_reg[2]_1\ => inst_wmema_n_23,
      \REG2_reg[2]_2\ => inst_wmema_n_24,
      pwropt => pwropt,
      pwropt_1 => pwropt_1,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(3) => inst_imemb_n_34,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(2) => inst_imemb_n_35,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(1) => inst_imemb_n_36,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(0) => inst_imemb_n_37,
      \ramb_bl.ramb36_sin_bl.ram36_bl_0\(0) => inst_imemb_n_46,
      \ramb_bl.ramb36_sin_bl.ram36_bl_1\(1) => inst_imemb_n_47,
      \ramb_bl.ramb36_sin_bl.ram36_bl_1\(0) => inst_imemb_n_48,
      \ramb_bl.ramb36_sin_bl.ram36_bl_10\(0) => inst_imemb_n_66,
      \ramb_bl.ramb36_sin_bl.ram36_bl_11\(1) => inst_imemb_n_67,
      \ramb_bl.ramb36_sin_bl.ram36_bl_11\(0) => inst_imemb_n_68,
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\(3) => inst_imemb_n_69,
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\(2) => inst_imemb_n_70,
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\(1) => inst_imemb_n_71,
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\(0) => inst_imemb_n_72,
      \ramb_bl.ramb36_sin_bl.ram36_bl_13\ => inst_imemb_n_73,
      \ramb_bl.ramb36_sin_bl.ram36_bl_14\ => inst_imemb_n_74,
      \ramb_bl.ramb36_sin_bl.ram36_bl_15\ => inst_imemb_n_75,
      \ramb_bl.ramb36_sin_bl.ram36_bl_16\(0) => inst_imemb_n_76,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\(0) => inst_imemb_n_77,
      \ramb_bl.ramb36_sin_bl.ram36_bl_18\ => inst_imemb_n_80,
      \ramb_bl.ramb36_sin_bl.ram36_bl_19\ => inst_imemb_n_81,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(3) => inst_imemb_n_49,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(2) => inst_imemb_n_50,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(1) => inst_imemb_n_51,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(0) => inst_imemb_n_52,
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\(0) => inst_imemb_n_82,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\(1) => inst_imemb_n_83,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\(0) => inst_imemb_n_84,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\(0) => inst_imemb_n_85,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(1) => inst_imemb_n_86,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(0) => inst_imemb_n_87,
      \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0) => inst_imemb_n_88,
      \ramb_bl.ramb36_sin_bl.ram36_bl_25\(1) => inst_imemb_n_89,
      \ramb_bl.ramb36_sin_bl.ram36_bl_25\(0) => inst_imemb_n_90,
      \ramb_bl.ramb36_sin_bl.ram36_bl_26\(0) => inst_imemb_n_91,
      \ramb_bl.ramb36_sin_bl.ram36_bl_27\(1) => inst_imemb_n_92,
      \ramb_bl.ramb36_sin_bl.ram36_bl_27\(0) => inst_imemb_n_93,
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(3 downto 0) => input_addr(3 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\(0) => inst_imemb_n_53,
      \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0) => inst_imemb_n_54,
      \ramb_bl.ramb36_sin_bl.ram36_bl_5\(1) => inst_imemb_n_57,
      \ramb_bl.ramb36_sin_bl.ram36_bl_5\(0) => inst_imemb_n_58,
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\(3) => inst_imemb_n_59,
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\(2) => inst_imemb_n_60,
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\(1) => inst_imemb_n_61,
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\(0) => inst_imemb_n_62,
      \ramb_bl.ramb36_sin_bl.ram36_bl_7\ => inst_imemb_n_63,
      \ramb_bl.ramb36_sin_bl.ram36_bl_8\ => inst_imemb_n_64,
      \ramb_bl.ramb36_sin_bl.ram36_bl_9\ => inst_imemb_n_65,
      rst_IBUF => rst_IBUF
    );
inst_omemc: entity work.OMemC
     port map (
      CLK => clk_IBUF_BUFG,
      DIADI(20 downto 0) => dataIN(20 downto 0),
      DOADO(31 downto 0) => DataOut_OBUF(31 downto 0),
      WEA(0) => we_OBUF,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(3 downto 0) => addr_omemc_OBUF(3 downto 0)
    );
inst_wmema: entity work.WMemA
     port map (
      B(7 downto 0) => B(7 downto 0),
      CLK => clk_IBUF_BUFG,
      DI(0) => inst_wmema_n_28,
      DOADO(31 downto 24) => B3(7 downto 0),
      DOADO(23 downto 16) => B2(7 downto 0),
      DOADO(15 downto 8) => B1(7 downto 0),
      DOADO(7 downto 0) => B0(7 downto 0),
      \MUL2_OUT__30_carry\ => inst_imemb_n_74,
      \MUL2_OUT__30_carry_0\ => inst_imemb_n_73,
      \MUL2_OUT__30_carry_1\ => inst_imemb_n_75,
      \MUL2_OUT__59_carry__0\ => inst_imemb_n_81,
      \MUL2_OUT__59_carry__0_0\ => inst_imemb_n_80,
      Q(0) => reg_weight_addr(0),
      \REG2_reg[2]\ => inst_control_n_20,
      \REG2_reg[2]_0\ => inst_imemb_n_64,
      \REG2_reg[2]_1\ => inst_imemb_n_63,
      \REG2_reg[2]_2\ => inst_imemb_n_65,
      S(3) => inst_wmema_n_40,
      S(2) => inst_wmema_n_41,
      S(1) => inst_wmema_n_42,
      S(0) => inst_wmema_n_43,
      pwropt => pwropt_1,
      \ramb_bl.ramb36_sin_bl.ram36_bl\(3) => A3(1),
      \ramb_bl.ramb36_sin_bl.ram36_bl\(2) => A2(1),
      \ramb_bl.ramb36_sin_bl.ram36_bl\(1) => A1(1),
      \ramb_bl.ramb36_sin_bl.ram36_bl\(0) => A0(1),
      \ramb_bl.ramb36_sin_bl.ram36_bl_0\ => inst_wmema_n_4,
      \ramb_bl.ramb36_sin_bl.ram36_bl_1\ => inst_wmema_n_5,
      \ramb_bl.ramb36_sin_bl.ram36_bl_10\ => inst_wmema_n_22,
      \ramb_bl.ramb36_sin_bl.ram36_bl_11\ => inst_wmema_n_23,
      \ramb_bl.ramb36_sin_bl.ram36_bl_12\ => inst_wmema_n_24,
      \ramb_bl.ramb36_sin_bl.ram36_bl_13\ => inst_wmema_n_25,
      \ramb_bl.ramb36_sin_bl.ram36_bl_14\ => inst_wmema_n_26,
      \ramb_bl.ramb36_sin_bl.ram36_bl_15\ => inst_wmema_n_27,
      \ramb_bl.ramb36_sin_bl.ram36_bl_16\(0) => inst_wmema_n_29,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\(3) => inst_wmema_n_30,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\(2) => inst_wmema_n_31,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\(1) => inst_wmema_n_32,
      \ramb_bl.ramb36_sin_bl.ram36_bl_17\(0) => inst_wmema_n_33,
      \ramb_bl.ramb36_sin_bl.ram36_bl_18\(0) => inst_wmema_n_34,
      \ramb_bl.ramb36_sin_bl.ram36_bl_19\(0) => inst_wmema_n_35,
      \ramb_bl.ramb36_sin_bl.ram36_bl_2\(0) => inst_wmema_n_6,
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\(3) => inst_wmema_n_36,
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\(2) => inst_wmema_n_37,
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\(1) => inst_wmema_n_38,
      \ramb_bl.ramb36_sin_bl.ram36_bl_20\(0) => inst_wmema_n_39,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\(3) => inst_wmema_n_44,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\(2) => inst_wmema_n_45,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\(1) => inst_wmema_n_46,
      \ramb_bl.ramb36_sin_bl.ram36_bl_21\(0) => inst_wmema_n_47,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\(3) => inst_wmema_n_48,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\(2) => inst_wmema_n_49,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\(1) => inst_wmema_n_50,
      \ramb_bl.ramb36_sin_bl.ram36_bl_22\(0) => inst_wmema_n_51,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(3) => inst_wmema_n_52,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(2) => inst_wmema_n_53,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(1) => inst_wmema_n_54,
      \ramb_bl.ramb36_sin_bl.ram36_bl_23\(0) => inst_wmema_n_55,
      \ramb_bl.ramb36_sin_bl.ram36_bl_24\(2) => inst_wmema_n_56,
      \ramb_bl.ramb36_sin_bl.ram36_bl_24\(1) => inst_wmema_n_57,
      \ramb_bl.ramb36_sin_bl.ram36_bl_24\(0) => inst_wmema_n_58,
      \ramb_bl.ramb36_sin_bl.ram36_bl_25\(0) => inst_wmema_n_59,
      \ramb_bl.ramb36_sin_bl.ram36_bl_26\(2) => inst_wmema_n_60,
      \ramb_bl.ramb36_sin_bl.ram36_bl_26\(1) => inst_wmema_n_61,
      \ramb_bl.ramb36_sin_bl.ram36_bl_26\(0) => inst_wmema_n_62,
      \ramb_bl.ramb36_sin_bl.ram36_bl_27\(0) => inst_wmema_n_63,
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(3) => inst_wmema_n_64,
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(2) => inst_wmema_n_65,
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(1) => inst_wmema_n_66,
      \ramb_bl.ramb36_sin_bl.ram36_bl_28\(0) => inst_wmema_n_67,
      \ramb_bl.ramb36_sin_bl.ram36_bl_29\(3) => inst_wmema_n_68,
      \ramb_bl.ramb36_sin_bl.ram36_bl_29\(2) => inst_wmema_n_69,
      \ramb_bl.ramb36_sin_bl.ram36_bl_29\(1) => inst_wmema_n_70,
      \ramb_bl.ramb36_sin_bl.ram36_bl_29\(0) => inst_wmema_n_71,
      \ramb_bl.ramb36_sin_bl.ram36_bl_3\(6 downto 0) => A(7 downto 1),
      \ramb_bl.ramb36_sin_bl.ram36_bl_30\(0) => inst_wmema_n_72,
      \ramb_bl.ramb36_sin_bl.ram36_bl_31\(2) => inst_wmema_n_73,
      \ramb_bl.ramb36_sin_bl.ram36_bl_31\(1) => inst_wmema_n_74,
      \ramb_bl.ramb36_sin_bl.ram36_bl_31\(0) => inst_wmema_n_75,
      \ramb_bl.ramb36_sin_bl.ram36_bl_32\(0) => inst_wmema_n_76,
      \ramb_bl.ramb36_sin_bl.ram36_bl_33\(2) => inst_wmema_n_77,
      \ramb_bl.ramb36_sin_bl.ram36_bl_33\(1) => inst_wmema_n_78,
      \ramb_bl.ramb36_sin_bl.ram36_bl_33\(0) => inst_wmema_n_79,
      \ramb_bl.ramb36_sin_bl.ram36_bl_34\(0) => inst_wmema_n_80,
      \ramb_bl.ramb36_sin_bl.ram36_bl_35\(3) => inst_wmema_n_81,
      \ramb_bl.ramb36_sin_bl.ram36_bl_35\(2) => inst_wmema_n_82,
      \ramb_bl.ramb36_sin_bl.ram36_bl_35\(1) => inst_wmema_n_83,
      \ramb_bl.ramb36_sin_bl.ram36_bl_35\(0) => inst_wmema_n_84,
      \ramb_bl.ramb36_sin_bl.ram36_bl_36\(3) => inst_wmema_n_85,
      \ramb_bl.ramb36_sin_bl.ram36_bl_36\(2) => inst_wmema_n_86,
      \ramb_bl.ramb36_sin_bl.ram36_bl_36\(1) => inst_wmema_n_87,
      \ramb_bl.ramb36_sin_bl.ram36_bl_36\(0) => inst_wmema_n_88,
      \ramb_bl.ramb36_sin_bl.ram36_bl_37\(0) => inst_wmema_n_89,
      \ramb_bl.ramb36_sin_bl.ram36_bl_38\(7 downto 0) => weight_addr(7 downto 0),
      \ramb_bl.ramb36_sin_bl.ram36_bl_4\(1) => inst_wmema_n_14,
      \ramb_bl.ramb36_sin_bl.ram36_bl_4\(0) => inst_wmema_n_15,
      \ramb_bl.ramb36_sin_bl.ram36_bl_5\ => inst_wmema_n_16,
      \ramb_bl.ramb36_sin_bl.ram36_bl_6\ => inst_wmema_n_17,
      \ramb_bl.ramb36_sin_bl.ram36_bl_7\(0) => inst_wmema_n_18,
      \ramb_bl.ramb36_sin_bl.ram36_bl_8\ => inst_wmema_n_19,
      \ramb_bl.ramb36_sin_bl.ram36_bl_9\(1) => inst_wmema_n_20,
      \ramb_bl.ramb36_sin_bl.ram36_bl_9\(0) => inst_wmema_n_21,
      rst_IBUF => rst_IBUF
    );
rst_IBUF_inst: unisim.vcomponents.IBUF
     port map (
      I => rst,
      O => rst_IBUF
    );
we_OBUF_inst: unisim.vcomponents.OBUF
     port map (
      I => we_OBUF,
      O => we
    );
end STRUCTURE;
