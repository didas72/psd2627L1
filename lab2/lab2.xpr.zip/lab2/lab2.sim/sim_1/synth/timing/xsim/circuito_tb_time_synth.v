// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (lin64) Build 6299465 Fri Nov 14 12:34:56 MST 2025
// Date        : Sun Nov  8 14:48:54 2026
// Host        : unknown72a06e5dd483.lan running 64-bit Fedora Linux 44 (KDE Plasma Desktop Edition)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               /home/garcia/Desktop/faculdade/PSD/psd2627L1/lab2/lab2/lab2.sim/sim_1/synth/timing/xsim/circuito_tb_time_synth.v
// Design      : circuito
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

module IMemB
   (DOADO,
    DI,
    \ramb_bl.ramb36_sin_bl.ram36_bl ,
    B,
    \ramb_bl.ramb36_sin_bl.ram36_bl_0 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_1 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_2 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_3 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_4 ,
    MUL1_OUT__59_carry__0,
    \ramb_bl.ramb36_sin_bl.ram36_bl_5 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_6 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_7 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_8 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_9 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_10 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_11 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_12 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_13 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_14 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_15 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_16 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_17 ,
    MUL2_OUT__59_carry__0,
    \ramb_bl.ramb36_sin_bl.ram36_bl_18 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_19 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_20 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_21 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_22 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_23 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_24 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_25 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_26 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_27 ,
    MUL1_OUT__59_carry__1,
    MUL2_OUT__59_carry__1,
    CLK,
    Q,
    input_select,
    \REG2_reg[2] ,
    A,
    O,
    \REG1_reg[15] ,
    \REG2_reg[2]_0 ,
    \REG2_reg[2]_1 ,
    \REG2_reg[2]_2 ,
    MUL2_OUT__0_carry__0,
    MUL2_OUT__0_carry__0_0,
    MUL2_OUT__0_carry__0_1,
    MUL2_OUT__0_carry__0_2,
    \REG2_reg[15] ,
    \REG2_reg[15]_0 ,
    MUL1_OUT__0_carry__0,
    MUL1_OUT__30_carry__0,
    MUL2_OUT__0_carry__0_3,
    MUL2_OUT__30_carry__0,
    CO,
    \REG1_reg[15]_0 ,
    \REG2_reg[15]_1 ,
    \REG2_reg[15]_2 );
  output [31:0]DOADO;
  output [1:0]DI;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl ;
  output [7:0]B;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  output [1:0]MUL1_OUT__59_carry__0;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_9 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  output [1:0]MUL2_OUT__59_carry__0;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  output [2:0]MUL1_OUT__59_carry__1;
  output [2:0]MUL2_OUT__59_carry__1;
  input CLK;
  input [3:0]Q;
  input input_select;
  input [3:0]\REG2_reg[2] ;
  input [6:0]A;
  input [1:0]O;
  input [2:0]\REG1_reg[15] ;
  input \REG2_reg[2]_0 ;
  input \REG2_reg[2]_1 ;
  input \REG2_reg[2]_2 ;
  input MUL2_OUT__0_carry__0;
  input MUL2_OUT__0_carry__0_0;
  input MUL2_OUT__0_carry__0_1;
  input MUL2_OUT__0_carry__0_2;
  input [1:0]\REG2_reg[15] ;
  input [2:0]\REG2_reg[15]_0 ;
  input MUL1_OUT__0_carry__0;
  input MUL1_OUT__30_carry__0;
  input MUL2_OUT__0_carry__0_3;
  input MUL2_OUT__30_carry__0;
  input [0:0]CO;
  input [0:0]\REG1_reg[15]_0 ;
  input [0:0]\REG2_reg[15]_1 ;
  input [0:0]\REG2_reg[15]_2 ;

  wire [6:0]A;
  wire [7:0]B;
  wire CLK;
  wire [0:0]CO;
  wire [1:0]DI;
  wire [31:0]DOADO;
  wire MUL1_OUT__0_carry__0;
  wire MUL1_OUT__30_carry__0;
  wire [1:0]MUL1_OUT__59_carry__0;
  wire [2:0]MUL1_OUT__59_carry__1;
  wire MUL2_OUT__0_carry__0;
  wire MUL2_OUT__0_carry__0_0;
  wire MUL2_OUT__0_carry__0_1;
  wire MUL2_OUT__0_carry__0_2;
  wire MUL2_OUT__0_carry__0_3;
  wire MUL2_OUT__30_carry__0;
  wire [1:0]MUL2_OUT__59_carry__0;
  wire [2:0]MUL2_OUT__59_carry__1;
  wire [1:0]O;
  wire [3:0]Q;
  wire [2:0]\REG1_reg[15] ;
  wire [0:0]\REG1_reg[15]_0 ;
  wire [1:0]\REG2_reg[15] ;
  wire [2:0]\REG2_reg[15]_0 ;
  wire [0:0]\REG2_reg[15]_1 ;
  wire [0:0]\REG2_reg[15]_2 ;
  wire [3:0]\REG2_reg[2] ;
  wire \REG2_reg[2]_0 ;
  wire \REG2_reg[2]_1 ;
  wire \REG2_reg[2]_2 ;
  wire input_select;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_9 ;

  unimacro_BRAM_SINGLE_MACRO MEM_in
       (.A(A),
        .B(B[7:6]),
        .CLK(CLK),
        .CO(CO),
        .DI(DI),
        .DOADO(DOADO),
        .MUL1_OUT__0_carry__0(MUL1_OUT__0_carry__0),
        .MUL1_OUT__30_carry__0(MUL1_OUT__30_carry__0),
        .MUL1_OUT__59_carry__0(MUL1_OUT__59_carry__0),
        .MUL1_OUT__59_carry__1(MUL1_OUT__59_carry__1),
        .MUL2_OUT__0_carry__0(MUL2_OUT__0_carry__0),
        .MUL2_OUT__0_carry__0_0(MUL2_OUT__0_carry__0_0),
        .MUL2_OUT__0_carry__0_1(MUL2_OUT__0_carry__0_1),
        .MUL2_OUT__0_carry__0_2(MUL2_OUT__0_carry__0_2),
        .MUL2_OUT__0_carry__0_3(MUL2_OUT__0_carry__0_3),
        .MUL2_OUT__30_carry__0(MUL2_OUT__30_carry__0),
        .MUL2_OUT__59_carry__0(MUL2_OUT__59_carry__0),
        .MUL2_OUT__59_carry__1(MUL2_OUT__59_carry__1),
        .O(O),
        .Q(Q),
        .\REG1_reg[15] (\REG1_reg[15] ),
        .\REG1_reg[15]_0 (\REG1_reg[15]_0 ),
        .\REG2_reg[15] (\REG2_reg[15] ),
        .\REG2_reg[15]_0 (\REG2_reg[15]_0 ),
        .\REG2_reg[15]_1 (\REG2_reg[15]_1 ),
        .\REG2_reg[15]_2 (\REG2_reg[15]_2 ),
        .\REG2_reg[2] (\REG2_reg[2] ),
        .\REG2_reg[2]_0 (\REG2_reg[2]_0 ),
        .\REG2_reg[2]_1 (\REG2_reg[2]_1 ),
        .\REG2_reg[2]_2 (\REG2_reg[2]_2 ),
        .input_select(input_select),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_0 (\ramb_bl.ramb36_sin_bl.ram36_bl ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_1 (B[2]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_10 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_11 (\ramb_bl.ramb36_sin_bl.ram36_bl_4 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_12 (\ramb_bl.ramb36_sin_bl.ram36_bl_5 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_13 (\ramb_bl.ramb36_sin_bl.ram36_bl_6 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_14 (\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_15 (\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_16 (\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_17 (\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_18 (\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_19 (\ramb_bl.ramb36_sin_bl.ram36_bl_12 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_2 (B[1]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_20 (\ramb_bl.ramb36_sin_bl.ram36_bl_13 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_21 (\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_22 (\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_23 (\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_24 (\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_25 (\ramb_bl.ramb36_sin_bl.ram36_bl_18 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_26 (\ramb_bl.ramb36_sin_bl.ram36_bl_19 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_27 (\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_28 (\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_29 (\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_3 (B[0]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_30 (\ramb_bl.ramb36_sin_bl.ram36_bl_23 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_31 (\ramb_bl.ramb36_sin_bl.ram36_bl_24 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_32 (\ramb_bl.ramb36_sin_bl.ram36_bl_25 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_33 (\ramb_bl.ramb36_sin_bl.ram36_bl_26 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_34 (\ramb_bl.ramb36_sin_bl.ram36_bl_27 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_4 (\ramb_bl.ramb36_sin_bl.ram36_bl_0 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_5 (\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_6 (\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_7 (B[5]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_8 (B[4]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_9 (B[3]));
endmodule

module OMemC
   (DOADO,
    CLK,
    addr_omemc,
    DIADI,
    WEA);
  output [31:0]DOADO;
  input CLK;
  input [3:0]addr_omemc;
  input [20:0]DIADI;
  input [0:0]WEA;

  wire CLK;
  wire [20:0]DIADI;
  wire [31:0]DOADO;
  wire [0:0]WEA;
  wire [3:0]addr_omemc;

  unimacro_BRAM_SINGLE_MACRO__parameterized1 MEM_in
       (.CLK(CLK),
        .DIADI(DIADI),
        .DOADO(DOADO),
        .WEA(WEA),
        .addr_omemc(addr_omemc));
endmodule

module WMemA
   (\ramb_bl.ramb36_sin_bl.ram36_bl ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_0 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_1 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_2 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_3 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_4 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_5 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_6 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_7 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_8 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_9 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_10 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_11 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_12 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_13 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_14 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_15 ,
    DI,
    \ramb_bl.ramb36_sin_bl.ram36_bl_16 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_17 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_18 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_19 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_20 ,
    S,
    \ramb_bl.ramb36_sin_bl.ram36_bl_21 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_22 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_23 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_24 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_25 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_26 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_27 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_28 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_29 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_30 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_31 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_32 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_33 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_34 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_35 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_36 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_37 ,
    CLK,
    out,
    DOADO,
    input_select,
    B,
    MUL2_OUT__59_carry__0,
    MUL2_OUT__59_carry__0_0,
    \REG2_reg[2] ,
    \REG2_reg[2]_0 ,
    MUL2_OUT__30_carry,
    MUL2_OUT__30_carry_0,
    \REG2_reg[2]_1 ,
    MUL2_OUT__30_carry_1);
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  output [6:0]\ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_9 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  output [0:0]DI;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  output [3:0]S;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_28 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_29 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_30 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_31 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_32 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_33 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_34 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_35 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_36 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_37 ;
  input CLK;
  input [7:0]out;
  input [31:0]DOADO;
  input input_select;
  input [7:0]B;
  input MUL2_OUT__59_carry__0;
  input MUL2_OUT__59_carry__0_0;
  input \REG2_reg[2] ;
  input \REG2_reg[2]_0 ;
  input MUL2_OUT__30_carry;
  input MUL2_OUT__30_carry_0;
  input \REG2_reg[2]_1 ;
  input MUL2_OUT__30_carry_1;

  wire [7:0]B;
  wire CLK;
  wire [0:0]DI;
  wire [31:0]DOADO;
  wire MUL2_OUT__30_carry;
  wire MUL2_OUT__30_carry_0;
  wire MUL2_OUT__30_carry_1;
  wire MUL2_OUT__59_carry__0;
  wire MUL2_OUT__59_carry__0_0;
  wire \REG2_reg[2] ;
  wire \REG2_reg[2]_0 ;
  wire \REG2_reg[2]_1 ;
  wire [3:0]S;
  wire input_select;
  wire [7:0]out;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_28 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_29 ;
  wire [6:0]\ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_30 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_31 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_32 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_33 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_34 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_35 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_36 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_37 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_9 ;

  unimacro_BRAM_SINGLE_MACRO__parameterized0 MEM_in
       (.B(B),
        .CLK(CLK),
        .DI(DI),
        .DOADO(\ramb_bl.ramb36_sin_bl.ram36_bl ),
        .MUL2_OUT__30_carry(MUL2_OUT__30_carry),
        .MUL2_OUT__30_carry_0(MUL2_OUT__30_carry_0),
        .MUL2_OUT__30_carry_1(MUL2_OUT__30_carry_1),
        .MUL2_OUT__59_carry(DOADO),
        .MUL2_OUT__59_carry__0(MUL2_OUT__59_carry__0),
        .MUL2_OUT__59_carry__0_0(MUL2_OUT__59_carry__0_0),
        .\REG2_reg[2] (\REG2_reg[2] ),
        .\REG2_reg[2]_0 (\REG2_reg[2]_0 ),
        .\REG2_reg[2]_1 (\REG2_reg[2]_1 ),
        .S(S),
        .input_select(input_select),
        .out(out),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_0 (\ramb_bl.ramb36_sin_bl.ram36_bl_0 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_1 (\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_10 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [0]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_11 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [1]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_12 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [2]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_13 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [3]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_14 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [4]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_15 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [5]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_16 (\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_17 (\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_18 (\ramb_bl.ramb36_sin_bl.ram36_bl_12 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_19 (\ramb_bl.ramb36_sin_bl.ram36_bl_13 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_2 (\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_20 (\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_21 (\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_22 (\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_23 (\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_24 (\ramb_bl.ramb36_sin_bl.ram36_bl_18 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_25 (\ramb_bl.ramb36_sin_bl.ram36_bl_19 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_26 (\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_27 (\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_28 (\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_29 (\ramb_bl.ramb36_sin_bl.ram36_bl_23 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_3 (\ramb_bl.ramb36_sin_bl.ram36_bl_3 [6]),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_30 (\ramb_bl.ramb36_sin_bl.ram36_bl_24 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_31 (\ramb_bl.ramb36_sin_bl.ram36_bl_25 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_32 (\ramb_bl.ramb36_sin_bl.ram36_bl_26 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_33 (\ramb_bl.ramb36_sin_bl.ram36_bl_27 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_34 (\ramb_bl.ramb36_sin_bl.ram36_bl_28 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_35 (\ramb_bl.ramb36_sin_bl.ram36_bl_29 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_36 (\ramb_bl.ramb36_sin_bl.ram36_bl_30 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_37 (\ramb_bl.ramb36_sin_bl.ram36_bl_31 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_38 (\ramb_bl.ramb36_sin_bl.ram36_bl_32 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_39 (\ramb_bl.ramb36_sin_bl.ram36_bl_33 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_4 (\ramb_bl.ramb36_sin_bl.ram36_bl_4 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_40 (\ramb_bl.ramb36_sin_bl.ram36_bl_34 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_41 (\ramb_bl.ramb36_sin_bl.ram36_bl_35 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_42 (\ramb_bl.ramb36_sin_bl.ram36_bl_36 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_43 (\ramb_bl.ramb36_sin_bl.ram36_bl_37 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_5 (\ramb_bl.ramb36_sin_bl.ram36_bl_5 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_6 (\ramb_bl.ramb36_sin_bl.ram36_bl_6 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_7 (\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_8 (\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_9 (\ramb_bl.ramb36_sin_bl.ram36_bl_9 ));
endmodule

(* NotValidForBitStream *)
module circuito
   (clk,
    rst,
    done,
    we,
    addr_omemc,
    DataOut);
  input clk;
  input rst;
  output done;
  output we;
  output [9:0]addr_omemc;
  output [31:0]DataOut;

  wire [7:1]A;
  wire [1:1]A0;
  wire [1:1]A1;
  wire [1:1]A2;
  wire [1:1]A3;
  wire [7:0]B;
  wire [7:0]B0;
  wire [7:0]B1;
  wire [7:0]B2;
  wire [7:0]B3;
  wire [31:0]DataOut;
  wire [31:0]DataOut_OBUF;
  wire RSTP;
  wire [9:0]addr_omemc;
  wire [3:0]addr_omemc_OBUF;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [20:0]dataIN;
  wire done;
  wire done_OBUF;
  wire en_accum;
  wire en_r1;
  wire [3:0]input_addr;
  wire input_select;
  wire inst_datapath_n_0;
  wire inst_datapath_n_1;
  wire inst_datapath_n_10;
  wire inst_datapath_n_11;
  wire inst_datapath_n_12;
  wire inst_datapath_n_13;
  wire inst_datapath_n_2;
  wire inst_datapath_n_3;
  wire inst_datapath_n_4;
  wire inst_datapath_n_5;
  wire inst_datapath_n_6;
  wire inst_datapath_n_7;
  wire inst_datapath_n_8;
  wire inst_datapath_n_9;
  wire inst_imemb_n_32;
  wire inst_imemb_n_33;
  wire inst_imemb_n_34;
  wire inst_imemb_n_35;
  wire inst_imemb_n_36;
  wire inst_imemb_n_37;
  wire inst_imemb_n_46;
  wire inst_imemb_n_47;
  wire inst_imemb_n_48;
  wire inst_imemb_n_49;
  wire inst_imemb_n_50;
  wire inst_imemb_n_51;
  wire inst_imemb_n_52;
  wire inst_imemb_n_53;
  wire inst_imemb_n_54;
  wire inst_imemb_n_55;
  wire inst_imemb_n_56;
  wire inst_imemb_n_57;
  wire inst_imemb_n_58;
  wire inst_imemb_n_59;
  wire inst_imemb_n_60;
  wire inst_imemb_n_61;
  wire inst_imemb_n_62;
  wire inst_imemb_n_63;
  wire inst_imemb_n_64;
  wire inst_imemb_n_65;
  wire inst_imemb_n_66;
  wire inst_imemb_n_67;
  wire inst_imemb_n_68;
  wire inst_imemb_n_69;
  wire inst_imemb_n_70;
  wire inst_imemb_n_71;
  wire inst_imemb_n_72;
  wire inst_imemb_n_73;
  wire inst_imemb_n_74;
  wire inst_imemb_n_75;
  wire inst_imemb_n_76;
  wire inst_imemb_n_77;
  wire inst_imemb_n_78;
  wire inst_imemb_n_79;
  wire inst_imemb_n_80;
  wire inst_imemb_n_81;
  wire inst_imemb_n_82;
  wire inst_imemb_n_83;
  wire inst_imemb_n_84;
  wire inst_imemb_n_85;
  wire inst_imemb_n_86;
  wire inst_imemb_n_87;
  wire inst_imemb_n_88;
  wire inst_imemb_n_89;
  wire inst_imemb_n_90;
  wire inst_imemb_n_91;
  wire inst_imemb_n_92;
  wire inst_imemb_n_93;
  wire inst_imemb_n_94;
  wire inst_imemb_n_95;
  wire inst_imemb_n_96;
  wire inst_imemb_n_97;
  wire inst_imemb_n_98;
  wire inst_imemb_n_99;
  wire inst_wmema_n_14;
  wire inst_wmema_n_15;
  wire inst_wmema_n_16;
  wire inst_wmema_n_17;
  wire inst_wmema_n_18;
  wire inst_wmema_n_19;
  wire inst_wmema_n_20;
  wire inst_wmema_n_21;
  wire inst_wmema_n_22;
  wire inst_wmema_n_23;
  wire inst_wmema_n_24;
  wire inst_wmema_n_25;
  wire inst_wmema_n_26;
  wire inst_wmema_n_27;
  wire inst_wmema_n_28;
  wire inst_wmema_n_29;
  wire inst_wmema_n_30;
  wire inst_wmema_n_31;
  wire inst_wmema_n_32;
  wire inst_wmema_n_33;
  wire inst_wmema_n_34;
  wire inst_wmema_n_35;
  wire inst_wmema_n_36;
  wire inst_wmema_n_37;
  wire inst_wmema_n_38;
  wire inst_wmema_n_39;
  wire inst_wmema_n_4;
  wire inst_wmema_n_40;
  wire inst_wmema_n_41;
  wire inst_wmema_n_42;
  wire inst_wmema_n_43;
  wire inst_wmema_n_44;
  wire inst_wmema_n_45;
  wire inst_wmema_n_46;
  wire inst_wmema_n_47;
  wire inst_wmema_n_48;
  wire inst_wmema_n_49;
  wire inst_wmema_n_5;
  wire inst_wmema_n_50;
  wire inst_wmema_n_51;
  wire inst_wmema_n_52;
  wire inst_wmema_n_53;
  wire inst_wmema_n_54;
  wire inst_wmema_n_55;
  wire inst_wmema_n_56;
  wire inst_wmema_n_57;
  wire inst_wmema_n_58;
  wire inst_wmema_n_59;
  wire inst_wmema_n_6;
  wire inst_wmema_n_60;
  wire inst_wmema_n_61;
  wire inst_wmema_n_62;
  wire inst_wmema_n_63;
  wire inst_wmema_n_64;
  wire inst_wmema_n_65;
  wire inst_wmema_n_66;
  wire inst_wmema_n_67;
  wire inst_wmema_n_68;
  wire inst_wmema_n_69;
  wire inst_wmema_n_70;
  wire inst_wmema_n_71;
  wire inst_wmema_n_72;
  wire inst_wmema_n_73;
  wire inst_wmema_n_74;
  wire inst_wmema_n_75;
  wire inst_wmema_n_76;
  wire inst_wmema_n_77;
  wire inst_wmema_n_78;
  wire inst_wmema_n_79;
  wire inst_wmema_n_80;
  wire inst_wmema_n_81;
  wire inst_wmema_n_82;
  wire inst_wmema_n_83;
  wire inst_wmema_n_84;
  wire inst_wmema_n_85;
  wire inst_wmema_n_86;
  wire inst_wmema_n_87;
  wire inst_wmema_n_88;
  wire inst_wmema_n_89;
  wire rst;
  wire rst_IBUF;
  wire we;
  wire we_OBUF;
  wire [7:0]weight_addr;

initial begin
 $sdf_annotate("circuito_tb_time_synth.sdf",,,,"tool_control");
end
  OBUF \DataOut_OBUF[0]_inst 
       (.I(DataOut_OBUF[0]),
        .O(DataOut[0]));
  OBUF \DataOut_OBUF[10]_inst 
       (.I(DataOut_OBUF[10]),
        .O(DataOut[10]));
  OBUF \DataOut_OBUF[11]_inst 
       (.I(DataOut_OBUF[11]),
        .O(DataOut[11]));
  OBUF \DataOut_OBUF[12]_inst 
       (.I(DataOut_OBUF[12]),
        .O(DataOut[12]));
  OBUF \DataOut_OBUF[13]_inst 
       (.I(DataOut_OBUF[13]),
        .O(DataOut[13]));
  OBUF \DataOut_OBUF[14]_inst 
       (.I(DataOut_OBUF[14]),
        .O(DataOut[14]));
  OBUF \DataOut_OBUF[15]_inst 
       (.I(DataOut_OBUF[15]),
        .O(DataOut[15]));
  OBUF \DataOut_OBUF[16]_inst 
       (.I(DataOut_OBUF[16]),
        .O(DataOut[16]));
  OBUF \DataOut_OBUF[17]_inst 
       (.I(DataOut_OBUF[17]),
        .O(DataOut[17]));
  OBUF \DataOut_OBUF[18]_inst 
       (.I(DataOut_OBUF[18]),
        .O(DataOut[18]));
  OBUF \DataOut_OBUF[19]_inst 
       (.I(DataOut_OBUF[19]),
        .O(DataOut[19]));
  OBUF \DataOut_OBUF[1]_inst 
       (.I(DataOut_OBUF[1]),
        .O(DataOut[1]));
  OBUF \DataOut_OBUF[20]_inst 
       (.I(DataOut_OBUF[20]),
        .O(DataOut[20]));
  OBUF \DataOut_OBUF[21]_inst 
       (.I(DataOut_OBUF[21]),
        .O(DataOut[21]));
  OBUF \DataOut_OBUF[22]_inst 
       (.I(DataOut_OBUF[22]),
        .O(DataOut[22]));
  OBUF \DataOut_OBUF[23]_inst 
       (.I(DataOut_OBUF[23]),
        .O(DataOut[23]));
  OBUF \DataOut_OBUF[24]_inst 
       (.I(DataOut_OBUF[24]),
        .O(DataOut[24]));
  OBUF \DataOut_OBUF[25]_inst 
       (.I(DataOut_OBUF[25]),
        .O(DataOut[25]));
  OBUF \DataOut_OBUF[26]_inst 
       (.I(DataOut_OBUF[26]),
        .O(DataOut[26]));
  OBUF \DataOut_OBUF[27]_inst 
       (.I(DataOut_OBUF[27]),
        .O(DataOut[27]));
  OBUF \DataOut_OBUF[28]_inst 
       (.I(DataOut_OBUF[28]),
        .O(DataOut[28]));
  OBUF \DataOut_OBUF[29]_inst 
       (.I(DataOut_OBUF[29]),
        .O(DataOut[29]));
  OBUF \DataOut_OBUF[2]_inst 
       (.I(DataOut_OBUF[2]),
        .O(DataOut[2]));
  OBUF \DataOut_OBUF[30]_inst 
       (.I(DataOut_OBUF[30]),
        .O(DataOut[30]));
  OBUF \DataOut_OBUF[31]_inst 
       (.I(DataOut_OBUF[31]),
        .O(DataOut[31]));
  OBUF \DataOut_OBUF[3]_inst 
       (.I(DataOut_OBUF[3]),
        .O(DataOut[3]));
  OBUF \DataOut_OBUF[4]_inst 
       (.I(DataOut_OBUF[4]),
        .O(DataOut[4]));
  OBUF \DataOut_OBUF[5]_inst 
       (.I(DataOut_OBUF[5]),
        .O(DataOut[5]));
  OBUF \DataOut_OBUF[6]_inst 
       (.I(DataOut_OBUF[6]),
        .O(DataOut[6]));
  OBUF \DataOut_OBUF[7]_inst 
       (.I(DataOut_OBUF[7]),
        .O(DataOut[7]));
  OBUF \DataOut_OBUF[8]_inst 
       (.I(DataOut_OBUF[8]),
        .O(DataOut[8]));
  OBUF \DataOut_OBUF[9]_inst 
       (.I(DataOut_OBUF[9]),
        .O(DataOut[9]));
  OBUF \addr_omemc_OBUF[0]_inst 
       (.I(addr_omemc_OBUF[0]),
        .O(addr_omemc[0]));
  OBUF \addr_omemc_OBUF[1]_inst 
       (.I(addr_omemc_OBUF[1]),
        .O(addr_omemc[1]));
  OBUF \addr_omemc_OBUF[2]_inst 
       (.I(addr_omemc_OBUF[2]),
        .O(addr_omemc[2]));
  OBUF \addr_omemc_OBUF[3]_inst 
       (.I(addr_omemc_OBUF[3]),
        .O(addr_omemc[3]));
  OBUF \addr_omemc_OBUF[4]_inst 
       (.I(1'b0),
        .O(addr_omemc[4]));
  OBUF \addr_omemc_OBUF[5]_inst 
       (.I(1'b0),
        .O(addr_omemc[5]));
  OBUF \addr_omemc_OBUF[6]_inst 
       (.I(1'b0),
        .O(addr_omemc[6]));
  OBUF \addr_omemc_OBUF[7]_inst 
       (.I(1'b0),
        .O(addr_omemc[7]));
  OBUF \addr_omemc_OBUF[8]_inst 
       (.I(1'b0),
        .O(addr_omemc[8]));
  OBUF \addr_omemc_OBUF[9]_inst 
       (.I(1'b0),
        .O(addr_omemc[9]));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF done_OBUF_inst
       (.I(done_OBUF),
        .O(done));
  control_unit inst_control
       (.CLK(clk_IBUF_BUFG),
        .E(en_accum),
        .\FSM_onehot_state_reg[6]_0 (done_OBUF),
        .Q(input_addr),
        .SR(rst_IBUF),
        .WEA(we_OBUF),
        .addr_omemc(addr_omemc_OBUF),
        .en_r1_reg_0(en_r1),
        .input_select(input_select),
        .out(weight_addr),
        .reset_accum_reg_0(RSTP));
  datapath inst_datapath
       (.CLK(clk_IBUF_BUFG),
        .CO(inst_datapath_n_0),
        .DI({inst_imemb_n_32,inst_wmema_n_28,inst_imemb_n_33}),
        .DIADI(dataIN),
        .E(en_r1),
        .MUL1_OUT__85_carry__0_i_3_0({inst_wmema_n_59,inst_imemb_n_46}),
        .MUL1_OUT__85_carry__0_i_3_1({inst_imemb_n_83,inst_imemb_n_84}),
        .MUL1_OUT__85_carry__0_i_4_0({inst_imemb_n_49,inst_imemb_n_50,inst_imemb_n_51,inst_imemb_n_52}),
        .MUL1_OUT__85_carry__0_i_4_1({inst_imemb_n_85,inst_wmema_n_60,inst_wmema_n_61,inst_wmema_n_62}),
        .MUL1_OUT__85_carry__0_i_6_0({inst_wmema_n_68,inst_wmema_n_69,inst_wmema_n_70,inst_wmema_n_71}),
        .MUL1_OUT__85_carry__0_i_6_1({inst_wmema_n_30,inst_wmema_n_31,inst_wmema_n_32,inst_wmema_n_33}),
        .MUL1_OUT__85_carry__1_i_5({inst_wmema_n_63,inst_imemb_n_53}),
        .MUL1_OUT__85_carry__1_i_5_0({inst_imemb_n_86,inst_imemb_n_87}),
        .MUL1_OUT__85_carry_i_1_0({inst_wmema_n_14,inst_imemb_n_54,inst_wmema_n_15}),
        .MUL1_OUT__85_carry_i_1_1({inst_wmema_n_64,inst_wmema_n_65,inst_wmema_n_66,inst_wmema_n_67}),
        .MUL1_OUT__85_carry_i_8_0({inst_imemb_n_34,inst_imemb_n_35,inst_imemb_n_36,inst_imemb_n_37}),
        .MUL1_OUT__85_carry_i_8_1({inst_imemb_n_82,inst_wmema_n_56,inst_wmema_n_57,inst_wmema_n_58}),
        .MUL2_OUT__85_carry__0_i_3_0({inst_wmema_n_76,inst_imemb_n_66}),
        .MUL2_OUT__85_carry__0_i_3_1({inst_imemb_n_89,inst_imemb_n_90}),
        .MUL2_OUT__85_carry__0_i_4_0({inst_imemb_n_69,inst_imemb_n_70,inst_imemb_n_71,inst_imemb_n_72}),
        .MUL2_OUT__85_carry__0_i_4_1({inst_imemb_n_91,inst_wmema_n_77,inst_wmema_n_78,inst_wmema_n_79}),
        .MUL2_OUT__85_carry__0_i_6_0({inst_wmema_n_85,inst_wmema_n_86,inst_wmema_n_87,inst_wmema_n_88}),
        .MUL2_OUT__85_carry__0_i_6_1({inst_wmema_n_36,inst_wmema_n_37,inst_wmema_n_38,inst_wmema_n_39}),
        .MUL2_OUT__85_carry__1_i_5({inst_wmema_n_80,inst_imemb_n_76}),
        .MUL2_OUT__85_carry__1_i_5_0({inst_imemb_n_92,inst_imemb_n_93}),
        .MUL2_OUT__85_carry_i_1_0({inst_wmema_n_20,inst_imemb_n_77,inst_wmema_n_21}),
        .MUL2_OUT__85_carry_i_1_1({inst_wmema_n_81,inst_wmema_n_82,inst_wmema_n_83,inst_wmema_n_84}),
        .MUL2_OUT__85_carry_i_8_0({inst_imemb_n_59,inst_imemb_n_60,inst_imemb_n_61,inst_imemb_n_62}),
        .MUL2_OUT__85_carry_i_8_1({inst_imemb_n_88,inst_wmema_n_73,inst_wmema_n_74,inst_wmema_n_75}),
        .O({inst_datapath_n_1,inst_datapath_n_2}),
        .\REG1_reg[15]_0 (inst_wmema_n_6),
        .\REG1_reg[15]_1 (inst_wmema_n_72),
        .\REG1_reg[15]_2 ({inst_imemb_n_55,inst_imemb_n_56}),
        .\REG1_reg[15]_3 ({inst_imemb_n_94,inst_imemb_n_95,inst_imemb_n_96}),
        .\REG1_reg[3]_0 ({inst_imemb_n_47,inst_wmema_n_29,inst_imemb_n_48}),
        .\REG1_reg[3]_1 ({inst_wmema_n_44,inst_wmema_n_45,inst_wmema_n_46,inst_wmema_n_47}),
        .\REG2_reg[15]_0 (inst_wmema_n_18),
        .\REG2_reg[15]_1 (inst_wmema_n_89),
        .\REG2_reg[15]_2 ({inst_imemb_n_78,inst_imemb_n_79}),
        .\REG2_reg[15]_3 ({inst_imemb_n_97,inst_imemb_n_98,inst_imemb_n_99}),
        .\REG2_reg[2]_0 ({inst_imemb_n_57,inst_wmema_n_34,inst_imemb_n_58}),
        .\REG2_reg[2]_1 ({inst_wmema_n_48,inst_wmema_n_49,inst_wmema_n_50,inst_wmema_n_51}),
        .\REG2_reg[3]_0 ({inst_imemb_n_67,inst_wmema_n_35,inst_imemb_n_68}),
        .\REG2_reg[3]_1 ({inst_wmema_n_52,inst_wmema_n_53,inst_wmema_n_54,inst_wmema_n_55}),
        .\REG_ACCUM_reg[21]_0 (RSTP),
        .\REG_ACCUM_reg[21]_1 (en_accum),
        .S({inst_wmema_n_40,inst_wmema_n_41,inst_wmema_n_42,inst_wmema_n_43}),
        .SR(rst_IBUF),
        .\ramb_bl.ramb36_sin_bl.ram36_bl ({inst_datapath_n_3,inst_datapath_n_4,inst_datapath_n_5}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_0 (inst_datapath_n_6),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_1 (inst_datapath_n_7),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_2 ({inst_datapath_n_8,inst_datapath_n_9}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_3 ({inst_datapath_n_10,inst_datapath_n_11,inst_datapath_n_12}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_4 (inst_datapath_n_13));
  IMemB inst_imemb
       (.A(A),
        .B(B),
        .CLK(clk_IBUF_BUFG),
        .CO(inst_datapath_n_0),
        .DI({inst_imemb_n_32,inst_imemb_n_33}),
        .DOADO({B3,B2,B1,B0}),
        .MUL1_OUT__0_carry__0(inst_wmema_n_4),
        .MUL1_OUT__30_carry__0(inst_wmema_n_5),
        .MUL1_OUT__59_carry__0({inst_imemb_n_55,inst_imemb_n_56}),
        .MUL1_OUT__59_carry__1({inst_imemb_n_94,inst_imemb_n_95,inst_imemb_n_96}),
        .MUL2_OUT__0_carry__0(inst_wmema_n_25),
        .MUL2_OUT__0_carry__0_0(inst_wmema_n_26),
        .MUL2_OUT__0_carry__0_1(inst_wmema_n_27),
        .MUL2_OUT__0_carry__0_2(inst_wmema_n_19),
        .MUL2_OUT__0_carry__0_3(inst_wmema_n_16),
        .MUL2_OUT__30_carry__0(inst_wmema_n_17),
        .MUL2_OUT__59_carry__0({inst_imemb_n_78,inst_imemb_n_79}),
        .MUL2_OUT__59_carry__1({inst_imemb_n_97,inst_imemb_n_98,inst_imemb_n_99}),
        .O({inst_datapath_n_1,inst_datapath_n_2}),
        .Q(input_addr),
        .\REG1_reg[15] ({inst_datapath_n_3,inst_datapath_n_4,inst_datapath_n_5}),
        .\REG1_reg[15]_0 (inst_datapath_n_6),
        .\REG2_reg[15] ({inst_datapath_n_8,inst_datapath_n_9}),
        .\REG2_reg[15]_0 ({inst_datapath_n_10,inst_datapath_n_11,inst_datapath_n_12}),
        .\REG2_reg[15]_1 (inst_datapath_n_7),
        .\REG2_reg[15]_2 (inst_datapath_n_13),
        .\REG2_reg[2] ({A3,A2,A1,A0}),
        .\REG2_reg[2]_0 (inst_wmema_n_22),
        .\REG2_reg[2]_1 (inst_wmema_n_23),
        .\REG2_reg[2]_2 (inst_wmema_n_24),
        .input_select(input_select),
        .\ramb_bl.ramb36_sin_bl.ram36_bl ({inst_imemb_n_34,inst_imemb_n_35,inst_imemb_n_36,inst_imemb_n_37}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_0 (inst_imemb_n_46),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_1 ({inst_imemb_n_47,inst_imemb_n_48}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_10 (inst_imemb_n_66),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_11 ({inst_imemb_n_67,inst_imemb_n_68}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_12 ({inst_imemb_n_69,inst_imemb_n_70,inst_imemb_n_71,inst_imemb_n_72}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_13 (inst_imemb_n_73),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_14 (inst_imemb_n_74),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_15 (inst_imemb_n_75),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_16 (inst_imemb_n_76),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_17 (inst_imemb_n_77),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_18 (inst_imemb_n_80),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_19 (inst_imemb_n_81),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_2 ({inst_imemb_n_49,inst_imemb_n_50,inst_imemb_n_51,inst_imemb_n_52}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_20 (inst_imemb_n_82),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_21 ({inst_imemb_n_83,inst_imemb_n_84}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_22 (inst_imemb_n_85),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_23 ({inst_imemb_n_86,inst_imemb_n_87}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_24 (inst_imemb_n_88),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_25 ({inst_imemb_n_89,inst_imemb_n_90}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_26 (inst_imemb_n_91),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_27 ({inst_imemb_n_92,inst_imemb_n_93}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_3 (inst_imemb_n_53),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_4 (inst_imemb_n_54),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_5 ({inst_imemb_n_57,inst_imemb_n_58}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_6 ({inst_imemb_n_59,inst_imemb_n_60,inst_imemb_n_61,inst_imemb_n_62}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_7 (inst_imemb_n_63),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_8 (inst_imemb_n_64),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_9 (inst_imemb_n_65));
  OMemC inst_omemc
       (.CLK(clk_IBUF_BUFG),
        .DIADI(dataIN),
        .DOADO(DataOut_OBUF),
        .WEA(we_OBUF),
        .addr_omemc(addr_omemc_OBUF));
  WMemA inst_wmema
       (.B(B),
        .CLK(clk_IBUF_BUFG),
        .DI(inst_wmema_n_28),
        .DOADO({B3,B2,B1,B0}),
        .MUL2_OUT__30_carry(inst_imemb_n_74),
        .MUL2_OUT__30_carry_0(inst_imemb_n_73),
        .MUL2_OUT__30_carry_1(inst_imemb_n_75),
        .MUL2_OUT__59_carry__0(inst_imemb_n_81),
        .MUL2_OUT__59_carry__0_0(inst_imemb_n_80),
        .\REG2_reg[2] (inst_imemb_n_64),
        .\REG2_reg[2]_0 (inst_imemb_n_63),
        .\REG2_reg[2]_1 (inst_imemb_n_65),
        .S({inst_wmema_n_40,inst_wmema_n_41,inst_wmema_n_42,inst_wmema_n_43}),
        .input_select(input_select),
        .out(weight_addr),
        .\ramb_bl.ramb36_sin_bl.ram36_bl ({A3,A2,A1,A0}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_0 (inst_wmema_n_4),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_1 (inst_wmema_n_5),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_10 (inst_wmema_n_22),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_11 (inst_wmema_n_23),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_12 (inst_wmema_n_24),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_13 (inst_wmema_n_25),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_14 (inst_wmema_n_26),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_15 (inst_wmema_n_27),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_16 (inst_wmema_n_29),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_17 ({inst_wmema_n_30,inst_wmema_n_31,inst_wmema_n_32,inst_wmema_n_33}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_18 (inst_wmema_n_34),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_19 (inst_wmema_n_35),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_2 (inst_wmema_n_6),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_20 ({inst_wmema_n_36,inst_wmema_n_37,inst_wmema_n_38,inst_wmema_n_39}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_21 ({inst_wmema_n_44,inst_wmema_n_45,inst_wmema_n_46,inst_wmema_n_47}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_22 ({inst_wmema_n_48,inst_wmema_n_49,inst_wmema_n_50,inst_wmema_n_51}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_23 ({inst_wmema_n_52,inst_wmema_n_53,inst_wmema_n_54,inst_wmema_n_55}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_24 ({inst_wmema_n_56,inst_wmema_n_57,inst_wmema_n_58}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_25 (inst_wmema_n_59),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_26 ({inst_wmema_n_60,inst_wmema_n_61,inst_wmema_n_62}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_27 (inst_wmema_n_63),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_28 ({inst_wmema_n_64,inst_wmema_n_65,inst_wmema_n_66,inst_wmema_n_67}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_29 ({inst_wmema_n_68,inst_wmema_n_69,inst_wmema_n_70,inst_wmema_n_71}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_3 (A),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_30 (inst_wmema_n_72),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_31 ({inst_wmema_n_73,inst_wmema_n_74,inst_wmema_n_75}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_32 (inst_wmema_n_76),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_33 ({inst_wmema_n_77,inst_wmema_n_78,inst_wmema_n_79}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_34 (inst_wmema_n_80),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_35 ({inst_wmema_n_81,inst_wmema_n_82,inst_wmema_n_83,inst_wmema_n_84}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_36 ({inst_wmema_n_85,inst_wmema_n_86,inst_wmema_n_87,inst_wmema_n_88}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_37 (inst_wmema_n_89),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_4 ({inst_wmema_n_14,inst_wmema_n_15}),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_5 (inst_wmema_n_16),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_6 (inst_wmema_n_17),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_7 (inst_wmema_n_18),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_8 (inst_wmema_n_19),
        .\ramb_bl.ramb36_sin_bl.ram36_bl_9 ({inst_wmema_n_20,inst_wmema_n_21}));
  IBUF rst_IBUF_inst
       (.I(rst),
        .O(rst_IBUF));
  OBUF we_OBUF_inst
       (.I(we_OBUF),
        .O(we));
endmodule

module control_unit
   (WEA,
    E,
    en_r1_reg_0,
    input_select,
    Q,
    \FSM_onehot_state_reg[6]_0 ,
    addr_omemc,
    out,
    reset_accum_reg_0,
    SR,
    CLK);
  output [0:0]WEA;
  output [0:0]E;
  output [0:0]en_r1_reg_0;
  output input_select;
  output [3:0]Q;
  output [0:0]\FSM_onehot_state_reg[6]_0 ;
  output [3:0]addr_omemc;
  output [7:0]out;
  output [0:0]reset_accum_reg_0;
  input [0:0]SR;
  input CLK;

  wire CLK;
  wire [0:0]E;
  wire \FSM_onehot_state[0]_i_1_n_0 ;
  wire \FSM_onehot_state[0]_i_2_n_0 ;
  wire \FSM_onehot_state[0]_i_3_n_0 ;
  wire \FSM_onehot_state[5]_i_1_n_0 ;
  wire \FSM_onehot_state[6]_i_1_n_0 ;
  wire [0:0]\FSM_onehot_state_reg[6]_0 ;
  wire \FSM_onehot_state_reg_n_0_[0] ;
  wire \FSM_onehot_state_reg_n_0_[1] ;
  wire \FSM_onehot_state_reg_n_0_[2] ;
  wire \FSM_onehot_state_reg_n_0_[3] ;
  wire [3:0]Q;
  wire [0:0]SR;
  wire [0:0]WEA;
  wire [3:0]addr_omemc;
  wire en_accum_i_1_n_0;
  wire en_r1_i_1_n_0;
  wire [0:0]en_r1_reg_0;
  wire input_select;
  wire input_select_i_1_n_0;
  wire [7:0]out;
  wire [3:0]plusOp;
  wire [7:0]plusOp__0;
  wire [3:1]reg_input_addr;
  wire \reg_input_addr[0]_i_1_n_0 ;
  wire \reg_input_addr[3]_i_1_n_0 ;
  wire [0:0]reg_output_addr;
  wire [0:0]reg_weight_addr;
  wire \reg_weight_addr[7]_i_2_n_0 ;
  wire reset_accum;
  wire [0:0]reset_accum_reg_0;

  LUT4 #(
    .INIT(16'hF888)) 
    \FSM_onehot_state[0]_i_1 
       (.I0(\FSM_onehot_state[0]_i_2_n_0 ),
        .I1(reg_weight_addr),
        .I2(\FSM_onehot_state[0]_i_3_n_0 ),
        .I3(reg_output_addr),
        .O(\FSM_onehot_state[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \FSM_onehot_state[0]_i_2 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(Q[3]),
        .O(\FSM_onehot_state[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \FSM_onehot_state[0]_i_3 
       (.I0(addr_omemc[0]),
        .I1(addr_omemc[1]),
        .I2(addr_omemc[2]),
        .I3(addr_omemc[3]),
        .O(\FSM_onehot_state[0]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \FSM_onehot_state[5]_i_1 
       (.I0(reg_weight_addr),
        .I1(Q[3]),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(Q[0]),
        .O(\FSM_onehot_state[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAAAAAAAAAAAAA)) 
    \FSM_onehot_state[6]_i_1 
       (.I0(\FSM_onehot_state_reg[6]_0 ),
        .I1(addr_omemc[0]),
        .I2(addr_omemc[1]),
        .I3(addr_omemc[2]),
        .I4(addr_omemc[3]),
        .I5(reg_output_addr),
        .O(\FSM_onehot_state[6]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state[0]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg_n_0_[0] ),
        .S(SR));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[0] ),
        .Q(\FSM_onehot_state_reg_n_0_[1] ),
        .R(SR));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[1] ),
        .Q(\FSM_onehot_state_reg_n_0_[2] ),
        .R(SR));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[2] ),
        .Q(\FSM_onehot_state_reg_n_0_[3] ),
        .R(SR));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[3] ),
        .Q(reg_weight_addr),
        .R(SR));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state[5]_i_1_n_0 ),
        .Q(reg_output_addr),
        .R(SR));
  (* FSM_ENCODED_STATES = "s_l2_0_latch:0000010,s_l2_1_addr:0000100,s_l2_1_latch:0001000,s_l2_2_accum:0010000,s_l1_0:0100000,s_done:1000000,s_l2_0_addr:0000001" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_onehot_state[6]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[6]_0 ),
        .R(SR));
  LUT2 #(
    .INIT(4'hE)) 
    \REG_ACCUM[21]_i_1 
       (.I0(SR),
        .I1(reset_accum),
        .O(reset_accum_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'hE)) 
    en_accum_i_1
       (.I0(\FSM_onehot_state_reg_n_0_[2] ),
        .I1(reg_weight_addr),
        .O(en_accum_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    en_accum_reg
       (.C(CLK),
        .CE(1'b1),
        .D(en_accum_i_1_n_0),
        .Q(E),
        .R(SR));
  LUT2 #(
    .INIT(4'hE)) 
    en_r1_i_1
       (.I0(\FSM_onehot_state_reg_n_0_[1] ),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .O(en_r1_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    en_r1_reg
       (.C(CLK),
        .CE(1'b1),
        .D(en_r1_i_1_n_0),
        .Q(en_r1_reg_0),
        .R(SR));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hDC)) 
    input_select_i_1
       (.I0(\FSM_onehot_state_reg_n_0_[0] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .I2(input_select),
        .O(input_select_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    input_select_reg
       (.C(CLK),
        .CE(1'b1),
        .D(input_select_i_1_n_0),
        .Q(input_select),
        .R(SR));
  LUT2 #(
    .INIT(4'h2)) 
    \reg_input_addr[0]_i_1 
       (.I0(reg_weight_addr),
        .I1(Q[0]),
        .O(\reg_input_addr[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \reg_input_addr[1]_i_1 
       (.I0(reg_weight_addr),
        .I1(Q[1]),
        .I2(Q[0]),
        .O(reg_input_addr[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h2888)) 
    \reg_input_addr[2]_i_1 
       (.I0(reg_weight_addr),
        .I1(Q[2]),
        .I2(Q[1]),
        .I3(Q[0]),
        .O(reg_input_addr[2]));
  LUT2 #(
    .INIT(4'hE)) 
    \reg_input_addr[3]_i_1 
       (.I0(reg_weight_addr),
        .I1(reg_output_addr),
        .O(\reg_input_addr[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h28888888)) 
    \reg_input_addr[3]_i_2 
       (.I0(reg_weight_addr),
        .I1(Q[3]),
        .I2(Q[2]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(reg_input_addr[3]));
  FDRE #(
    .INIT(1'b0)) 
    \reg_input_addr_reg[0] 
       (.C(CLK),
        .CE(\reg_input_addr[3]_i_1_n_0 ),
        .D(\reg_input_addr[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_input_addr_reg[1] 
       (.C(CLK),
        .CE(\reg_input_addr[3]_i_1_n_0 ),
        .D(reg_input_addr[1]),
        .Q(Q[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_input_addr_reg[2] 
       (.C(CLK),
        .CE(\reg_input_addr[3]_i_1_n_0 ),
        .D(reg_input_addr[2]),
        .Q(Q[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_input_addr_reg[3] 
       (.C(CLK),
        .CE(\reg_input_addr[3]_i_1_n_0 ),
        .D(reg_input_addr[3]),
        .Q(Q[3]),
        .R(SR));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_output_addr[0]_i_1 
       (.I0(addr_omemc[0]),
        .O(plusOp[0]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \reg_output_addr[1]_i_1 
       (.I0(addr_omemc[0]),
        .I1(addr_omemc[1]),
        .O(plusOp[1]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \reg_output_addr[2]_i_1 
       (.I0(addr_omemc[0]),
        .I1(addr_omemc[1]),
        .I2(addr_omemc[2]),
        .O(plusOp[2]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \reg_output_addr[3]_i_1 
       (.I0(addr_omemc[1]),
        .I1(addr_omemc[0]),
        .I2(addr_omemc[2]),
        .I3(addr_omemc[3]),
        .O(plusOp[3]));
  FDRE #(
    .INIT(1'b0)) 
    \reg_output_addr_reg[0] 
       (.C(CLK),
        .CE(reg_output_addr),
        .D(plusOp[0]),
        .Q(addr_omemc[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_output_addr_reg[1] 
       (.C(CLK),
        .CE(reg_output_addr),
        .D(plusOp[1]),
        .Q(addr_omemc[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_output_addr_reg[2] 
       (.C(CLK),
        .CE(reg_output_addr),
        .D(plusOp[2]),
        .Q(addr_omemc[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_output_addr_reg[3] 
       (.C(CLK),
        .CE(reg_output_addr),
        .D(plusOp[3]),
        .Q(addr_omemc[3]),
        .R(SR));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_weight_addr[0]_i_1 
       (.I0(out[0]),
        .O(plusOp__0[0]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \reg_weight_addr[1]_i_1 
       (.I0(out[0]),
        .I1(out[1]),
        .O(plusOp__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \reg_weight_addr[2]_i_1 
       (.I0(out[0]),
        .I1(out[1]),
        .I2(out[2]),
        .O(plusOp__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \reg_weight_addr[3]_i_1 
       (.I0(out[1]),
        .I1(out[0]),
        .I2(out[2]),
        .I3(out[3]),
        .O(plusOp__0[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \reg_weight_addr[4]_i_1 
       (.I0(out[2]),
        .I1(out[0]),
        .I2(out[1]),
        .I3(out[3]),
        .I4(out[4]),
        .O(plusOp__0[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \reg_weight_addr[5]_i_1 
       (.I0(out[3]),
        .I1(out[1]),
        .I2(out[0]),
        .I3(out[2]),
        .I4(out[4]),
        .I5(out[5]),
        .O(plusOp__0[5]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \reg_weight_addr[6]_i_1 
       (.I0(\reg_weight_addr[7]_i_2_n_0 ),
        .I1(out[6]),
        .O(plusOp__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \reg_weight_addr[7]_i_1 
       (.I0(\reg_weight_addr[7]_i_2_n_0 ),
        .I1(out[6]),
        .I2(out[7]),
        .O(plusOp__0[7]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \reg_weight_addr[7]_i_2 
       (.I0(out[5]),
        .I1(out[3]),
        .I2(out[1]),
        .I3(out[0]),
        .I4(out[2]),
        .I5(out[4]),
        .O(\reg_weight_addr[7]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[0] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[0]),
        .Q(out[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[1] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[1]),
        .Q(out[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[2] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[2]),
        .Q(out[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[3] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[3]),
        .Q(out[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[4] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[4]),
        .Q(out[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[5] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[5]),
        .Q(out[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[6] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[6]),
        .Q(out[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \reg_weight_addr_reg[7] 
       (.C(CLK),
        .CE(reg_weight_addr),
        .D(plusOp__0[7]),
        .Q(out[7]),
        .R(SR));
  FDSE #(
    .INIT(1'b1)) 
    reset_accum_reg
       (.C(CLK),
        .CE(1'b1),
        .D(reg_output_addr),
        .Q(reset_accum),
        .S(SR));
  FDRE #(
    .INIT(1'b0)) 
    we_reg
       (.C(CLK),
        .CE(1'b1),
        .D(reg_output_addr),
        .Q(WEA),
        .R(SR));
endmodule

module datapath
   (CO,
    O,
    \ramb_bl.ramb36_sin_bl.ram36_bl ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_0 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_1 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_2 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_3 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_4 ,
    DIADI,
    DI,
    S,
    MUL1_OUT__85_carry_i_8_0,
    MUL1_OUT__85_carry_i_8_1,
    MUL1_OUT__85_carry__0_i_3_0,
    MUL1_OUT__85_carry__0_i_3_1,
    \REG1_reg[3]_0 ,
    \REG1_reg[3]_1 ,
    MUL1_OUT__85_carry__0_i_4_0,
    MUL1_OUT__85_carry__0_i_4_1,
    MUL1_OUT__85_carry__1_i_5,
    MUL1_OUT__85_carry__1_i_5_0,
    MUL1_OUT__85_carry_i_1_0,
    MUL1_OUT__85_carry_i_1_1,
    MUL1_OUT__85_carry__0_i_6_0,
    MUL1_OUT__85_carry__0_i_6_1,
    \REG1_reg[15]_0 ,
    \REG1_reg[15]_1 ,
    \REG1_reg[15]_2 ,
    \REG1_reg[15]_3 ,
    \REG2_reg[2]_0 ,
    \REG2_reg[2]_1 ,
    MUL2_OUT__85_carry_i_8_0,
    MUL2_OUT__85_carry_i_8_1,
    MUL2_OUT__85_carry__0_i_3_0,
    MUL2_OUT__85_carry__0_i_3_1,
    \REG2_reg[3]_0 ,
    \REG2_reg[3]_1 ,
    MUL2_OUT__85_carry__0_i_4_0,
    MUL2_OUT__85_carry__0_i_4_1,
    MUL2_OUT__85_carry__1_i_5,
    MUL2_OUT__85_carry__1_i_5_0,
    MUL2_OUT__85_carry_i_1_0,
    MUL2_OUT__85_carry_i_1_1,
    MUL2_OUT__85_carry__0_i_6_0,
    MUL2_OUT__85_carry__0_i_6_1,
    \REG2_reg[15]_0 ,
    \REG2_reg[15]_1 ,
    \REG2_reg[15]_2 ,
    \REG2_reg[15]_3 ,
    SR,
    E,
    CLK,
    \REG_ACCUM_reg[21]_0 ,
    \REG_ACCUM_reg[21]_1 );
  output [0:0]CO;
  output [1:0]O;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  output [20:0]DIADI;
  input [2:0]DI;
  input [3:0]S;
  input [3:0]MUL1_OUT__85_carry_i_8_0;
  input [3:0]MUL1_OUT__85_carry_i_8_1;
  input [1:0]MUL1_OUT__85_carry__0_i_3_0;
  input [1:0]MUL1_OUT__85_carry__0_i_3_1;
  input [2:0]\REG1_reg[3]_0 ;
  input [3:0]\REG1_reg[3]_1 ;
  input [3:0]MUL1_OUT__85_carry__0_i_4_0;
  input [3:0]MUL1_OUT__85_carry__0_i_4_1;
  input [1:0]MUL1_OUT__85_carry__1_i_5;
  input [1:0]MUL1_OUT__85_carry__1_i_5_0;
  input [2:0]MUL1_OUT__85_carry_i_1_0;
  input [3:0]MUL1_OUT__85_carry_i_1_1;
  input [3:0]MUL1_OUT__85_carry__0_i_6_0;
  input [3:0]MUL1_OUT__85_carry__0_i_6_1;
  input [0:0]\REG1_reg[15]_0 ;
  input [0:0]\REG1_reg[15]_1 ;
  input [1:0]\REG1_reg[15]_2 ;
  input [2:0]\REG1_reg[15]_3 ;
  input [2:0]\REG2_reg[2]_0 ;
  input [3:0]\REG2_reg[2]_1 ;
  input [3:0]MUL2_OUT__85_carry_i_8_0;
  input [3:0]MUL2_OUT__85_carry_i_8_1;
  input [1:0]MUL2_OUT__85_carry__0_i_3_0;
  input [1:0]MUL2_OUT__85_carry__0_i_3_1;
  input [2:0]\REG2_reg[3]_0 ;
  input [3:0]\REG2_reg[3]_1 ;
  input [3:0]MUL2_OUT__85_carry__0_i_4_0;
  input [3:0]MUL2_OUT__85_carry__0_i_4_1;
  input [1:0]MUL2_OUT__85_carry__1_i_5;
  input [1:0]MUL2_OUT__85_carry__1_i_5_0;
  input [2:0]MUL2_OUT__85_carry_i_1_0;
  input [3:0]MUL2_OUT__85_carry_i_1_1;
  input [3:0]MUL2_OUT__85_carry__0_i_6_0;
  input [3:0]MUL2_OUT__85_carry__0_i_6_1;
  input [0:0]\REG2_reg[15]_0 ;
  input [0:0]\REG2_reg[15]_1 ;
  input [1:0]\REG2_reg[15]_2 ;
  input [2:0]\REG2_reg[15]_3 ;
  input [0:0]SR;
  input [0:0]E;
  input CLK;
  input [0:0]\REG_ACCUM_reg[21]_0 ;
  input [0:0]\REG_ACCUM_reg[21]_1 ;

  wire [21:0]ADD_OUT;
  wire ADD_OUT_carry__0_i_1_n_0;
  wire ADD_OUT_carry__0_i_2_n_0;
  wire ADD_OUT_carry__0_i_3_n_0;
  wire ADD_OUT_carry__0_i_4_n_0;
  wire ADD_OUT_carry__0_n_0;
  wire ADD_OUT_carry__0_n_1;
  wire ADD_OUT_carry__0_n_2;
  wire ADD_OUT_carry__0_n_3;
  wire ADD_OUT_carry__1_i_1_n_0;
  wire ADD_OUT_carry__1_i_2_n_0;
  wire ADD_OUT_carry__1_i_3_n_0;
  wire ADD_OUT_carry__1_i_4_n_0;
  wire ADD_OUT_carry__1_n_0;
  wire ADD_OUT_carry__1_n_1;
  wire ADD_OUT_carry__1_n_2;
  wire ADD_OUT_carry__1_n_3;
  wire ADD_OUT_carry__2_i_1_n_0;
  wire ADD_OUT_carry__2_i_2_n_0;
  wire ADD_OUT_carry__2_i_3_n_0;
  wire ADD_OUT_carry__2_i_4_n_0;
  wire ADD_OUT_carry__2_i_5_n_0;
  wire ADD_OUT_carry__2_n_0;
  wire ADD_OUT_carry__2_n_1;
  wire ADD_OUT_carry__2_n_2;
  wire ADD_OUT_carry__2_n_3;
  wire ADD_OUT_carry_i_1_n_0;
  wire ADD_OUT_carry_i_2_n_0;
  wire ADD_OUT_carry_i_3_n_0;
  wire ADD_OUT_carry_i_4_n_0;
  wire ADD_OUT_carry_n_0;
  wire ADD_OUT_carry_n_1;
  wire ADD_OUT_carry_n_2;
  wire ADD_OUT_carry_n_3;
  wire \ADD_OUT_inferred__0/i__carry__0_n_0 ;
  wire \ADD_OUT_inferred__0/i__carry__0_n_1 ;
  wire \ADD_OUT_inferred__0/i__carry__0_n_2 ;
  wire \ADD_OUT_inferred__0/i__carry__0_n_3 ;
  wire \ADD_OUT_inferred__0/i__carry__1_n_0 ;
  wire \ADD_OUT_inferred__0/i__carry__1_n_1 ;
  wire \ADD_OUT_inferred__0/i__carry__1_n_2 ;
  wire \ADD_OUT_inferred__0/i__carry__1_n_3 ;
  wire \ADD_OUT_inferred__0/i__carry__2_n_0 ;
  wire \ADD_OUT_inferred__0/i__carry__2_n_1 ;
  wire \ADD_OUT_inferred__0/i__carry__2_n_2 ;
  wire \ADD_OUT_inferred__0/i__carry__2_n_3 ;
  wire \ADD_OUT_inferred__0/i__carry__3_n_0 ;
  wire \ADD_OUT_inferred__0/i__carry__3_n_1 ;
  wire \ADD_OUT_inferred__0/i__carry__3_n_2 ;
  wire \ADD_OUT_inferred__0/i__carry__3_n_3 ;
  wire \ADD_OUT_inferred__0/i__carry__4_n_3 ;
  wire \ADD_OUT_inferred__0/i__carry_n_0 ;
  wire \ADD_OUT_inferred__0/i__carry_n_1 ;
  wire \ADD_OUT_inferred__0/i__carry_n_2 ;
  wire \ADD_OUT_inferred__0/i__carry_n_3 ;
  wire CLK;
  wire [0:0]CO;
  wire [2:0]DI;
  wire [20:0]DIADI;
  wire [0:0]E;
  wire [15:0]MUL1_OUT;
  wire MUL1_OUT__0_carry__0_n_0;
  wire MUL1_OUT__0_carry__0_n_1;
  wire MUL1_OUT__0_carry__0_n_2;
  wire MUL1_OUT__0_carry__0_n_3;
  wire MUL1_OUT__0_carry__0_n_4;
  wire MUL1_OUT__0_carry__0_n_5;
  wire MUL1_OUT__0_carry__0_n_6;
  wire MUL1_OUT__0_carry__0_n_7;
  wire MUL1_OUT__0_carry__1_n_1;
  wire MUL1_OUT__0_carry__1_n_3;
  wire MUL1_OUT__0_carry__1_n_6;
  wire MUL1_OUT__0_carry__1_n_7;
  wire MUL1_OUT__0_carry_n_0;
  wire MUL1_OUT__0_carry_n_1;
  wire MUL1_OUT__0_carry_n_2;
  wire MUL1_OUT__0_carry_n_3;
  wire MUL1_OUT__0_carry_n_4;
  wire MUL1_OUT__30_carry__0_n_0;
  wire MUL1_OUT__30_carry__0_n_1;
  wire MUL1_OUT__30_carry__0_n_2;
  wire MUL1_OUT__30_carry__0_n_3;
  wire MUL1_OUT__30_carry__0_n_4;
  wire MUL1_OUT__30_carry__0_n_5;
  wire MUL1_OUT__30_carry__0_n_6;
  wire MUL1_OUT__30_carry__0_n_7;
  wire MUL1_OUT__30_carry__1_n_3;
  wire MUL1_OUT__30_carry_n_0;
  wire MUL1_OUT__30_carry_n_1;
  wire MUL1_OUT__30_carry_n_2;
  wire MUL1_OUT__30_carry_n_3;
  wire MUL1_OUT__30_carry_n_4;
  wire MUL1_OUT__30_carry_n_5;
  wire MUL1_OUT__30_carry_n_6;
  wire MUL1_OUT__30_carry_n_7;
  wire MUL1_OUT__59_carry__0_n_0;
  wire MUL1_OUT__59_carry__0_n_1;
  wire MUL1_OUT__59_carry__0_n_2;
  wire MUL1_OUT__59_carry__0_n_3;
  wire MUL1_OUT__59_carry__0_n_7;
  wire MUL1_OUT__59_carry__1_n_3;
  wire MUL1_OUT__59_carry__1_n_6;
  wire MUL1_OUT__59_carry_n_0;
  wire MUL1_OUT__59_carry_n_1;
  wire MUL1_OUT__59_carry_n_2;
  wire MUL1_OUT__59_carry_n_3;
  wire MUL1_OUT__59_carry_n_4;
  wire MUL1_OUT__59_carry_n_5;
  wire MUL1_OUT__59_carry_n_6;
  wire MUL1_OUT__59_carry_n_7;
  wire MUL1_OUT__85_carry__0_i_1_n_0;
  wire MUL1_OUT__85_carry__0_i_2_n_0;
  wire [1:0]MUL1_OUT__85_carry__0_i_3_0;
  wire [1:0]MUL1_OUT__85_carry__0_i_3_1;
  wire MUL1_OUT__85_carry__0_i_3_n_0;
  wire [3:0]MUL1_OUT__85_carry__0_i_4_0;
  wire [3:0]MUL1_OUT__85_carry__0_i_4_1;
  wire MUL1_OUT__85_carry__0_i_4_n_0;
  wire MUL1_OUT__85_carry__0_i_5_n_0;
  wire [3:0]MUL1_OUT__85_carry__0_i_6_0;
  wire [3:0]MUL1_OUT__85_carry__0_i_6_1;
  wire MUL1_OUT__85_carry__0_i_6_n_0;
  wire MUL1_OUT__85_carry__0_i_7_n_0;
  wire MUL1_OUT__85_carry__0_i_8_n_0;
  wire MUL1_OUT__85_carry__0_n_0;
  wire MUL1_OUT__85_carry__0_n_1;
  wire MUL1_OUT__85_carry__0_n_2;
  wire MUL1_OUT__85_carry__0_n_3;
  wire [1:0]MUL1_OUT__85_carry__1_i_5;
  wire [1:0]MUL1_OUT__85_carry__1_i_5_0;
  wire MUL1_OUT__85_carry__1_n_1;
  wire MUL1_OUT__85_carry__1_n_2;
  wire MUL1_OUT__85_carry__1_n_3;
  wire [2:0]MUL1_OUT__85_carry_i_1_0;
  wire [3:0]MUL1_OUT__85_carry_i_1_1;
  wire MUL1_OUT__85_carry_i_1_n_0;
  wire MUL1_OUT__85_carry_i_2_n_0;
  wire MUL1_OUT__85_carry_i_3_n_0;
  wire MUL1_OUT__85_carry_i_4_n_0;
  wire MUL1_OUT__85_carry_i_5_n_0;
  wire MUL1_OUT__85_carry_i_6_n_0;
  wire MUL1_OUT__85_carry_i_7_n_0;
  wire [3:0]MUL1_OUT__85_carry_i_8_0;
  wire [3:0]MUL1_OUT__85_carry_i_8_1;
  wire MUL1_OUT__85_carry_i_8_n_0;
  wire MUL1_OUT__85_carry_n_0;
  wire MUL1_OUT__85_carry_n_1;
  wire MUL1_OUT__85_carry_n_2;
  wire MUL1_OUT__85_carry_n_3;
  wire [15:0]MUL2_OUT;
  wire MUL2_OUT__0_carry__0_n_0;
  wire MUL2_OUT__0_carry__0_n_1;
  wire MUL2_OUT__0_carry__0_n_2;
  wire MUL2_OUT__0_carry__0_n_3;
  wire MUL2_OUT__0_carry__0_n_4;
  wire MUL2_OUT__0_carry__0_n_5;
  wire MUL2_OUT__0_carry__0_n_6;
  wire MUL2_OUT__0_carry__0_n_7;
  wire MUL2_OUT__0_carry__1_n_1;
  wire MUL2_OUT__0_carry__1_n_3;
  wire MUL2_OUT__0_carry__1_n_6;
  wire MUL2_OUT__0_carry__1_n_7;
  wire MUL2_OUT__0_carry_n_0;
  wire MUL2_OUT__0_carry_n_1;
  wire MUL2_OUT__0_carry_n_2;
  wire MUL2_OUT__0_carry_n_3;
  wire MUL2_OUT__0_carry_n_4;
  wire MUL2_OUT__30_carry__0_n_0;
  wire MUL2_OUT__30_carry__0_n_1;
  wire MUL2_OUT__30_carry__0_n_2;
  wire MUL2_OUT__30_carry__0_n_3;
  wire MUL2_OUT__30_carry__0_n_4;
  wire MUL2_OUT__30_carry__0_n_5;
  wire MUL2_OUT__30_carry__0_n_6;
  wire MUL2_OUT__30_carry__0_n_7;
  wire MUL2_OUT__30_carry__1_n_3;
  wire MUL2_OUT__30_carry_n_0;
  wire MUL2_OUT__30_carry_n_1;
  wire MUL2_OUT__30_carry_n_2;
  wire MUL2_OUT__30_carry_n_3;
  wire MUL2_OUT__30_carry_n_4;
  wire MUL2_OUT__30_carry_n_5;
  wire MUL2_OUT__30_carry_n_6;
  wire MUL2_OUT__30_carry_n_7;
  wire MUL2_OUT__59_carry__0_n_0;
  wire MUL2_OUT__59_carry__0_n_1;
  wire MUL2_OUT__59_carry__0_n_2;
  wire MUL2_OUT__59_carry__0_n_3;
  wire MUL2_OUT__59_carry__0_n_7;
  wire MUL2_OUT__59_carry__1_n_3;
  wire MUL2_OUT__59_carry__1_n_6;
  wire MUL2_OUT__59_carry_n_0;
  wire MUL2_OUT__59_carry_n_1;
  wire MUL2_OUT__59_carry_n_2;
  wire MUL2_OUT__59_carry_n_3;
  wire MUL2_OUT__59_carry_n_4;
  wire MUL2_OUT__59_carry_n_5;
  wire MUL2_OUT__59_carry_n_6;
  wire MUL2_OUT__59_carry_n_7;
  wire MUL2_OUT__85_carry__0_i_1_n_0;
  wire MUL2_OUT__85_carry__0_i_2_n_0;
  wire [1:0]MUL2_OUT__85_carry__0_i_3_0;
  wire [1:0]MUL2_OUT__85_carry__0_i_3_1;
  wire MUL2_OUT__85_carry__0_i_3_n_0;
  wire [3:0]MUL2_OUT__85_carry__0_i_4_0;
  wire [3:0]MUL2_OUT__85_carry__0_i_4_1;
  wire MUL2_OUT__85_carry__0_i_4_n_0;
  wire MUL2_OUT__85_carry__0_i_5_n_0;
  wire [3:0]MUL2_OUT__85_carry__0_i_6_0;
  wire [3:0]MUL2_OUT__85_carry__0_i_6_1;
  wire MUL2_OUT__85_carry__0_i_6_n_0;
  wire MUL2_OUT__85_carry__0_i_7_n_0;
  wire MUL2_OUT__85_carry__0_i_8_n_0;
  wire MUL2_OUT__85_carry__0_n_0;
  wire MUL2_OUT__85_carry__0_n_1;
  wire MUL2_OUT__85_carry__0_n_2;
  wire MUL2_OUT__85_carry__0_n_3;
  wire [1:0]MUL2_OUT__85_carry__1_i_5;
  wire [1:0]MUL2_OUT__85_carry__1_i_5_0;
  wire MUL2_OUT__85_carry__1_n_1;
  wire MUL2_OUT__85_carry__1_n_2;
  wire MUL2_OUT__85_carry__1_n_3;
  wire [2:0]MUL2_OUT__85_carry_i_1_0;
  wire [3:0]MUL2_OUT__85_carry_i_1_1;
  wire MUL2_OUT__85_carry_i_1_n_0;
  wire MUL2_OUT__85_carry_i_2_n_0;
  wire MUL2_OUT__85_carry_i_3_n_0;
  wire MUL2_OUT__85_carry_i_4_n_0;
  wire MUL2_OUT__85_carry_i_5_n_0;
  wire MUL2_OUT__85_carry_i_6_n_0;
  wire MUL2_OUT__85_carry_i_7_n_0;
  wire [3:0]MUL2_OUT__85_carry_i_8_0;
  wire [3:0]MUL2_OUT__85_carry_i_8_1;
  wire MUL2_OUT__85_carry_i_8_n_0;
  wire MUL2_OUT__85_carry_n_0;
  wire MUL2_OUT__85_carry_n_1;
  wire MUL2_OUT__85_carry_n_2;
  wire MUL2_OUT__85_carry_n_3;
  wire [1:0]O;
  wire [15:0]PCIN;
  wire [15:0]REG1;
  wire [0:0]\REG1_reg[15]_0 ;
  wire [0:0]\REG1_reg[15]_1 ;
  wire [1:0]\REG1_reg[15]_2 ;
  wire [2:0]\REG1_reg[15]_3 ;
  wire [2:0]\REG1_reg[3]_0 ;
  wire [3:0]\REG1_reg[3]_1 ;
  wire [15:0]REG2;
  wire [0:0]\REG2_reg[15]_0 ;
  wire [0:0]\REG2_reg[15]_1 ;
  wire [1:0]\REG2_reg[15]_2 ;
  wire [2:0]\REG2_reg[15]_3 ;
  wire [2:0]\REG2_reg[2]_0 ;
  wire [3:0]\REG2_reg[2]_1 ;
  wire [2:0]\REG2_reg[3]_0 ;
  wire [3:0]\REG2_reg[3]_1 ;
  wire [0:0]\REG_ACCUM_reg[21]_0 ;
  wire [0:0]\REG_ACCUM_reg[21]_1 ;
  wire \REG_ACCUM_reg_n_0_[0] ;
  wire \REG_ACCUM_reg_n_0_[10] ;
  wire \REG_ACCUM_reg_n_0_[11] ;
  wire \REG_ACCUM_reg_n_0_[12] ;
  wire \REG_ACCUM_reg_n_0_[13] ;
  wire \REG_ACCUM_reg_n_0_[14] ;
  wire \REG_ACCUM_reg_n_0_[15] ;
  wire \REG_ACCUM_reg_n_0_[16] ;
  wire \REG_ACCUM_reg_n_0_[17] ;
  wire \REG_ACCUM_reg_n_0_[18] ;
  wire \REG_ACCUM_reg_n_0_[19] ;
  wire \REG_ACCUM_reg_n_0_[1] ;
  wire \REG_ACCUM_reg_n_0_[20] ;
  wire \REG_ACCUM_reg_n_0_[21] ;
  wire \REG_ACCUM_reg_n_0_[2] ;
  wire \REG_ACCUM_reg_n_0_[3] ;
  wire \REG_ACCUM_reg_n_0_[4] ;
  wire \REG_ACCUM_reg_n_0_[5] ;
  wire \REG_ACCUM_reg_n_0_[6] ;
  wire \REG_ACCUM_reg_n_0_[7] ;
  wire \REG_ACCUM_reg_n_0_[8] ;
  wire \REG_ACCUM_reg_n_0_[9] ;
  wire [3:0]S;
  wire [0:0]SR;
  wire i__carry__0_i_1_n_0;
  wire i__carry__0_i_2_n_0;
  wire i__carry__0_i_3_n_0;
  wire i__carry__0_i_4_n_0;
  wire i__carry__1_i_1_n_0;
  wire i__carry__1_i_2_n_0;
  wire i__carry__1_i_3_n_0;
  wire i__carry__1_i_4_n_0;
  wire i__carry__2_i_1_n_0;
  wire i__carry__2_i_2_n_0;
  wire i__carry__2_i_3_n_0;
  wire i__carry__2_i_4_n_0;
  wire i__carry__3_i_1_n_0;
  wire i__carry__3_i_2_n_0;
  wire i__carry__3_i_3_n_0;
  wire i__carry__3_i_4_n_0;
  wire i__carry__3_i_5_n_3;
  wire i__carry__4_i_1_n_0;
  wire i__carry__4_i_2_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_4_n_0;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  wire [3:1]\NLW_ADD_OUT_inferred__0/i__carry__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_ADD_OUT_inferred__0/i__carry__4_O_UNCONNECTED ;
  wire [3:1]NLW_MUL1_OUT__0_carry__1_CO_UNCONNECTED;
  wire [3:2]NLW_MUL1_OUT__0_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_MUL1_OUT__30_carry__1_CO_UNCONNECTED;
  wire [3:2]NLW_MUL1_OUT__30_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_MUL1_OUT__59_carry__1_CO_UNCONNECTED;
  wire [3:2]NLW_MUL1_OUT__59_carry__1_O_UNCONNECTED;
  wire [3:3]NLW_MUL1_OUT__85_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_MUL2_OUT__0_carry__1_CO_UNCONNECTED;
  wire [3:2]NLW_MUL2_OUT__0_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_MUL2_OUT__30_carry__1_CO_UNCONNECTED;
  wire [3:2]NLW_MUL2_OUT__30_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_MUL2_OUT__59_carry__1_CO_UNCONNECTED;
  wire [3:2]NLW_MUL2_OUT__59_carry__1_O_UNCONNECTED;
  wire [3:3]NLW_MUL2_OUT__85_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_i__carry__3_i_5_CO_UNCONNECTED;
  wire [3:0]NLW_i__carry__3_i_5_O_UNCONNECTED;

  CARRY4 ADD_OUT_carry
       (.CI(1'b0),
        .CO({ADD_OUT_carry_n_0,ADD_OUT_carry_n_1,ADD_OUT_carry_n_2,ADD_OUT_carry_n_3}),
        .CYINIT(1'b0),
        .DI(REG2[3:0]),
        .O(PCIN[3:0]),
        .S({ADD_OUT_carry_i_1_n_0,ADD_OUT_carry_i_2_n_0,ADD_OUT_carry_i_3_n_0,ADD_OUT_carry_i_4_n_0}));
  CARRY4 ADD_OUT_carry__0
       (.CI(ADD_OUT_carry_n_0),
        .CO({ADD_OUT_carry__0_n_0,ADD_OUT_carry__0_n_1,ADD_OUT_carry__0_n_2,ADD_OUT_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(REG2[7:4]),
        .O(PCIN[7:4]),
        .S({ADD_OUT_carry__0_i_1_n_0,ADD_OUT_carry__0_i_2_n_0,ADD_OUT_carry__0_i_3_n_0,ADD_OUT_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__0_i_1
       (.I0(REG2[7]),
        .I1(REG1[7]),
        .O(ADD_OUT_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__0_i_2
       (.I0(REG2[6]),
        .I1(REG1[6]),
        .O(ADD_OUT_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__0_i_3
       (.I0(REG2[5]),
        .I1(REG1[5]),
        .O(ADD_OUT_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__0_i_4
       (.I0(REG2[4]),
        .I1(REG1[4]),
        .O(ADD_OUT_carry__0_i_4_n_0));
  CARRY4 ADD_OUT_carry__1
       (.CI(ADD_OUT_carry__0_n_0),
        .CO({ADD_OUT_carry__1_n_0,ADD_OUT_carry__1_n_1,ADD_OUT_carry__1_n_2,ADD_OUT_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(REG2[11:8]),
        .O(PCIN[11:8]),
        .S({ADD_OUT_carry__1_i_1_n_0,ADD_OUT_carry__1_i_2_n_0,ADD_OUT_carry__1_i_3_n_0,ADD_OUT_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__1_i_1
       (.I0(REG2[11]),
        .I1(REG1[11]),
        .O(ADD_OUT_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__1_i_2
       (.I0(REG2[10]),
        .I1(REG1[10]),
        .O(ADD_OUT_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__1_i_3
       (.I0(REG2[9]),
        .I1(REG1[9]),
        .O(ADD_OUT_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__1_i_4
       (.I0(REG2[8]),
        .I1(REG1[8]),
        .O(ADD_OUT_carry__1_i_4_n_0));
  CARRY4 ADD_OUT_carry__2
       (.CI(ADD_OUT_carry__1_n_0),
        .CO({ADD_OUT_carry__2_n_0,ADD_OUT_carry__2_n_1,ADD_OUT_carry__2_n_2,ADD_OUT_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({ADD_OUT_carry__2_i_1_n_0,REG2[14:12]}),
        .O(PCIN[15:12]),
        .S({ADD_OUT_carry__2_i_2_n_0,ADD_OUT_carry__2_i_3_n_0,ADD_OUT_carry__2_i_4_n_0,ADD_OUT_carry__2_i_5_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    ADD_OUT_carry__2_i_1
       (.I0(REG2[15]),
        .O(ADD_OUT_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__2_i_2
       (.I0(REG2[15]),
        .I1(REG1[15]),
        .O(ADD_OUT_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__2_i_3
       (.I0(REG2[14]),
        .I1(REG1[14]),
        .O(ADD_OUT_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__2_i_4
       (.I0(REG2[13]),
        .I1(REG1[13]),
        .O(ADD_OUT_carry__2_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry__2_i_5
       (.I0(REG2[12]),
        .I1(REG1[12]),
        .O(ADD_OUT_carry__2_i_5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry_i_1
       (.I0(REG2[3]),
        .I1(REG1[3]),
        .O(ADD_OUT_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry_i_2
       (.I0(REG2[2]),
        .I1(REG1[2]),
        .O(ADD_OUT_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry_i_3
       (.I0(REG2[1]),
        .I1(REG1[1]),
        .O(ADD_OUT_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    ADD_OUT_carry_i_4
       (.I0(REG2[0]),
        .I1(REG1[0]),
        .O(ADD_OUT_carry_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ADD_OUT_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\ADD_OUT_inferred__0/i__carry_n_0 ,\ADD_OUT_inferred__0/i__carry_n_1 ,\ADD_OUT_inferred__0/i__carry_n_2 ,\ADD_OUT_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({\REG_ACCUM_reg_n_0_[3] ,\REG_ACCUM_reg_n_0_[2] ,\REG_ACCUM_reg_n_0_[1] ,\REG_ACCUM_reg_n_0_[0] }),
        .O(ADD_OUT[3:0]),
        .S({i__carry_i_1_n_0,i__carry_i_2_n_0,i__carry_i_3_n_0,i__carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ADD_OUT_inferred__0/i__carry__0 
       (.CI(\ADD_OUT_inferred__0/i__carry_n_0 ),
        .CO({\ADD_OUT_inferred__0/i__carry__0_n_0 ,\ADD_OUT_inferred__0/i__carry__0_n_1 ,\ADD_OUT_inferred__0/i__carry__0_n_2 ,\ADD_OUT_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({\REG_ACCUM_reg_n_0_[7] ,\REG_ACCUM_reg_n_0_[6] ,\REG_ACCUM_reg_n_0_[5] ,\REG_ACCUM_reg_n_0_[4] }),
        .O(ADD_OUT[7:4]),
        .S({i__carry__0_i_1_n_0,i__carry__0_i_2_n_0,i__carry__0_i_3_n_0,i__carry__0_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ADD_OUT_inferred__0/i__carry__1 
       (.CI(\ADD_OUT_inferred__0/i__carry__0_n_0 ),
        .CO({\ADD_OUT_inferred__0/i__carry__1_n_0 ,\ADD_OUT_inferred__0/i__carry__1_n_1 ,\ADD_OUT_inferred__0/i__carry__1_n_2 ,\ADD_OUT_inferred__0/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI({\REG_ACCUM_reg_n_0_[11] ,\REG_ACCUM_reg_n_0_[10] ,\REG_ACCUM_reg_n_0_[9] ,\REG_ACCUM_reg_n_0_[8] }),
        .O(ADD_OUT[11:8]),
        .S({i__carry__1_i_1_n_0,i__carry__1_i_2_n_0,i__carry__1_i_3_n_0,i__carry__1_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ADD_OUT_inferred__0/i__carry__2 
       (.CI(\ADD_OUT_inferred__0/i__carry__1_n_0 ),
        .CO({\ADD_OUT_inferred__0/i__carry__2_n_0 ,\ADD_OUT_inferred__0/i__carry__2_n_1 ,\ADD_OUT_inferred__0/i__carry__2_n_2 ,\ADD_OUT_inferred__0/i__carry__2_n_3 }),
        .CYINIT(1'b0),
        .DI({\REG_ACCUM_reg_n_0_[15] ,\REG_ACCUM_reg_n_0_[14] ,\REG_ACCUM_reg_n_0_[13] ,\REG_ACCUM_reg_n_0_[12] }),
        .O(ADD_OUT[15:12]),
        .S({i__carry__2_i_1_n_0,i__carry__2_i_2_n_0,i__carry__2_i_3_n_0,i__carry__2_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ADD_OUT_inferred__0/i__carry__3 
       (.CI(\ADD_OUT_inferred__0/i__carry__2_n_0 ),
        .CO({\ADD_OUT_inferred__0/i__carry__3_n_0 ,\ADD_OUT_inferred__0/i__carry__3_n_1 ,\ADD_OUT_inferred__0/i__carry__3_n_2 ,\ADD_OUT_inferred__0/i__carry__3_n_3 }),
        .CYINIT(1'b0),
        .DI({\REG_ACCUM_reg_n_0_[19] ,\REG_ACCUM_reg_n_0_[18] ,\REG_ACCUM_reg_n_0_[17] ,\REG_ACCUM_reg_n_0_[16] }),
        .O(ADD_OUT[19:16]),
        .S({i__carry__3_i_1_n_0,i__carry__3_i_2_n_0,i__carry__3_i_3_n_0,i__carry__3_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ADD_OUT_inferred__0/i__carry__4 
       (.CI(\ADD_OUT_inferred__0/i__carry__3_n_0 ),
        .CO({\NLW_ADD_OUT_inferred__0/i__carry__4_CO_UNCONNECTED [3:1],\ADD_OUT_inferred__0/i__carry__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\REG_ACCUM_reg_n_0_[20] }),
        .O({\NLW_ADD_OUT_inferred__0/i__carry__4_O_UNCONNECTED [3:2],ADD_OUT[21:20]}),
        .S({1'b0,1'b0,i__carry__4_i_1_n_0,i__carry__4_i_2_n_0}));
  CARRY4 MUL1_OUT__0_carry
       (.CI(1'b0),
        .CO({MUL1_OUT__0_carry_n_0,MUL1_OUT__0_carry_n_1,MUL1_OUT__0_carry_n_2,MUL1_OUT__0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({DI,1'b0}),
        .O({MUL1_OUT__0_carry_n_4,MUL1_OUT[2:0]}),
        .S(S));
  CARRY4 MUL1_OUT__0_carry__0
       (.CI(MUL1_OUT__0_carry_n_0),
        .CO({MUL1_OUT__0_carry__0_n_0,MUL1_OUT__0_carry__0_n_1,MUL1_OUT__0_carry__0_n_2,MUL1_OUT__0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(MUL1_OUT__85_carry_i_8_0),
        .O({MUL1_OUT__0_carry__0_n_4,MUL1_OUT__0_carry__0_n_5,MUL1_OUT__0_carry__0_n_6,MUL1_OUT__0_carry__0_n_7}),
        .S(MUL1_OUT__85_carry_i_8_1));
  CARRY4 MUL1_OUT__0_carry__1
       (.CI(MUL1_OUT__0_carry__0_n_0),
        .CO({NLW_MUL1_OUT__0_carry__1_CO_UNCONNECTED[3],MUL1_OUT__0_carry__1_n_1,NLW_MUL1_OUT__0_carry__1_CO_UNCONNECTED[1],MUL1_OUT__0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,MUL1_OUT__85_carry__0_i_3_0}),
        .O({NLW_MUL1_OUT__0_carry__1_O_UNCONNECTED[3:2],MUL1_OUT__0_carry__1_n_6,MUL1_OUT__0_carry__1_n_7}),
        .S({1'b0,1'b1,MUL1_OUT__85_carry__0_i_3_1}));
  CARRY4 MUL1_OUT__30_carry
       (.CI(1'b0),
        .CO({MUL1_OUT__30_carry_n_0,MUL1_OUT__30_carry_n_1,MUL1_OUT__30_carry_n_2,MUL1_OUT__30_carry_n_3}),
        .CYINIT(1'b0),
        .DI({\REG1_reg[3]_0 ,1'b0}),
        .O({MUL1_OUT__30_carry_n_4,MUL1_OUT__30_carry_n_5,MUL1_OUT__30_carry_n_6,MUL1_OUT__30_carry_n_7}),
        .S(\REG1_reg[3]_1 ));
  CARRY4 MUL1_OUT__30_carry__0
       (.CI(MUL1_OUT__30_carry_n_0),
        .CO({MUL1_OUT__30_carry__0_n_0,MUL1_OUT__30_carry__0_n_1,MUL1_OUT__30_carry__0_n_2,MUL1_OUT__30_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(MUL1_OUT__85_carry__0_i_4_0),
        .O({MUL1_OUT__30_carry__0_n_4,MUL1_OUT__30_carry__0_n_5,MUL1_OUT__30_carry__0_n_6,MUL1_OUT__30_carry__0_n_7}),
        .S(MUL1_OUT__85_carry__0_i_4_1));
  CARRY4 MUL1_OUT__30_carry__1
       (.CI(MUL1_OUT__30_carry__0_n_0),
        .CO({NLW_MUL1_OUT__30_carry__1_CO_UNCONNECTED[3],CO,NLW_MUL1_OUT__30_carry__1_CO_UNCONNECTED[1],MUL1_OUT__30_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,MUL1_OUT__85_carry__1_i_5}),
        .O({NLW_MUL1_OUT__30_carry__1_O_UNCONNECTED[3:2],O}),
        .S({1'b0,1'b1,MUL1_OUT__85_carry__1_i_5_0}));
  CARRY4 MUL1_OUT__59_carry
       (.CI(1'b0),
        .CO({MUL1_OUT__59_carry_n_0,MUL1_OUT__59_carry_n_1,MUL1_OUT__59_carry_n_2,MUL1_OUT__59_carry_n_3}),
        .CYINIT(1'b0),
        .DI({MUL1_OUT__85_carry_i_1_0,1'b0}),
        .O({MUL1_OUT__59_carry_n_4,MUL1_OUT__59_carry_n_5,MUL1_OUT__59_carry_n_6,MUL1_OUT__59_carry_n_7}),
        .S(MUL1_OUT__85_carry_i_1_1));
  CARRY4 MUL1_OUT__59_carry__0
       (.CI(MUL1_OUT__59_carry_n_0),
        .CO({MUL1_OUT__59_carry__0_n_0,MUL1_OUT__59_carry__0_n_1,MUL1_OUT__59_carry__0_n_2,MUL1_OUT__59_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(MUL1_OUT__85_carry__0_i_6_0),
        .O({\ramb_bl.ramb36_sin_bl.ram36_bl ,MUL1_OUT__59_carry__0_n_7}),
        .S(MUL1_OUT__85_carry__0_i_6_1));
  CARRY4 MUL1_OUT__59_carry__1
       (.CI(MUL1_OUT__59_carry__0_n_0),
        .CO({NLW_MUL1_OUT__59_carry__1_CO_UNCONNECTED[3:1],MUL1_OUT__59_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\REG1_reg[15]_0 }),
        .O({NLW_MUL1_OUT__59_carry__1_O_UNCONNECTED[3:2],MUL1_OUT__59_carry__1_n_6,\ramb_bl.ramb36_sin_bl.ram36_bl_0 }),
        .S({1'b0,1'b0,1'b1,\REG1_reg[15]_1 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 MUL1_OUT__85_carry
       (.CI(1'b0),
        .CO({MUL1_OUT__85_carry_n_0,MUL1_OUT__85_carry_n_1,MUL1_OUT__85_carry_n_2,MUL1_OUT__85_carry_n_3}),
        .CYINIT(1'b0),
        .DI({MUL1_OUT__85_carry_i_1_n_0,MUL1_OUT__85_carry_i_2_n_0,MUL1_OUT__85_carry_i_3_n_0,MUL1_OUT__85_carry_i_4_n_0}),
        .O(MUL1_OUT[7:4]),
        .S({MUL1_OUT__85_carry_i_5_n_0,MUL1_OUT__85_carry_i_6_n_0,MUL1_OUT__85_carry_i_7_n_0,MUL1_OUT__85_carry_i_8_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 MUL1_OUT__85_carry__0
       (.CI(MUL1_OUT__85_carry_n_0),
        .CO({MUL1_OUT__85_carry__0_n_0,MUL1_OUT__85_carry__0_n_1,MUL1_OUT__85_carry__0_n_2,MUL1_OUT__85_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({MUL1_OUT__85_carry__0_i_1_n_0,MUL1_OUT__85_carry__0_i_2_n_0,MUL1_OUT__85_carry__0_i_3_n_0,MUL1_OUT__85_carry__0_i_4_n_0}),
        .O(MUL1_OUT[11:8]),
        .S({MUL1_OUT__85_carry__0_i_5_n_0,MUL1_OUT__85_carry__0_i_6_n_0,MUL1_OUT__85_carry__0_i_7_n_0,MUL1_OUT__85_carry__0_i_8_n_0}));
  LUT3 #(
    .INIT(8'hE8)) 
    MUL1_OUT__85_carry__0_i_1
       (.I0(MUL1_OUT__59_carry__0_n_7),
        .I1(MUL1_OUT__30_carry__0_n_4),
        .I2(MUL1_OUT__0_carry__1_n_1),
        .O(MUL1_OUT__85_carry__0_i_1_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL1_OUT__85_carry__0_i_2
       (.I0(MUL1_OUT__59_carry_n_4),
        .I1(MUL1_OUT__30_carry__0_n_5),
        .I2(MUL1_OUT__0_carry__1_n_6),
        .O(MUL1_OUT__85_carry__0_i_2_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL1_OUT__85_carry__0_i_3
       (.I0(MUL1_OUT__59_carry_n_5),
        .I1(MUL1_OUT__30_carry__0_n_6),
        .I2(MUL1_OUT__0_carry__1_n_7),
        .O(MUL1_OUT__85_carry__0_i_3_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL1_OUT__85_carry__0_i_4
       (.I0(MUL1_OUT__59_carry_n_6),
        .I1(MUL1_OUT__30_carry__0_n_7),
        .I2(MUL1_OUT__0_carry__0_n_4),
        .O(MUL1_OUT__85_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hE81717E8)) 
    MUL1_OUT__85_carry__0_i_5
       (.I0(MUL1_OUT__0_carry__1_n_1),
        .I1(MUL1_OUT__30_carry__0_n_4),
        .I2(MUL1_OUT__59_carry__0_n_7),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl [0]),
        .I4(O[0]),
        .O(MUL1_OUT__85_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    MUL1_OUT__85_carry__0_i_6
       (.I0(MUL1_OUT__85_carry__0_i_2_n_0),
        .I1(MUL1_OUT__30_carry__0_n_4),
        .I2(MUL1_OUT__59_carry__0_n_7),
        .I3(MUL1_OUT__0_carry__1_n_1),
        .O(MUL1_OUT__85_carry__0_i_6_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL1_OUT__85_carry__0_i_7
       (.I0(MUL1_OUT__59_carry_n_4),
        .I1(MUL1_OUT__30_carry__0_n_5),
        .I2(MUL1_OUT__0_carry__1_n_6),
        .I3(MUL1_OUT__85_carry__0_i_3_n_0),
        .O(MUL1_OUT__85_carry__0_i_7_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL1_OUT__85_carry__0_i_8
       (.I0(MUL1_OUT__59_carry_n_5),
        .I1(MUL1_OUT__30_carry__0_n_6),
        .I2(MUL1_OUT__0_carry__1_n_7),
        .I3(MUL1_OUT__85_carry__0_i_4_n_0),
        .O(MUL1_OUT__85_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 MUL1_OUT__85_carry__1
       (.CI(MUL1_OUT__85_carry__0_n_0),
        .CO({NLW_MUL1_OUT__85_carry__1_CO_UNCONNECTED[3],MUL1_OUT__85_carry__1_n_1,MUL1_OUT__85_carry__1_n_2,MUL1_OUT__85_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,\ramb_bl.ramb36_sin_bl.ram36_bl_0 ,\REG1_reg[15]_2 }),
        .O(MUL1_OUT[15:12]),
        .S({MUL1_OUT__59_carry__1_n_6,\REG1_reg[15]_3 }));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL1_OUT__85_carry_i_1
       (.I0(MUL1_OUT__59_carry_n_7),
        .I1(MUL1_OUT__30_carry_n_4),
        .I2(MUL1_OUT__0_carry__0_n_5),
        .O(MUL1_OUT__85_carry_i_1_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    MUL1_OUT__85_carry_i_2
       (.I0(MUL1_OUT__30_carry_n_5),
        .I1(MUL1_OUT__0_carry__0_n_6),
        .O(MUL1_OUT__85_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    MUL1_OUT__85_carry_i_3
       (.I0(MUL1_OUT__0_carry__0_n_7),
        .I1(MUL1_OUT__30_carry_n_6),
        .O(MUL1_OUT__85_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    MUL1_OUT__85_carry_i_4
       (.I0(MUL1_OUT__0_carry_n_4),
        .I1(MUL1_OUT__30_carry_n_7),
        .O(MUL1_OUT__85_carry_i_4_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL1_OUT__85_carry_i_5
       (.I0(MUL1_OUT__59_carry_n_6),
        .I1(MUL1_OUT__30_carry__0_n_7),
        .I2(MUL1_OUT__0_carry__0_n_4),
        .I3(MUL1_OUT__85_carry_i_1_n_0),
        .O(MUL1_OUT__85_carry_i_5_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL1_OUT__85_carry_i_6
       (.I0(MUL1_OUT__59_carry_n_7),
        .I1(MUL1_OUT__30_carry_n_4),
        .I2(MUL1_OUT__0_carry__0_n_5),
        .I3(MUL1_OUT__85_carry_i_2_n_0),
        .O(MUL1_OUT__85_carry_i_6_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h9666)) 
    MUL1_OUT__85_carry_i_7
       (.I0(MUL1_OUT__30_carry_n_5),
        .I1(MUL1_OUT__0_carry__0_n_6),
        .I2(MUL1_OUT__0_carry__0_n_7),
        .I3(MUL1_OUT__30_carry_n_6),
        .O(MUL1_OUT__85_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h8778)) 
    MUL1_OUT__85_carry_i_8
       (.I0(MUL1_OUT__0_carry_n_4),
        .I1(MUL1_OUT__30_carry_n_7),
        .I2(MUL1_OUT__30_carry_n_6),
        .I3(MUL1_OUT__0_carry__0_n_7),
        .O(MUL1_OUT__85_carry_i_8_n_0));
  CARRY4 MUL2_OUT__0_carry
       (.CI(1'b0),
        .CO({MUL2_OUT__0_carry_n_0,MUL2_OUT__0_carry_n_1,MUL2_OUT__0_carry_n_2,MUL2_OUT__0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({\REG2_reg[2]_0 ,1'b0}),
        .O({MUL2_OUT__0_carry_n_4,MUL2_OUT[2:0]}),
        .S(\REG2_reg[2]_1 ));
  CARRY4 MUL2_OUT__0_carry__0
       (.CI(MUL2_OUT__0_carry_n_0),
        .CO({MUL2_OUT__0_carry__0_n_0,MUL2_OUT__0_carry__0_n_1,MUL2_OUT__0_carry__0_n_2,MUL2_OUT__0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(MUL2_OUT__85_carry_i_8_0),
        .O({MUL2_OUT__0_carry__0_n_4,MUL2_OUT__0_carry__0_n_5,MUL2_OUT__0_carry__0_n_6,MUL2_OUT__0_carry__0_n_7}),
        .S(MUL2_OUT__85_carry_i_8_1));
  CARRY4 MUL2_OUT__0_carry__1
       (.CI(MUL2_OUT__0_carry__0_n_0),
        .CO({NLW_MUL2_OUT__0_carry__1_CO_UNCONNECTED[3],MUL2_OUT__0_carry__1_n_1,NLW_MUL2_OUT__0_carry__1_CO_UNCONNECTED[1],MUL2_OUT__0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,MUL2_OUT__85_carry__0_i_3_0}),
        .O({NLW_MUL2_OUT__0_carry__1_O_UNCONNECTED[3:2],MUL2_OUT__0_carry__1_n_6,MUL2_OUT__0_carry__1_n_7}),
        .S({1'b0,1'b1,MUL2_OUT__85_carry__0_i_3_1}));
  CARRY4 MUL2_OUT__30_carry
       (.CI(1'b0),
        .CO({MUL2_OUT__30_carry_n_0,MUL2_OUT__30_carry_n_1,MUL2_OUT__30_carry_n_2,MUL2_OUT__30_carry_n_3}),
        .CYINIT(1'b0),
        .DI({\REG2_reg[3]_0 ,1'b0}),
        .O({MUL2_OUT__30_carry_n_4,MUL2_OUT__30_carry_n_5,MUL2_OUT__30_carry_n_6,MUL2_OUT__30_carry_n_7}),
        .S(\REG2_reg[3]_1 ));
  CARRY4 MUL2_OUT__30_carry__0
       (.CI(MUL2_OUT__30_carry_n_0),
        .CO({MUL2_OUT__30_carry__0_n_0,MUL2_OUT__30_carry__0_n_1,MUL2_OUT__30_carry__0_n_2,MUL2_OUT__30_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(MUL2_OUT__85_carry__0_i_4_0),
        .O({MUL2_OUT__30_carry__0_n_4,MUL2_OUT__30_carry__0_n_5,MUL2_OUT__30_carry__0_n_6,MUL2_OUT__30_carry__0_n_7}),
        .S(MUL2_OUT__85_carry__0_i_4_1));
  CARRY4 MUL2_OUT__30_carry__1
       (.CI(MUL2_OUT__30_carry__0_n_0),
        .CO({NLW_MUL2_OUT__30_carry__1_CO_UNCONNECTED[3],\ramb_bl.ramb36_sin_bl.ram36_bl_1 ,NLW_MUL2_OUT__30_carry__1_CO_UNCONNECTED[1],MUL2_OUT__30_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,MUL2_OUT__85_carry__1_i_5}),
        .O({NLW_MUL2_OUT__30_carry__1_O_UNCONNECTED[3:2],\ramb_bl.ramb36_sin_bl.ram36_bl_2 }),
        .S({1'b0,1'b1,MUL2_OUT__85_carry__1_i_5_0}));
  CARRY4 MUL2_OUT__59_carry
       (.CI(1'b0),
        .CO({MUL2_OUT__59_carry_n_0,MUL2_OUT__59_carry_n_1,MUL2_OUT__59_carry_n_2,MUL2_OUT__59_carry_n_3}),
        .CYINIT(1'b0),
        .DI({MUL2_OUT__85_carry_i_1_0,1'b0}),
        .O({MUL2_OUT__59_carry_n_4,MUL2_OUT__59_carry_n_5,MUL2_OUT__59_carry_n_6,MUL2_OUT__59_carry_n_7}),
        .S(MUL2_OUT__85_carry_i_1_1));
  CARRY4 MUL2_OUT__59_carry__0
       (.CI(MUL2_OUT__59_carry_n_0),
        .CO({MUL2_OUT__59_carry__0_n_0,MUL2_OUT__59_carry__0_n_1,MUL2_OUT__59_carry__0_n_2,MUL2_OUT__59_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(MUL2_OUT__85_carry__0_i_6_0),
        .O({\ramb_bl.ramb36_sin_bl.ram36_bl_3 ,MUL2_OUT__59_carry__0_n_7}),
        .S(MUL2_OUT__85_carry__0_i_6_1));
  CARRY4 MUL2_OUT__59_carry__1
       (.CI(MUL2_OUT__59_carry__0_n_0),
        .CO({NLW_MUL2_OUT__59_carry__1_CO_UNCONNECTED[3:1],MUL2_OUT__59_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\REG2_reg[15]_0 }),
        .O({NLW_MUL2_OUT__59_carry__1_O_UNCONNECTED[3:2],MUL2_OUT__59_carry__1_n_6,\ramb_bl.ramb36_sin_bl.ram36_bl_4 }),
        .S({1'b0,1'b0,1'b1,\REG2_reg[15]_1 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 MUL2_OUT__85_carry
       (.CI(1'b0),
        .CO({MUL2_OUT__85_carry_n_0,MUL2_OUT__85_carry_n_1,MUL2_OUT__85_carry_n_2,MUL2_OUT__85_carry_n_3}),
        .CYINIT(1'b0),
        .DI({MUL2_OUT__85_carry_i_1_n_0,MUL2_OUT__85_carry_i_2_n_0,MUL2_OUT__85_carry_i_3_n_0,MUL2_OUT__85_carry_i_4_n_0}),
        .O(MUL2_OUT[7:4]),
        .S({MUL2_OUT__85_carry_i_5_n_0,MUL2_OUT__85_carry_i_6_n_0,MUL2_OUT__85_carry_i_7_n_0,MUL2_OUT__85_carry_i_8_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 MUL2_OUT__85_carry__0
       (.CI(MUL2_OUT__85_carry_n_0),
        .CO({MUL2_OUT__85_carry__0_n_0,MUL2_OUT__85_carry__0_n_1,MUL2_OUT__85_carry__0_n_2,MUL2_OUT__85_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({MUL2_OUT__85_carry__0_i_1_n_0,MUL2_OUT__85_carry__0_i_2_n_0,MUL2_OUT__85_carry__0_i_3_n_0,MUL2_OUT__85_carry__0_i_4_n_0}),
        .O(MUL2_OUT[11:8]),
        .S({MUL2_OUT__85_carry__0_i_5_n_0,MUL2_OUT__85_carry__0_i_6_n_0,MUL2_OUT__85_carry__0_i_7_n_0,MUL2_OUT__85_carry__0_i_8_n_0}));
  LUT3 #(
    .INIT(8'hE8)) 
    MUL2_OUT__85_carry__0_i_1
       (.I0(MUL2_OUT__59_carry__0_n_7),
        .I1(MUL2_OUT__30_carry__0_n_4),
        .I2(MUL2_OUT__0_carry__1_n_1),
        .O(MUL2_OUT__85_carry__0_i_1_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL2_OUT__85_carry__0_i_2
       (.I0(MUL2_OUT__59_carry_n_4),
        .I1(MUL2_OUT__30_carry__0_n_5),
        .I2(MUL2_OUT__0_carry__1_n_6),
        .O(MUL2_OUT__85_carry__0_i_2_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL2_OUT__85_carry__0_i_3
       (.I0(MUL2_OUT__59_carry_n_5),
        .I1(MUL2_OUT__30_carry__0_n_6),
        .I2(MUL2_OUT__0_carry__1_n_7),
        .O(MUL2_OUT__85_carry__0_i_3_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL2_OUT__85_carry__0_i_4
       (.I0(MUL2_OUT__59_carry_n_6),
        .I1(MUL2_OUT__30_carry__0_n_7),
        .I2(MUL2_OUT__0_carry__0_n_4),
        .O(MUL2_OUT__85_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hE81717E8)) 
    MUL2_OUT__85_carry__0_i_5
       (.I0(MUL2_OUT__0_carry__1_n_1),
        .I1(MUL2_OUT__30_carry__0_n_4),
        .I2(MUL2_OUT__59_carry__0_n_7),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_3 [0]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_2 [0]),
        .O(MUL2_OUT__85_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    MUL2_OUT__85_carry__0_i_6
       (.I0(MUL2_OUT__85_carry__0_i_2_n_0),
        .I1(MUL2_OUT__30_carry__0_n_4),
        .I2(MUL2_OUT__59_carry__0_n_7),
        .I3(MUL2_OUT__0_carry__1_n_1),
        .O(MUL2_OUT__85_carry__0_i_6_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL2_OUT__85_carry__0_i_7
       (.I0(MUL2_OUT__59_carry_n_4),
        .I1(MUL2_OUT__30_carry__0_n_5),
        .I2(MUL2_OUT__0_carry__1_n_6),
        .I3(MUL2_OUT__85_carry__0_i_3_n_0),
        .O(MUL2_OUT__85_carry__0_i_7_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL2_OUT__85_carry__0_i_8
       (.I0(MUL2_OUT__59_carry_n_5),
        .I1(MUL2_OUT__30_carry__0_n_6),
        .I2(MUL2_OUT__0_carry__1_n_7),
        .I3(MUL2_OUT__85_carry__0_i_4_n_0),
        .O(MUL2_OUT__85_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 MUL2_OUT__85_carry__1
       (.CI(MUL2_OUT__85_carry__0_n_0),
        .CO({NLW_MUL2_OUT__85_carry__1_CO_UNCONNECTED[3],MUL2_OUT__85_carry__1_n_1,MUL2_OUT__85_carry__1_n_2,MUL2_OUT__85_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,\ramb_bl.ramb36_sin_bl.ram36_bl_4 ,\REG2_reg[15]_2 }),
        .O(MUL2_OUT[15:12]),
        .S({MUL2_OUT__59_carry__1_n_6,\REG2_reg[15]_3 }));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    MUL2_OUT__85_carry_i_1
       (.I0(MUL2_OUT__59_carry_n_7),
        .I1(MUL2_OUT__30_carry_n_4),
        .I2(MUL2_OUT__0_carry__0_n_5),
        .O(MUL2_OUT__85_carry_i_1_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    MUL2_OUT__85_carry_i_2
       (.I0(MUL2_OUT__30_carry_n_5),
        .I1(MUL2_OUT__0_carry__0_n_6),
        .O(MUL2_OUT__85_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    MUL2_OUT__85_carry_i_3
       (.I0(MUL2_OUT__0_carry__0_n_7),
        .I1(MUL2_OUT__30_carry_n_6),
        .O(MUL2_OUT__85_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    MUL2_OUT__85_carry_i_4
       (.I0(MUL2_OUT__0_carry_n_4),
        .I1(MUL2_OUT__30_carry_n_7),
        .O(MUL2_OUT__85_carry_i_4_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL2_OUT__85_carry_i_5
       (.I0(MUL2_OUT__59_carry_n_6),
        .I1(MUL2_OUT__30_carry__0_n_7),
        .I2(MUL2_OUT__0_carry__0_n_4),
        .I3(MUL2_OUT__85_carry_i_1_n_0),
        .O(MUL2_OUT__85_carry_i_5_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    MUL2_OUT__85_carry_i_6
       (.I0(MUL2_OUT__59_carry_n_7),
        .I1(MUL2_OUT__30_carry_n_4),
        .I2(MUL2_OUT__0_carry__0_n_5),
        .I3(MUL2_OUT__85_carry_i_2_n_0),
        .O(MUL2_OUT__85_carry_i_6_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h9666)) 
    MUL2_OUT__85_carry_i_7
       (.I0(MUL2_OUT__30_carry_n_5),
        .I1(MUL2_OUT__0_carry__0_n_6),
        .I2(MUL2_OUT__0_carry__0_n_7),
        .I3(MUL2_OUT__30_carry_n_6),
        .O(MUL2_OUT__85_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h8778)) 
    MUL2_OUT__85_carry_i_8
       (.I0(MUL2_OUT__0_carry_n_4),
        .I1(MUL2_OUT__30_carry_n_7),
        .I2(MUL2_OUT__30_carry_n_6),
        .I3(MUL2_OUT__0_carry__0_n_7),
        .O(MUL2_OUT__85_carry_i_8_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    \REG1[3]_i_1 
       (.I0(MUL1_OUT__0_carry_n_4),
        .I1(MUL1_OUT__30_carry_n_7),
        .O(MUL1_OUT[3]));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[0] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[0]),
        .Q(REG1[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[10] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[10]),
        .Q(REG1[10]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[11] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[11]),
        .Q(REG1[11]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[12] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[12]),
        .Q(REG1[12]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[13] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[13]),
        .Q(REG1[13]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[14] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[14]),
        .Q(REG1[14]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[15] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[15]),
        .Q(REG1[15]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[1] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[1]),
        .Q(REG1[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[2] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[2]),
        .Q(REG1[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[3] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[3]),
        .Q(REG1[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[4] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[4]),
        .Q(REG1[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[5] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[5]),
        .Q(REG1[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[6] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[6]),
        .Q(REG1[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[7] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[7]),
        .Q(REG1[7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[8] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[8]),
        .Q(REG1[8]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG1_reg[9] 
       (.C(CLK),
        .CE(E),
        .D(MUL1_OUT[9]),
        .Q(REG1[9]),
        .R(SR));
  LUT2 #(
    .INIT(4'h6)) 
    \REG2[3]_i_1 
       (.I0(MUL2_OUT__0_carry_n_4),
        .I1(MUL2_OUT__30_carry_n_7),
        .O(MUL2_OUT[3]));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[0] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[0]),
        .Q(REG2[0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[10] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[10]),
        .Q(REG2[10]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[11] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[11]),
        .Q(REG2[11]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[12] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[12]),
        .Q(REG2[12]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[13] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[13]),
        .Q(REG2[13]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[14] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[14]),
        .Q(REG2[14]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[15] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[15]),
        .Q(REG2[15]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[1] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[1]),
        .Q(REG2[1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[2] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[2]),
        .Q(REG2[2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[3] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[3]),
        .Q(REG2[3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[4] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[4]),
        .Q(REG2[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[5] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[5]),
        .Q(REG2[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[6] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[6]),
        .Q(REG2[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[7] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[7]),
        .Q(REG2[7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[8] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[8]),
        .Q(REG2[8]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG2_reg[9] 
       (.C(CLK),
        .CE(E),
        .D(MUL2_OUT[9]),
        .Q(REG2[9]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[0] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[0]),
        .Q(\REG_ACCUM_reg_n_0_[0] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[10] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[10]),
        .Q(\REG_ACCUM_reg_n_0_[10] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[11] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[11]),
        .Q(\REG_ACCUM_reg_n_0_[11] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[12] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[12]),
        .Q(\REG_ACCUM_reg_n_0_[12] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[13] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[13]),
        .Q(\REG_ACCUM_reg_n_0_[13] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[14] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[14]),
        .Q(\REG_ACCUM_reg_n_0_[14] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[15] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[15]),
        .Q(\REG_ACCUM_reg_n_0_[15] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[16] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[16]),
        .Q(\REG_ACCUM_reg_n_0_[16] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[17] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[17]),
        .Q(\REG_ACCUM_reg_n_0_[17] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[18] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[18]),
        .Q(\REG_ACCUM_reg_n_0_[18] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[19] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[19]),
        .Q(\REG_ACCUM_reg_n_0_[19] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[1] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[1]),
        .Q(\REG_ACCUM_reg_n_0_[1] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[20] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[20]),
        .Q(\REG_ACCUM_reg_n_0_[20] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[21] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[21]),
        .Q(\REG_ACCUM_reg_n_0_[21] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[2] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[2]),
        .Q(\REG_ACCUM_reg_n_0_[2] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[3] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[3]),
        .Q(\REG_ACCUM_reg_n_0_[3] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[4] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[4]),
        .Q(\REG_ACCUM_reg_n_0_[4] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[5] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[5]),
        .Q(\REG_ACCUM_reg_n_0_[5] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[6] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[6]),
        .Q(\REG_ACCUM_reg_n_0_[6] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[7] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[7]),
        .Q(\REG_ACCUM_reg_n_0_[7] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[8] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[8]),
        .Q(\REG_ACCUM_reg_n_0_[8] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \REG_ACCUM_reg[9] 
       (.C(CLK),
        .CE(\REG_ACCUM_reg[21]_1 ),
        .D(ADD_OUT[9]),
        .Q(\REG_ACCUM_reg_n_0_[9] ),
        .R(\REG_ACCUM_reg[21]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__0_i_1
       (.I0(\REG_ACCUM_reg_n_0_[7] ),
        .I1(PCIN[7]),
        .O(i__carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__0_i_2
       (.I0(\REG_ACCUM_reg_n_0_[6] ),
        .I1(PCIN[6]),
        .O(i__carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__0_i_3
       (.I0(\REG_ACCUM_reg_n_0_[5] ),
        .I1(PCIN[5]),
        .O(i__carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__0_i_4
       (.I0(\REG_ACCUM_reg_n_0_[4] ),
        .I1(PCIN[4]),
        .O(i__carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__1_i_1
       (.I0(\REG_ACCUM_reg_n_0_[11] ),
        .I1(PCIN[11]),
        .O(i__carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__1_i_2
       (.I0(\REG_ACCUM_reg_n_0_[10] ),
        .I1(PCIN[10]),
        .O(i__carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__1_i_3
       (.I0(\REG_ACCUM_reg_n_0_[9] ),
        .I1(PCIN[9]),
        .O(i__carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__1_i_4
       (.I0(\REG_ACCUM_reg_n_0_[8] ),
        .I1(PCIN[8]),
        .O(i__carry__1_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__2_i_1
       (.I0(\REG_ACCUM_reg_n_0_[15] ),
        .I1(PCIN[15]),
        .O(i__carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__2_i_2
       (.I0(\REG_ACCUM_reg_n_0_[14] ),
        .I1(PCIN[14]),
        .O(i__carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__2_i_3
       (.I0(\REG_ACCUM_reg_n_0_[13] ),
        .I1(PCIN[13]),
        .O(i__carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry__2_i_4
       (.I0(\REG_ACCUM_reg_n_0_[12] ),
        .I1(PCIN[12]),
        .O(i__carry__2_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__3_i_1
       (.I0(\REG_ACCUM_reg_n_0_[19] ),
        .I1(i__carry__3_i_5_n_3),
        .O(i__carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__3_i_2
       (.I0(\REG_ACCUM_reg_n_0_[18] ),
        .I1(i__carry__3_i_5_n_3),
        .O(i__carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__3_i_3
       (.I0(\REG_ACCUM_reg_n_0_[17] ),
        .I1(i__carry__3_i_5_n_3),
        .O(i__carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__3_i_4
       (.I0(\REG_ACCUM_reg_n_0_[16] ),
        .I1(i__carry__3_i_5_n_3),
        .O(i__carry__3_i_4_n_0));
  CARRY4 i__carry__3_i_5
       (.CI(ADD_OUT_carry__2_n_0),
        .CO({NLW_i__carry__3_i_5_CO_UNCONNECTED[3:1],i__carry__3_i_5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_i__carry__3_i_5_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__4_i_1
       (.I0(\REG_ACCUM_reg_n_0_[21] ),
        .I1(i__carry__3_i_5_n_3),
        .O(i__carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry__4_i_2
       (.I0(\REG_ACCUM_reg_n_0_[20] ),
        .I1(i__carry__3_i_5_n_3),
        .O(i__carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_1
       (.I0(\REG_ACCUM_reg_n_0_[3] ),
        .I1(PCIN[3]),
        .O(i__carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_2
       (.I0(\REG_ACCUM_reg_n_0_[2] ),
        .I1(PCIN[2]),
        .O(i__carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_3
       (.I0(\REG_ACCUM_reg_n_0_[1] ),
        .I1(PCIN[1]),
        .O(i__carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i__carry_i_4
       (.I0(\REG_ACCUM_reg_n_0_[0] ),
        .I1(PCIN[0]),
        .O(i__carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_1 
       (.I0(\REG_ACCUM_reg_n_0_[20] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[20]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_10 
       (.I0(\REG_ACCUM_reg_n_0_[11] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[11]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_11 
       (.I0(\REG_ACCUM_reg_n_0_[10] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[10]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_12 
       (.I0(\REG_ACCUM_reg_n_0_[9] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[9]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_13 
       (.I0(\REG_ACCUM_reg_n_0_[8] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[8]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_14 
       (.I0(\REG_ACCUM_reg_n_0_[7] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[7]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_15 
       (.I0(\REG_ACCUM_reg_n_0_[6] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[6]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_16 
       (.I0(\REG_ACCUM_reg_n_0_[5] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[5]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_17 
       (.I0(\REG_ACCUM_reg_n_0_[4] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[4]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_18 
       (.I0(\REG_ACCUM_reg_n_0_[3] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[3]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_19 
       (.I0(\REG_ACCUM_reg_n_0_[2] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[2]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_2 
       (.I0(\REG_ACCUM_reg_n_0_[19] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[19]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_20 
       (.I0(\REG_ACCUM_reg_n_0_[1] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[1]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_21 
       (.I0(\REG_ACCUM_reg_n_0_[0] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[0]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_3 
       (.I0(\REG_ACCUM_reg_n_0_[18] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[18]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_4 
       (.I0(\REG_ACCUM_reg_n_0_[17] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[17]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_5 
       (.I0(\REG_ACCUM_reg_n_0_[16] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[16]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_6 
       (.I0(\REG_ACCUM_reg_n_0_[15] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[15]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_7 
       (.I0(\REG_ACCUM_reg_n_0_[14] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[14]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_8 
       (.I0(\REG_ACCUM_reg_n_0_[13] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[13]));
  LUT2 #(
    .INIT(4'h2)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl_i_9 
       (.I0(\REG_ACCUM_reg_n_0_[12] ),
        .I1(\REG_ACCUM_reg_n_0_[21] ),
        .O(DIADI[12]));
endmodule

module unimacro_BRAM_SINGLE_MACRO
   (DOADO,
    DI,
    \ramb_bl.ramb36_sin_bl.ram36_bl_0 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_1 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_2 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_3 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_4 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_5 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_6 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_7 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_8 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_9 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_10 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_11 ,
    MUL1_OUT__59_carry__0,
    \ramb_bl.ramb36_sin_bl.ram36_bl_12 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_13 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_14 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_15 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_16 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_17 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_18 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_19 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_20 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_21 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_22 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_23 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_24 ,
    MUL2_OUT__59_carry__0,
    B,
    \ramb_bl.ramb36_sin_bl.ram36_bl_25 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_26 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_27 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_28 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_29 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_30 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_31 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_32 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_33 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_34 ,
    MUL1_OUT__59_carry__1,
    MUL2_OUT__59_carry__1,
    CLK,
    Q,
    input_select,
    \REG2_reg[2] ,
    A,
    O,
    \REG1_reg[15] ,
    \REG2_reg[2]_0 ,
    \REG2_reg[2]_1 ,
    \REG2_reg[2]_2 ,
    MUL2_OUT__0_carry__0,
    MUL2_OUT__0_carry__0_0,
    MUL2_OUT__0_carry__0_1,
    MUL2_OUT__0_carry__0_2,
    \REG2_reg[15] ,
    \REG2_reg[15]_0 ,
    MUL1_OUT__0_carry__0,
    MUL1_OUT__30_carry__0,
    MUL2_OUT__0_carry__0_3,
    MUL2_OUT__30_carry__0,
    CO,
    \REG1_reg[15]_0 ,
    \REG2_reg[15]_1 ,
    \REG2_reg[15]_2 );
  output [31:0]DOADO;
  output [1:0]DI;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_9 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  output [1:0]MUL1_OUT__59_carry__0;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  output [1:0]MUL2_OUT__59_carry__0;
  output [1:0]B;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_28 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_29 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_30 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_31 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_32 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_33 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_34 ;
  output [2:0]MUL1_OUT__59_carry__1;
  output [2:0]MUL2_OUT__59_carry__1;
  input CLK;
  input [3:0]Q;
  input input_select;
  input [3:0]\REG2_reg[2] ;
  input [6:0]A;
  input [1:0]O;
  input [2:0]\REG1_reg[15] ;
  input \REG2_reg[2]_0 ;
  input \REG2_reg[2]_1 ;
  input \REG2_reg[2]_2 ;
  input MUL2_OUT__0_carry__0;
  input MUL2_OUT__0_carry__0_0;
  input MUL2_OUT__0_carry__0_1;
  input MUL2_OUT__0_carry__0_2;
  input [1:0]\REG2_reg[15] ;
  input [2:0]\REG2_reg[15]_0 ;
  input MUL1_OUT__0_carry__0;
  input MUL1_OUT__30_carry__0;
  input MUL2_OUT__0_carry__0_3;
  input MUL2_OUT__30_carry__0;
  input [0:0]CO;
  input [0:0]\REG1_reg[15]_0 ;
  input [0:0]\REG2_reg[15]_1 ;
  input [0:0]\REG2_reg[15]_2 ;

  wire [6:0]A;
  wire [1:0]B;
  wire CLK;
  wire [0:0]CO;
  wire [1:0]DI;
  wire [31:0]DOADO;
  wire MUL1_OUT__0_carry__0;
  wire MUL1_OUT__30_carry__0;
  wire [1:0]MUL1_OUT__59_carry__0;
  wire [2:0]MUL1_OUT__59_carry__1;
  wire MUL2_OUT__0_carry__0;
  wire MUL2_OUT__0_carry__0_0;
  wire MUL2_OUT__0_carry__0_1;
  wire MUL2_OUT__0_carry__0_2;
  wire MUL2_OUT__0_carry__0_3;
  wire MUL2_OUT__30_carry__0;
  wire [1:0]MUL2_OUT__59_carry__0;
  wire [2:0]MUL2_OUT__59_carry__1;
  wire [1:0]O;
  wire [3:0]Q;
  wire [2:0]\REG1_reg[15] ;
  wire [0:0]\REG1_reg[15]_0 ;
  wire [1:0]\REG2_reg[15] ;
  wire [2:0]\REG2_reg[15]_0 ;
  wire [0:0]\REG2_reg[15]_1 ;
  wire [0:0]\REG2_reg[15]_2 ;
  wire [3:0]\REG2_reg[2] ;
  wire \REG2_reg[2]_0 ;
  wire \REG2_reg[2]_1 ;
  wire \REG2_reg[2]_2 ;
  wire input_select;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_28 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_29 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_30 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_31 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_32 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_33 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_34 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_9 ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED ;

  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__0_carry__0_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I1(A[3]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I3(A[4]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I5(A[5]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_0 [3]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__0_carry__0_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I1(A[2]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I3(A[3]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I5(A[4]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_0 [2]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__0_carry__0_i_3
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I1(A[1]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I3(A[2]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I5(A[3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_0 [1]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__0_carry__0_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I1(A[0]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I3(A[1]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I5(A[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_0 [0]));
  LUT6 #(
    .INIT(64'h6A95956A956A956A)) 
    MUL1_OUT__0_carry__0_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_0 [3]),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I2(A[5]),
        .I3(MUL1_OUT__0_carry__0),
        .I4(A[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_27 ));
  LUT6 #(
    .INIT(64'h8000F888F888F888)) 
    MUL1_OUT__0_carry__1_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I1(A[4]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I3(A[5]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I5(A[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_4 ));
  LUT6 #(
    .INIT(64'h02A2FFFF5555FFFF)) 
    MUL1_OUT__0_carry__1_i_3
       (.I0(A[5]),
        .I1(DOADO[1]),
        .I2(input_select),
        .I3(DOADO[17]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I5(A[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_28 [1]));
  LUT6 #(
    .INIT(64'h2450F30F4BFFC3FF)) 
    MUL1_OUT__0_carry__1_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I1(A[4]),
        .I2(A[5]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I4(A[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_28 [0]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL1_OUT__0_carry_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ),
        .I1(A[1]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ),
        .I3(A[0]),
        .I4(A[2]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .O(DI[1]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_10
       (.I0(DOADO[18]),
        .I1(input_select),
        .I2(DOADO[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_13
       (.I0(DOADO[16]),
        .I1(input_select),
        .I2(DOADO[0]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ));
  LUT5 #(
    .INIT(32'hB8308800)) 
    MUL1_OUT__0_carry_i_3
       (.I0(DOADO[16]),
        .I1(input_select),
        .I2(DOADO[0]),
        .I3(\REG2_reg[2] [2]),
        .I4(\REG2_reg[2] [0]),
        .O(DI[0]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_8
       (.I0(DOADO[17]),
        .I1(input_select),
        .I2(DOADO[1]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__30_carry__0_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I1(A[3]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I3(A[4]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .I5(A[5]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_6 [3]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__30_carry__0_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I1(A[2]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I3(A[3]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .I5(A[4]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_6 [2]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__30_carry__0_i_3
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I1(A[1]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I3(A[2]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .I5(A[3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_6 [1]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL1_OUT__30_carry__0_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I1(A[0]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I3(A[1]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .I5(A[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_6 [0]));
  LUT6 #(
    .INIT(64'h6A95956A956A956A)) 
    MUL1_OUT__30_carry__0_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_6 [3]),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I2(A[5]),
        .I3(MUL1_OUT__30_carry__0),
        .I4(A[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_29 ));
  LUT6 #(
    .INIT(64'h8000F888F888F888)) 
    MUL1_OUT__30_carry__1_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I1(A[4]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I3(A[5]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .I5(A[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ));
  LUT6 #(
    .INIT(64'h02A2FFFF5555FFFF)) 
    MUL1_OUT__30_carry__1_i_3
       (.I0(A[5]),
        .I1(DOADO[4]),
        .I2(input_select),
        .I3(DOADO[20]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I5(A[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_30 [1]));
  LUT6 #(
    .INIT(64'h2450F30F4BFFC3FF)) 
    MUL1_OUT__30_carry__1_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .I1(A[4]),
        .I2(A[5]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I4(A[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_30 [0]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL1_OUT__30_carry_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I1(A[1]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ),
        .I3(A[0]),
        .I4(A[2]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_5 [1]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__30_carry_i_10
       (.I0(DOADO[19]),
        .I1(input_select),
        .I2(DOADO[3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_9 ));
  LUT5 #(
    .INIT(32'hB8308800)) 
    MUL1_OUT__30_carry_i_3
       (.I0(DOADO[19]),
        .I1(input_select),
        .I2(DOADO[3]),
        .I3(\REG2_reg[2] [2]),
        .I4(\REG2_reg[2] [0]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_5 [0]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__30_carry_i_8
       (.I0(DOADO[20]),
        .I1(input_select),
        .I2(DOADO[4]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__30_carry_i_9
       (.I0(DOADO[21]),
        .I1(input_select),
        .I2(DOADO[5]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ));
  LUT5 #(
    .INIT(32'hB8308800)) 
    MUL1_OUT__59_carry_i_2
       (.I0(DOADO[23]),
        .I1(input_select),
        .I2(DOADO[7]),
        .I3(\REG2_reg[2] [2]),
        .I4(\REG2_reg[2] [0]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__59_carry_i_8
       (.I0(DOADO[23]),
        .I1(input_select),
        .I2(DOADO[7]),
        .O(B[1]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__59_carry_i_9
       (.I0(DOADO[22]),
        .I1(input_select),
        .I2(DOADO[6]),
        .O(B[0]));
  LUT2 #(
    .INIT(4'h8)) 
    MUL1_OUT__85_carry__1_i_1
       (.I0(O[1]),
        .I1(\REG1_reg[15] [1]),
        .O(MUL1_OUT__59_carry__0[1]));
  LUT2 #(
    .INIT(4'h8)) 
    MUL1_OUT__85_carry__1_i_2
       (.I0(O[0]),
        .I1(\REG1_reg[15] [0]),
        .O(MUL1_OUT__59_carry__0[0]));
  LUT3 #(
    .INIT(8'h78)) 
    MUL1_OUT__85_carry__1_i_3
       (.I0(CO),
        .I1(\REG1_reg[15] [2]),
        .I2(\REG1_reg[15]_0 ),
        .O(MUL1_OUT__59_carry__1[2]));
  LUT4 #(
    .INIT(16'h8778)) 
    MUL1_OUT__85_carry__1_i_4
       (.I0(O[1]),
        .I1(\REG1_reg[15] [1]),
        .I2(\REG1_reg[15] [2]),
        .I3(CO),
        .O(MUL1_OUT__59_carry__1[1]));
  LUT4 #(
    .INIT(16'h8778)) 
    MUL1_OUT__85_carry__1_i_5
       (.I0(O[0]),
        .I1(\REG1_reg[15] [0]),
        .I2(\REG1_reg[15] [1]),
        .I3(O[1]),
        .O(MUL1_OUT__59_carry__1[0]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__0_carry__0_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I1(MUL2_OUT__0_carry__0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I3(MUL2_OUT__0_carry__0_0),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I5(MUL2_OUT__0_carry__0_1),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_13 [3]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__0_carry__0_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I1(\REG2_reg[2]_2 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I3(MUL2_OUT__0_carry__0),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I5(MUL2_OUT__0_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_13 [2]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__0_carry__0_i_3
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I1(\REG2_reg[2]_1 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I3(\REG2_reg[2]_2 ),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I5(MUL2_OUT__0_carry__0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_13 [1]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__0_carry__0_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I1(\REG2_reg[2]_0 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I3(\REG2_reg[2]_1 ),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I5(\REG2_reg[2]_2 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_13 [0]));
  LUT6 #(
    .INIT(64'h6A95956A956A956A)) 
    MUL2_OUT__0_carry__0_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_13 [3]),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I2(MUL2_OUT__0_carry__0_1),
        .I3(MUL2_OUT__0_carry__0_3),
        .I4(MUL2_OUT__0_carry__0_2),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_31 ));
  LUT6 #(
    .INIT(64'h8000F888F888F888)) 
    MUL2_OUT__0_carry__1_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I1(MUL2_OUT__0_carry__0_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I3(MUL2_OUT__0_carry__0_1),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I5(MUL2_OUT__0_carry__0_2),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ));
  LUT6 #(
    .INIT(64'h02A2FFFF5555FFFF)) 
    MUL2_OUT__0_carry__1_i_3
       (.I0(MUL2_OUT__0_carry__0_1),
        .I1(DOADO[25]),
        .I2(input_select),
        .I3(DOADO[9]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I5(MUL2_OUT__0_carry__0_2),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_32 [1]));
  LUT6 #(
    .INIT(64'h2450F30F4BFFC3FF)) 
    MUL2_OUT__0_carry__1_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I1(MUL2_OUT__0_carry__0_0),
        .I2(MUL2_OUT__0_carry__0_1),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I4(MUL2_OUT__0_carry__0_2),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_32 [0]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL2_OUT__0_carry_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I1(\REG2_reg[2]_1 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I3(\REG2_reg[2]_0 ),
        .I4(\REG2_reg[2]_2 ),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_12 [1]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_10
       (.I0(DOADO[10]),
        .I1(input_select),
        .I2(DOADO[26]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_13
       (.I0(DOADO[8]),
        .I1(input_select),
        .I2(DOADO[24]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ));
  LUT5 #(
    .INIT(32'hB8308800)) 
    MUL2_OUT__0_carry_i_3
       (.I0(DOADO[8]),
        .I1(input_select),
        .I2(DOADO[24]),
        .I3(\REG2_reg[2] [1]),
        .I4(\REG2_reg[2] [3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_12 [0]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_8
       (.I0(DOADO[9]),
        .I1(input_select),
        .I2(DOADO[25]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__30_carry__0_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I1(MUL2_OUT__0_carry__0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I3(MUL2_OUT__0_carry__0_0),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .I5(MUL2_OUT__0_carry__0_1),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_19 [3]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__30_carry__0_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I1(\REG2_reg[2]_2 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I3(MUL2_OUT__0_carry__0),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .I5(MUL2_OUT__0_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_19 [2]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__30_carry__0_i_3
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I1(\REG2_reg[2]_1 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I3(\REG2_reg[2]_2 ),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .I5(MUL2_OUT__0_carry__0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_19 [1]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    MUL2_OUT__30_carry__0_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I1(\REG2_reg[2]_0 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I3(\REG2_reg[2]_1 ),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .I5(\REG2_reg[2]_2 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_19 [0]));
  LUT6 #(
    .INIT(64'h6A95956A956A956A)) 
    MUL2_OUT__30_carry__0_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_19 [3]),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I2(MUL2_OUT__0_carry__0_1),
        .I3(MUL2_OUT__30_carry__0),
        .I4(MUL2_OUT__0_carry__0_2),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_33 ));
  LUT6 #(
    .INIT(64'h8000F888F888F888)) 
    MUL2_OUT__30_carry__1_i_2
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I1(MUL2_OUT__0_carry__0_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I3(MUL2_OUT__0_carry__0_1),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .I5(MUL2_OUT__0_carry__0_2),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_23 ));
  LUT6 #(
    .INIT(64'h02A2FFFF5555FFFF)) 
    MUL2_OUT__30_carry__1_i_3
       (.I0(MUL2_OUT__0_carry__0_1),
        .I1(DOADO[28]),
        .I2(input_select),
        .I3(DOADO[12]),
        .I4(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I5(MUL2_OUT__0_carry__0_2),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_34 [1]));
  LUT6 #(
    .INIT(64'h2450F30F4BFFC3FF)) 
    MUL2_OUT__30_carry__1_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .I1(MUL2_OUT__0_carry__0_0),
        .I2(MUL2_OUT__0_carry__0_1),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I4(MUL2_OUT__0_carry__0_2),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_34 [0]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL2_OUT__30_carry_i_1
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I1(\REG2_reg[2]_1 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I3(\REG2_reg[2]_0 ),
        .I4(\REG2_reg[2]_2 ),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_18 [1]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__30_carry_i_10
       (.I0(DOADO[11]),
        .I1(input_select),
        .I2(DOADO[27]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ));
  LUT5 #(
    .INIT(32'hB8308800)) 
    MUL2_OUT__30_carry_i_3
       (.I0(DOADO[11]),
        .I1(input_select),
        .I2(DOADO[27]),
        .I3(\REG2_reg[2] [1]),
        .I4(\REG2_reg[2] [3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_18 [0]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__30_carry_i_8
       (.I0(DOADO[12]),
        .I1(input_select),
        .I2(DOADO[28]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__30_carry_i_9
       (.I0(DOADO[13]),
        .I1(input_select),
        .I2(DOADO[29]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ));
  LUT5 #(
    .INIT(32'hB8308800)) 
    MUL2_OUT__59_carry_i_2
       (.I0(DOADO[15]),
        .I1(input_select),
        .I2(DOADO[31]),
        .I3(\REG2_reg[2] [1]),
        .I4(\REG2_reg[2] [3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_24 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__59_carry_i_8
       (.I0(DOADO[15]),
        .I1(input_select),
        .I2(DOADO[31]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_26 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__59_carry_i_9
       (.I0(DOADO[14]),
        .I1(input_select),
        .I2(DOADO[30]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_25 ));
  LUT2 #(
    .INIT(4'h8)) 
    MUL2_OUT__85_carry__1_i_1
       (.I0(\REG2_reg[15] [1]),
        .I1(\REG2_reg[15]_0 [1]),
        .O(MUL2_OUT__59_carry__0[1]));
  LUT2 #(
    .INIT(4'h8)) 
    MUL2_OUT__85_carry__1_i_2
       (.I0(\REG2_reg[15] [0]),
        .I1(\REG2_reg[15]_0 [0]),
        .O(MUL2_OUT__59_carry__0[0]));
  LUT3 #(
    .INIT(8'h78)) 
    MUL2_OUT__85_carry__1_i_3
       (.I0(\REG2_reg[15]_1 ),
        .I1(\REG2_reg[15]_0 [2]),
        .I2(\REG2_reg[15]_2 ),
        .O(MUL2_OUT__59_carry__1[2]));
  LUT4 #(
    .INIT(16'h8778)) 
    MUL2_OUT__85_carry__1_i_4
       (.I0(\REG2_reg[15] [1]),
        .I1(\REG2_reg[15]_0 [1]),
        .I2(\REG2_reg[15]_0 [2]),
        .I3(\REG2_reg[15]_1 ),
        .O(MUL2_OUT__59_carry__1[1]));
  LUT4 #(
    .INIT(16'h8778)) 
    MUL2_OUT__85_carry__1_i_5
       (.I0(\REG2_reg[15] [0]),
        .I1(\REG2_reg[15]_0 [0]),
        .I2(\REG2_reg[15]_0 [1]),
        .I3(\REG2_reg[15] [1]),
        .O(MUL2_OUT__59_carry__1[0]));
  (* box_type = "PRIMITIVE" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'hB4ED1248FC7BFA4C14D47CF1CFE204C727CE5E04FFF7E53F90D0744017C65E26),
    .INIT_01(256'hB3A3C707E664261B03C17919F3BCBC458D7860040B51584F3248FD50F32BB8B2),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .INIT_FILE("NONE"),
    .IS_CLKARDCLK_INVERTED(1'b0),
    .IS_CLKBWRCLK_INVERTED(1'b0),
    .IS_ENARDEN_INVERTED(1'b0),
    .IS_ENBWREN_INVERTED(1'b0),
    .IS_RSTRAMARSTRAM_INVERTED(1'b0),
    .IS_RSTRAMB_INVERTED(1'b0),
    .IS_RSTREGARSTREG_INVERTED(1'b0),
    .IS_RSTREGB_INVERTED(1'b0),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("PERFORMANCE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("NONE"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(36),
    .WRITE_WIDTH_B(0)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl 
       (.ADDRARDADDR({1'b1,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,Q,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .CASCADEINA(1'b0),
        .CASCADEINB(1'b0),
        .CASCADEOUTA(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(CLK),
        .CLKBWRCLK(1'b0),
        .DBITERR(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(DOADO),
        .DOBDO(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED [31:0]),
        .DOPADOP(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(1'b1),
        .ENBWREN(1'b0),
        .INJECTDBITERR(1'b0),
        .INJECTSBITERR(1'b0),
        .RDADDRECC(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED ),
        .WEA({1'b0,1'b0,1'b0,1'b0}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
endmodule

(* ORIG_REF_NAME = "unimacro_BRAM_SINGLE_MACRO" *) 
module unimacro_BRAM_SINGLE_MACRO__parameterized0
   (DOADO,
    \ramb_bl.ramb36_sin_bl.ram36_bl_0 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_1 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_2 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_3 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_4 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_5 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_6 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_7 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_8 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_9 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_10 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_11 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_12 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_13 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_14 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_15 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_16 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_17 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_18 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_19 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_20 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_21 ,
    DI,
    \ramb_bl.ramb36_sin_bl.ram36_bl_22 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_23 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_24 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_25 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_26 ,
    S,
    \ramb_bl.ramb36_sin_bl.ram36_bl_27 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_28 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_29 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_30 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_31 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_32 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_33 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_34 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_35 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_36 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_37 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_38 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_39 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_40 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_41 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_42 ,
    \ramb_bl.ramb36_sin_bl.ram36_bl_43 ,
    CLK,
    out,
    MUL2_OUT__59_carry,
    input_select,
    B,
    MUL2_OUT__59_carry__0,
    MUL2_OUT__59_carry__0_0,
    \REG2_reg[2] ,
    \REG2_reg[2]_0 ,
    MUL2_OUT__30_carry,
    MUL2_OUT__30_carry_0,
    \REG2_reg[2]_1 ,
    MUL2_OUT__30_carry_1);
  output [3:0]DOADO;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  output [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_9 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  output \ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  output [0:0]DI;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  output [3:0]S;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_28 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_29 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_30 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_31 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_32 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_33 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_34 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_35 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_36 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_37 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_38 ;
  output [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_39 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_40 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_41 ;
  output [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_42 ;
  output [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_43 ;
  input CLK;
  input [7:0]out;
  input [31:0]MUL2_OUT__59_carry;
  input input_select;
  input [7:0]B;
  input MUL2_OUT__59_carry__0;
  input MUL2_OUT__59_carry__0_0;
  input \REG2_reg[2] ;
  input \REG2_reg[2]_0 ;
  input MUL2_OUT__30_carry;
  input MUL2_OUT__30_carry_0;
  input \REG2_reg[2]_1 ;
  input MUL2_OUT__30_carry_1;

  wire [0:0]A;
  wire [7:0]A0;
  wire [7:0]A1;
  wire [7:0]A2;
  wire [7:0]A3;
  wire [7:0]B;
  wire CLK;
  wire [0:0]DI;
  wire [3:0]DOADO;
  wire MUL1_OUT__0_carry__0_i_14_n_0;
  wire MUL1_OUT__0_carry__0_i_15_n_0;
  wire MUL1_OUT__0_carry__0_i_16_n_0;
  wire MUL1_OUT__0_carry__0_i_17_n_0;
  wire MUL1_OUT__0_carry__0_i_18_n_0;
  wire MUL1_OUT__0_carry__0_i_19_n_0;
  wire MUL1_OUT__0_carry__0_i_20_n_0;
  wire MUL1_OUT__0_carry__0_i_21_n_0;
  wire MUL1_OUT__0_carry__0_i_22_n_0;
  wire MUL1_OUT__0_carry__0_i_23_n_0;
  wire MUL1_OUT__0_carry__0_i_24_n_0;
  wire MUL1_OUT__0_carry_i_15_n_0;
  wire MUL1_OUT__30_carry__0_i_10_n_0;
  wire MUL1_OUT__30_carry__0_i_11_n_0;
  wire MUL1_OUT__30_carry__0_i_12_n_0;
  wire MUL1_OUT__30_carry__0_i_13_n_0;
  wire MUL1_OUT__30_carry__0_i_14_n_0;
  wire MUL1_OUT__30_carry__0_i_15_n_0;
  wire MUL1_OUT__30_carry__0_i_16_n_0;
  wire MUL1_OUT__30_carry__0_i_17_n_0;
  wire MUL1_OUT__30_carry__0_i_18_n_0;
  wire MUL1_OUT__30_carry__0_i_19_n_0;
  wire MUL1_OUT__30_carry__0_i_20_n_0;
  wire MUL1_OUT__30_carry_i_11_n_0;
  wire MUL2_OUT__0_carry__0_i_14_n_0;
  wire MUL2_OUT__0_carry__0_i_15_n_0;
  wire MUL2_OUT__0_carry__0_i_16_n_0;
  wire MUL2_OUT__0_carry__0_i_17_n_0;
  wire MUL2_OUT__0_carry__0_i_18_n_0;
  wire MUL2_OUT__0_carry__0_i_19_n_0;
  wire MUL2_OUT__0_carry__0_i_20_n_0;
  wire MUL2_OUT__0_carry__0_i_21_n_0;
  wire MUL2_OUT__0_carry__0_i_22_n_0;
  wire MUL2_OUT__0_carry__0_i_23_n_0;
  wire MUL2_OUT__0_carry__0_i_24_n_0;
  wire MUL2_OUT__0_carry_i_14_n_0;
  wire MUL2_OUT__0_carry_i_15_n_0;
  wire MUL2_OUT__30_carry;
  wire MUL2_OUT__30_carry_0;
  wire MUL2_OUT__30_carry_1;
  wire MUL2_OUT__30_carry__0_i_10_n_0;
  wire MUL2_OUT__30_carry__0_i_11_n_0;
  wire MUL2_OUT__30_carry__0_i_12_n_0;
  wire MUL2_OUT__30_carry__0_i_13_n_0;
  wire MUL2_OUT__30_carry__0_i_14_n_0;
  wire MUL2_OUT__30_carry__0_i_15_n_0;
  wire MUL2_OUT__30_carry__0_i_16_n_0;
  wire MUL2_OUT__30_carry__0_i_17_n_0;
  wire MUL2_OUT__30_carry__0_i_18_n_0;
  wire MUL2_OUT__30_carry__0_i_19_n_0;
  wire MUL2_OUT__30_carry__0_i_20_n_0;
  wire MUL2_OUT__30_carry_i_11_n_0;
  wire [31:0]MUL2_OUT__59_carry;
  wire MUL2_OUT__59_carry__0;
  wire MUL2_OUT__59_carry__0_0;
  wire \REG2_reg[2] ;
  wire \REG2_reg[2]_0 ;
  wire \REG2_reg[2]_1 ;
  wire [3:0]S;
  wire input_select;
  wire [7:0]out;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_0 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_1 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_10 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_11 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_12 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_13 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_14 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_15 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_16 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_17 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_18 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_19 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_2 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_20 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_21 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_22 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_23 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_24 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_25 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_26 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_27 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_28 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_29 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_3 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_30 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_31 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_32 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_33 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_34 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_35 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_36 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_37 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_38 ;
  wire [2:0]\ramb_bl.ramb36_sin_bl.ram36_bl_39 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_4 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_40 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_41 ;
  wire [3:0]\ramb_bl.ramb36_sin_bl.ram36_bl_42 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_43 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_5 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_6 ;
  wire [0:0]\ramb_bl.ramb36_sin_bl.ram36_bl_7 ;
  wire \ramb_bl.ramb36_sin_bl.ram36_bl_8 ;
  wire [1:0]\ramb_bl.ramb36_sin_bl.ram36_bl_9 ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED ;

  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry__0_i_10
       (.I0(A2[5]),
        .I1(input_select),
        .I2(A0[5]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry__0_i_11
       (.I0(A2[6]),
        .I1(input_select),
        .I2(A0[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_12
       (.I0(A0[5]),
        .I1(A2[5]),
        .I2(MUL2_OUT__59_carry[2]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[18]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry__0_i_13
       (.I0(A2[7]),
        .I1(input_select),
        .I2(A0[7]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_14
       (.I0(A0[5]),
        .I1(A2[5]),
        .I2(MUL2_OUT__59_carry[0]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[16]),
        .O(MUL1_OUT__0_carry__0_i_14_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_15
       (.I0(A0[4]),
        .I1(A2[4]),
        .I2(MUL2_OUT__59_carry[1]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[17]),
        .O(MUL1_OUT__0_carry__0_i_15_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_16
       (.I0(A0[3]),
        .I1(A2[3]),
        .I2(MUL2_OUT__59_carry[2]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[18]),
        .O(MUL1_OUT__0_carry__0_i_16_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_17
       (.I0(A0[5]),
        .I1(A2[5]),
        .I2(MUL2_OUT__59_carry[1]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[17]),
        .O(MUL1_OUT__0_carry__0_i_17_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_18
       (.I0(A0[4]),
        .I1(A2[4]),
        .I2(MUL2_OUT__59_carry[2]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[18]),
        .O(MUL1_OUT__0_carry__0_i_18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_19
       (.I0(A0[6]),
        .I1(A2[6]),
        .I2(MUL2_OUT__59_carry[0]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[16]),
        .O(MUL1_OUT__0_carry__0_i_19_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_20
       (.I0(A0[4]),
        .I1(A2[4]),
        .I2(MUL2_OUT__59_carry[0]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[16]),
        .O(MUL1_OUT__0_carry__0_i_20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_21
       (.I0(A0[3]),
        .I1(A2[3]),
        .I2(MUL2_OUT__59_carry[1]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[17]),
        .O(MUL1_OUT__0_carry__0_i_21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_22
       (.I0(A0[2]),
        .I1(A2[2]),
        .I2(MUL2_OUT__59_carry[2]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[18]),
        .O(MUL1_OUT__0_carry__0_i_22_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_23
       (.I0(A0[2]),
        .I1(A2[2]),
        .I2(MUL2_OUT__59_carry[1]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[17]),
        .O(MUL1_OUT__0_carry__0_i_23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry__0_i_24
       (.I0(DOADO[0]),
        .I1(DOADO[2]),
        .I2(MUL2_OUT__59_carry[2]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[18]),
        .O(MUL1_OUT__0_carry__0_i_24_n_0));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL1_OUT__0_carry__0_i_6
       (.I0(MUL1_OUT__0_carry__0_i_14_n_0),
        .I1(MUL1_OUT__0_carry__0_i_15_n_0),
        .I2(MUL1_OUT__0_carry__0_i_16_n_0),
        .I3(MUL1_OUT__0_carry__0_i_17_n_0),
        .I4(MUL1_OUT__0_carry__0_i_18_n_0),
        .I5(MUL1_OUT__0_carry__0_i_19_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_30 [2]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL1_OUT__0_carry__0_i_7
       (.I0(MUL1_OUT__0_carry__0_i_20_n_0),
        .I1(MUL1_OUT__0_carry__0_i_21_n_0),
        .I2(MUL1_OUT__0_carry__0_i_22_n_0),
        .I3(MUL1_OUT__0_carry__0_i_15_n_0),
        .I4(MUL1_OUT__0_carry__0_i_16_n_0),
        .I5(MUL1_OUT__0_carry__0_i_14_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_30 [1]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL1_OUT__0_carry__0_i_8
       (.I0(MUL1_OUT__0_carry_i_15_n_0),
        .I1(MUL1_OUT__0_carry__0_i_23_n_0),
        .I2(MUL1_OUT__0_carry__0_i_24_n_0),
        .I3(MUL1_OUT__0_carry__0_i_21_n_0),
        .I4(MUL1_OUT__0_carry__0_i_22_n_0),
        .I5(MUL1_OUT__0_carry__0_i_20_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_30 [0]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry__0_i_9
       (.I0(A2[4]),
        .I1(input_select),
        .I2(A0[4]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_13 ));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL1_OUT__0_carry__1_i_1
       (.I0(B[1]),
        .I1(A2[7]),
        .I2(input_select),
        .I3(A0[7]),
        .I4(B[2]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_31 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_11
       (.I0(DOADO[2]),
        .I1(input_select),
        .I2(DOADO[0]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_12
       (.I0(A2[3]),
        .I1(input_select),
        .I2(A0[3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_12 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_14
       (.I0(A2[0]),
        .I1(input_select),
        .I2(A0[0]),
        .O(A));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__0_carry_i_15
       (.I0(A0[3]),
        .I1(A2[3]),
        .I2(MUL2_OUT__59_carry[0]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[16]),
        .O(MUL1_OUT__0_carry_i_15_n_0));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL1_OUT__0_carry_i_2
       (.I0(B[1]),
        .I1(DOADO[2]),
        .I2(input_select),
        .I3(DOADO[0]),
        .I4(B[2]),
        .I5(A),
        .O(DI));
  LUT6 #(
    .INIT(64'h99C369C399339933)) 
    MUL1_OUT__0_carry_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .I1(MUL1_OUT__0_carry_i_15_n_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .I3(B[1]),
        .I4(A),
        .I5(B[2]),
        .O(S[3]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL1_OUT__0_carry_i_5
       (.I0(A),
        .I1(B[2]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .I3(B[1]),
        .I4(B[0]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .O(S[2]));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL1_OUT__0_carry_i_6
       (.I0(B[0]),
        .I1(DOADO[2]),
        .I2(input_select),
        .I3(DOADO[0]),
        .I4(B[1]),
        .I5(A),
        .O(S[1]));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    MUL1_OUT__0_carry_i_7
       (.I0(A0[0]),
        .I1(A2[0]),
        .I2(MUL2_OUT__59_carry[0]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[16]),
        .O(S[0]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL1_OUT__0_carry_i_9
       (.I0(A2[2]),
        .I1(input_select),
        .I2(A0[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_10
       (.I0(A0[5]),
        .I1(A2[5]),
        .I2(MUL2_OUT__59_carry[3]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[19]),
        .O(MUL1_OUT__30_carry__0_i_10_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_11
       (.I0(A0[4]),
        .I1(A2[4]),
        .I2(MUL2_OUT__59_carry[4]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[20]),
        .O(MUL1_OUT__30_carry__0_i_11_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_12
       (.I0(A0[3]),
        .I1(A2[3]),
        .I2(MUL2_OUT__59_carry[5]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[21]),
        .O(MUL1_OUT__30_carry__0_i_12_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_13
       (.I0(A0[5]),
        .I1(A2[5]),
        .I2(MUL2_OUT__59_carry[4]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[20]),
        .O(MUL1_OUT__30_carry__0_i_13_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_14
       (.I0(A0[4]),
        .I1(A2[4]),
        .I2(MUL2_OUT__59_carry[5]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[21]),
        .O(MUL1_OUT__30_carry__0_i_14_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_15
       (.I0(A0[6]),
        .I1(A2[6]),
        .I2(MUL2_OUT__59_carry[3]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[19]),
        .O(MUL1_OUT__30_carry__0_i_15_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_16
       (.I0(A0[4]),
        .I1(A2[4]),
        .I2(MUL2_OUT__59_carry[3]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[19]),
        .O(MUL1_OUT__30_carry__0_i_16_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_17
       (.I0(A0[3]),
        .I1(A2[3]),
        .I2(MUL2_OUT__59_carry[4]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[20]),
        .O(MUL1_OUT__30_carry__0_i_17_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_18
       (.I0(A0[2]),
        .I1(A2[2]),
        .I2(MUL2_OUT__59_carry[5]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[21]),
        .O(MUL1_OUT__30_carry__0_i_18_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_19
       (.I0(A0[2]),
        .I1(A2[2]),
        .I2(MUL2_OUT__59_carry[4]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[20]),
        .O(MUL1_OUT__30_carry__0_i_19_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_20
       (.I0(DOADO[0]),
        .I1(DOADO[2]),
        .I2(MUL2_OUT__59_carry[5]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[21]),
        .O(MUL1_OUT__30_carry__0_i_20_n_0));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL1_OUT__30_carry__0_i_6
       (.I0(MUL1_OUT__30_carry__0_i_10_n_0),
        .I1(MUL1_OUT__30_carry__0_i_11_n_0),
        .I2(MUL1_OUT__30_carry__0_i_12_n_0),
        .I3(MUL1_OUT__30_carry__0_i_13_n_0),
        .I4(MUL1_OUT__30_carry__0_i_14_n_0),
        .I5(MUL1_OUT__30_carry__0_i_15_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_32 [2]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL1_OUT__30_carry__0_i_7
       (.I0(MUL1_OUT__30_carry__0_i_16_n_0),
        .I1(MUL1_OUT__30_carry__0_i_17_n_0),
        .I2(MUL1_OUT__30_carry__0_i_18_n_0),
        .I3(MUL1_OUT__30_carry__0_i_11_n_0),
        .I4(MUL1_OUT__30_carry__0_i_12_n_0),
        .I5(MUL1_OUT__30_carry__0_i_10_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_32 [1]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL1_OUT__30_carry__0_i_8
       (.I0(MUL1_OUT__30_carry_i_11_n_0),
        .I1(MUL1_OUT__30_carry__0_i_19_n_0),
        .I2(MUL1_OUT__30_carry__0_i_20_n_0),
        .I3(MUL1_OUT__30_carry__0_i_17_n_0),
        .I4(MUL1_OUT__30_carry__0_i_18_n_0),
        .I5(MUL1_OUT__30_carry__0_i_16_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_32 [0]));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry__0_i_9
       (.I0(A0[5]),
        .I1(A2[5]),
        .I2(MUL2_OUT__59_carry[5]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[21]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_1 ));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL1_OUT__30_carry__1_i_1
       (.I0(B[4]),
        .I1(A2[7]),
        .I2(input_select),
        .I3(A0[7]),
        .I4(B[5]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_33 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__30_carry_i_11
       (.I0(A0[3]),
        .I1(A2[3]),
        .I2(MUL2_OUT__59_carry[3]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[19]),
        .O(MUL1_OUT__30_carry_i_11_n_0));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL1_OUT__30_carry_i_2
       (.I0(B[4]),
        .I1(DOADO[2]),
        .I2(input_select),
        .I3(DOADO[0]),
        .I4(B[5]),
        .I5(A),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_22 ));
  LUT6 #(
    .INIT(64'h99C369C399339933)) 
    MUL1_OUT__30_carry_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .I1(MUL1_OUT__30_carry_i_11_n_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .I3(B[4]),
        .I4(A),
        .I5(B[5]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_27 [3]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL1_OUT__30_carry_i_5
       (.I0(A),
        .I1(B[5]),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .I3(B[4]),
        .I4(B[3]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_27 [2]));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL1_OUT__30_carry_i_6
       (.I0(B[3]),
        .I1(DOADO[2]),
        .I2(input_select),
        .I3(DOADO[0]),
        .I4(B[4]),
        .I5(A),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_27 [1]));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    MUL1_OUT__30_carry_i_7
       (.I0(A0[0]),
        .I1(A2[0]),
        .I2(MUL2_OUT__59_carry[3]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[19]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_27 [0]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL1_OUT__59_carry__0_i_1
       (.I0(B[7]),
        .I1(A2[5]),
        .I2(input_select),
        .I3(A0[5]),
        .I4(B[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_35 [3]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL1_OUT__59_carry__0_i_2
       (.I0(B[7]),
        .I1(A2[4]),
        .I2(input_select),
        .I3(A0[4]),
        .I4(B[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_35 [2]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL1_OUT__59_carry__0_i_3
       (.I0(B[7]),
        .I1(A2[3]),
        .I2(input_select),
        .I3(A0[3]),
        .I4(B[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_13 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_35 [1]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL1_OUT__59_carry__0_i_4
       (.I0(B[7]),
        .I1(A2[2]),
        .I2(input_select),
        .I3(A0[2]),
        .I4(B[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_12 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_35 [0]));
  LUT5 #(
    .INIT(32'h738CC0C0)) 
    MUL1_OUT__59_carry__0_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I2(B[7]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .I4(B[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_23 [3]));
  LUT5 #(
    .INIT(32'h8C733F3F)) 
    MUL1_OUT__59_carry__0_i_6
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_13 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I2(B[7]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_15 ),
        .I4(B[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_23 [2]));
  LUT5 #(
    .INIT(32'h8C733F3F)) 
    MUL1_OUT__59_carry__0_i_7
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_12 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_13 ),
        .I2(B[7]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_14 ),
        .I4(B[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_23 [1]));
  LUT5 #(
    .INIT(32'h8C733F3F)) 
    MUL1_OUT__59_carry__0_i_8
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_12 ),
        .I2(B[7]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_13 ),
        .I4(B[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_23 [0]));
  LUT6 #(
    .INIT(64'h0000757F757F757F)) 
    MUL1_OUT__59_carry__1_i_1
       (.I0(B[7]),
        .I1(A2[6]),
        .I2(input_select),
        .I3(A0[6]),
        .I4(B[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_2 ));
  LUT6 #(
    .INIT(64'hFEAE555503F3FFFF)) 
    MUL1_OUT__59_carry__1_i_2
       (.I0(B[6]),
        .I1(A0[6]),
        .I2(input_select),
        .I3(A2[6]),
        .I4(B[7]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_3 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_36 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__59_carry_i_1
       (.I0(DOADO[0]),
        .I1(DOADO[2]),
        .I2(MUL2_OUT__59_carry[7]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[23]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_4 [1]));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL1_OUT__59_carry_i_3
       (.I0(A0[0]),
        .I1(A2[0]),
        .I2(MUL2_OUT__59_carry[7]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[23]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_4 [0]));
  LUT5 #(
    .INIT(32'h9F606060)) 
    MUL1_OUT__59_carry_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_11 ),
        .I2(B[7]),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_12 ),
        .I4(B[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_34 [3]));
  LUT6 #(
    .INIT(64'h9A955A5595955555)) 
    MUL1_OUT__59_carry_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_4 [1]),
        .I1(MUL2_OUT__59_carry[22]),
        .I2(input_select),
        .I3(MUL2_OUT__59_carry[6]),
        .I4(A2[2]),
        .I5(A0[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_34 [2]));
  LUT6 #(
    .INIT(64'h8A80757F757F757F)) 
    MUL1_OUT__59_carry_i_6
       (.I0(B[7]),
        .I1(A2[0]),
        .I2(input_select),
        .I3(A0[0]),
        .I4(B[6]),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_10 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_34 [1]));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    MUL1_OUT__59_carry_i_7
       (.I0(A0[0]),
        .I1(A2[0]),
        .I2(MUL2_OUT__59_carry[6]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[22]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_34 [0]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry__0_i_10
       (.I0(A1[5]),
        .I1(input_select),
        .I2(A3[5]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry__0_i_11
       (.I0(A1[6]),
        .I1(input_select),
        .I2(A3[6]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_12
       (.I0(A3[5]),
        .I1(A1[5]),
        .I2(MUL2_OUT__59_carry[26]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[10]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_5 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry__0_i_13
       (.I0(A1[7]),
        .I1(input_select),
        .I2(A3[7]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_14
       (.I0(A3[5]),
        .I1(A1[5]),
        .I2(MUL2_OUT__59_carry[24]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[8]),
        .O(MUL2_OUT__0_carry__0_i_14_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_15
       (.I0(A3[4]),
        .I1(A1[4]),
        .I2(MUL2_OUT__59_carry[25]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[9]),
        .O(MUL2_OUT__0_carry__0_i_15_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_16
       (.I0(A3[3]),
        .I1(A1[3]),
        .I2(MUL2_OUT__59_carry[26]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[10]),
        .O(MUL2_OUT__0_carry__0_i_16_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_17
       (.I0(A3[5]),
        .I1(A1[5]),
        .I2(MUL2_OUT__59_carry[25]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[9]),
        .O(MUL2_OUT__0_carry__0_i_17_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_18
       (.I0(A3[4]),
        .I1(A1[4]),
        .I2(MUL2_OUT__59_carry[26]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[10]),
        .O(MUL2_OUT__0_carry__0_i_18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_19
       (.I0(A3[6]),
        .I1(A1[6]),
        .I2(MUL2_OUT__59_carry[24]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[8]),
        .O(MUL2_OUT__0_carry__0_i_19_n_0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_20
       (.I0(A3[4]),
        .I1(A1[4]),
        .I2(MUL2_OUT__59_carry[24]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[8]),
        .O(MUL2_OUT__0_carry__0_i_20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_21
       (.I0(A3[3]),
        .I1(A1[3]),
        .I2(MUL2_OUT__59_carry[25]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[9]),
        .O(MUL2_OUT__0_carry__0_i_21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_22
       (.I0(A3[2]),
        .I1(A1[2]),
        .I2(MUL2_OUT__59_carry[26]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[10]),
        .O(MUL2_OUT__0_carry__0_i_22_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_23
       (.I0(A3[2]),
        .I1(A1[2]),
        .I2(MUL2_OUT__59_carry[25]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[9]),
        .O(MUL2_OUT__0_carry__0_i_23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry__0_i_24
       (.I0(DOADO[3]),
        .I1(DOADO[1]),
        .I2(MUL2_OUT__59_carry[26]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[10]),
        .O(MUL2_OUT__0_carry__0_i_24_n_0));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL2_OUT__0_carry__0_i_6
       (.I0(MUL2_OUT__0_carry__0_i_14_n_0),
        .I1(MUL2_OUT__0_carry__0_i_15_n_0),
        .I2(MUL2_OUT__0_carry__0_i_16_n_0),
        .I3(MUL2_OUT__0_carry__0_i_17_n_0),
        .I4(MUL2_OUT__0_carry__0_i_18_n_0),
        .I5(MUL2_OUT__0_carry__0_i_19_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_37 [2]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL2_OUT__0_carry__0_i_7
       (.I0(MUL2_OUT__0_carry__0_i_20_n_0),
        .I1(MUL2_OUT__0_carry__0_i_21_n_0),
        .I2(MUL2_OUT__0_carry__0_i_22_n_0),
        .I3(MUL2_OUT__0_carry__0_i_15_n_0),
        .I4(MUL2_OUT__0_carry__0_i_16_n_0),
        .I5(MUL2_OUT__0_carry__0_i_14_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_37 [1]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL2_OUT__0_carry__0_i_8
       (.I0(MUL2_OUT__0_carry_i_15_n_0),
        .I1(MUL2_OUT__0_carry__0_i_23_n_0),
        .I2(MUL2_OUT__0_carry__0_i_24_n_0),
        .I3(MUL2_OUT__0_carry__0_i_21_n_0),
        .I4(MUL2_OUT__0_carry__0_i_22_n_0),
        .I5(MUL2_OUT__0_carry__0_i_20_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_37 [0]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry__0_i_9
       (.I0(A1[4]),
        .I1(input_select),
        .I2(A3[4]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_19 ));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL2_OUT__0_carry__1_i_1
       (.I0(\REG2_reg[2] ),
        .I1(A1[7]),
        .I2(input_select),
        .I3(A3[7]),
        .I4(\REG2_reg[2]_0 ),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_38 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_11
       (.I0(DOADO[1]),
        .I1(input_select),
        .I2(DOADO[3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_12
       (.I0(A1[3]),
        .I1(input_select),
        .I2(A3[3]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_18 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_14
       (.I0(A1[0]),
        .I1(input_select),
        .I2(A3[0]),
        .O(MUL2_OUT__0_carry_i_14_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__0_carry_i_15
       (.I0(A3[3]),
        .I1(A1[3]),
        .I2(MUL2_OUT__59_carry[24]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[8]),
        .O(MUL2_OUT__0_carry_i_15_n_0));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL2_OUT__0_carry_i_2
       (.I0(\REG2_reg[2] ),
        .I1(DOADO[1]),
        .I2(input_select),
        .I3(DOADO[3]),
        .I4(\REG2_reg[2]_0 ),
        .I5(MUL2_OUT__0_carry_i_14_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_24 ));
  LUT6 #(
    .INIT(64'h99C369C399339933)) 
    MUL2_OUT__0_carry_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .I1(MUL2_OUT__0_carry_i_15_n_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I3(\REG2_reg[2] ),
        .I4(MUL2_OUT__0_carry_i_14_n_0),
        .I5(\REG2_reg[2]_0 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_28 [3]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL2_OUT__0_carry_i_5
       (.I0(MUL2_OUT__0_carry_i_14_n_0),
        .I1(\REG2_reg[2]_0 ),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I3(\REG2_reg[2] ),
        .I4(\REG2_reg[2]_1 ),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_28 [2]));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL2_OUT__0_carry_i_6
       (.I0(\REG2_reg[2]_1 ),
        .I1(DOADO[1]),
        .I2(input_select),
        .I3(DOADO[3]),
        .I4(\REG2_reg[2] ),
        .I5(MUL2_OUT__0_carry_i_14_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_28 [1]));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    MUL2_OUT__0_carry_i_7
       (.I0(A3[0]),
        .I1(A1[0]),
        .I2(MUL2_OUT__59_carry[24]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[8]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_28 [0]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    MUL2_OUT__0_carry_i_9
       (.I0(A1[2]),
        .I1(input_select),
        .I2(A3[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_10
       (.I0(A3[5]),
        .I1(A1[5]),
        .I2(MUL2_OUT__59_carry[27]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[11]),
        .O(MUL2_OUT__30_carry__0_i_10_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_11
       (.I0(A3[4]),
        .I1(A1[4]),
        .I2(MUL2_OUT__59_carry[28]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[12]),
        .O(MUL2_OUT__30_carry__0_i_11_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_12
       (.I0(A3[3]),
        .I1(A1[3]),
        .I2(MUL2_OUT__59_carry[29]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[13]),
        .O(MUL2_OUT__30_carry__0_i_12_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_13
       (.I0(A3[5]),
        .I1(A1[5]),
        .I2(MUL2_OUT__59_carry[28]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[12]),
        .O(MUL2_OUT__30_carry__0_i_13_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_14
       (.I0(A3[4]),
        .I1(A1[4]),
        .I2(MUL2_OUT__59_carry[29]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[13]),
        .O(MUL2_OUT__30_carry__0_i_14_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_15
       (.I0(A3[6]),
        .I1(A1[6]),
        .I2(MUL2_OUT__59_carry[27]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[11]),
        .O(MUL2_OUT__30_carry__0_i_15_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_16
       (.I0(A3[4]),
        .I1(A1[4]),
        .I2(MUL2_OUT__59_carry[27]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[11]),
        .O(MUL2_OUT__30_carry__0_i_16_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_17
       (.I0(A3[3]),
        .I1(A1[3]),
        .I2(MUL2_OUT__59_carry[28]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[12]),
        .O(MUL2_OUT__30_carry__0_i_17_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_18
       (.I0(A3[2]),
        .I1(A1[2]),
        .I2(MUL2_OUT__59_carry[29]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[13]),
        .O(MUL2_OUT__30_carry__0_i_18_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_19
       (.I0(A3[2]),
        .I1(A1[2]),
        .I2(MUL2_OUT__59_carry[28]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[12]),
        .O(MUL2_OUT__30_carry__0_i_19_n_0));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_20
       (.I0(DOADO[3]),
        .I1(DOADO[1]),
        .I2(MUL2_OUT__59_carry[29]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[13]),
        .O(MUL2_OUT__30_carry__0_i_20_n_0));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL2_OUT__30_carry__0_i_6
       (.I0(MUL2_OUT__30_carry__0_i_10_n_0),
        .I1(MUL2_OUT__30_carry__0_i_11_n_0),
        .I2(MUL2_OUT__30_carry__0_i_12_n_0),
        .I3(MUL2_OUT__30_carry__0_i_13_n_0),
        .I4(MUL2_OUT__30_carry__0_i_14_n_0),
        .I5(MUL2_OUT__30_carry__0_i_15_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_39 [2]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL2_OUT__30_carry__0_i_7
       (.I0(MUL2_OUT__30_carry__0_i_16_n_0),
        .I1(MUL2_OUT__30_carry__0_i_17_n_0),
        .I2(MUL2_OUT__30_carry__0_i_18_n_0),
        .I3(MUL2_OUT__30_carry__0_i_11_n_0),
        .I4(MUL2_OUT__30_carry__0_i_12_n_0),
        .I5(MUL2_OUT__30_carry__0_i_10_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_39 [1]));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    MUL2_OUT__30_carry__0_i_8
       (.I0(MUL2_OUT__30_carry_i_11_n_0),
        .I1(MUL2_OUT__30_carry__0_i_19_n_0),
        .I2(MUL2_OUT__30_carry__0_i_20_n_0),
        .I3(MUL2_OUT__30_carry__0_i_17_n_0),
        .I4(MUL2_OUT__30_carry__0_i_18_n_0),
        .I5(MUL2_OUT__30_carry__0_i_16_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_39 [0]));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry__0_i_9
       (.I0(A3[5]),
        .I1(A1[5]),
        .I2(MUL2_OUT__59_carry[29]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[13]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_6 ));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL2_OUT__30_carry__1_i_1
       (.I0(MUL2_OUT__30_carry),
        .I1(A1[7]),
        .I2(input_select),
        .I3(A3[7]),
        .I4(MUL2_OUT__30_carry_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_40 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__30_carry_i_11
       (.I0(A3[3]),
        .I1(A1[3]),
        .I2(MUL2_OUT__59_carry[27]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[11]),
        .O(MUL2_OUT__30_carry_i_11_n_0));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL2_OUT__30_carry_i_2
       (.I0(MUL2_OUT__30_carry),
        .I1(DOADO[1]),
        .I2(input_select),
        .I3(DOADO[3]),
        .I4(MUL2_OUT__30_carry_0),
        .I5(MUL2_OUT__0_carry_i_14_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_25 ));
  LUT6 #(
    .INIT(64'h99C369C399339933)) 
    MUL2_OUT__30_carry_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .I1(MUL2_OUT__30_carry_i_11_n_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I3(MUL2_OUT__30_carry),
        .I4(MUL2_OUT__0_carry_i_14_n_0),
        .I5(MUL2_OUT__30_carry_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_29 [3]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    MUL2_OUT__30_carry_i_5
       (.I0(MUL2_OUT__0_carry_i_14_n_0),
        .I1(MUL2_OUT__30_carry_0),
        .I2(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I3(MUL2_OUT__30_carry),
        .I4(MUL2_OUT__30_carry_1),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_29 [2]));
  LUT6 #(
    .INIT(64'h757F8A808A808A80)) 
    MUL2_OUT__30_carry_i_6
       (.I0(MUL2_OUT__30_carry_1),
        .I1(DOADO[1]),
        .I2(input_select),
        .I3(DOADO[3]),
        .I4(MUL2_OUT__30_carry),
        .I5(MUL2_OUT__0_carry_i_14_n_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_29 [1]));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    MUL2_OUT__30_carry_i_7
       (.I0(A3[0]),
        .I1(A1[0]),
        .I2(MUL2_OUT__59_carry[27]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[11]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_29 [0]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL2_OUT__59_carry__0_i_1
       (.I0(MUL2_OUT__59_carry__0),
        .I1(A1[5]),
        .I2(input_select),
        .I3(A3[5]),
        .I4(MUL2_OUT__59_carry__0_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_42 [3]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL2_OUT__59_carry__0_i_2
       (.I0(MUL2_OUT__59_carry__0),
        .I1(A1[4]),
        .I2(input_select),
        .I3(A3[4]),
        .I4(MUL2_OUT__59_carry__0_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_42 [2]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL2_OUT__59_carry__0_i_3
       (.I0(MUL2_OUT__59_carry__0),
        .I1(A1[3]),
        .I2(input_select),
        .I3(A3[3]),
        .I4(MUL2_OUT__59_carry__0_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_19 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_42 [1]));
  LUT6 #(
    .INIT(64'h757F000000000000)) 
    MUL2_OUT__59_carry__0_i_4
       (.I0(MUL2_OUT__59_carry__0),
        .I1(A1[2]),
        .I2(input_select),
        .I3(A3[2]),
        .I4(MUL2_OUT__59_carry__0_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_18 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_42 [0]));
  LUT5 #(
    .INIT(32'h738CC0C0)) 
    MUL2_OUT__59_carry__0_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I2(MUL2_OUT__59_carry__0),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .I4(MUL2_OUT__59_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_26 [3]));
  LUT5 #(
    .INIT(32'h8C733F3F)) 
    MUL2_OUT__59_carry__0_i_6
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_19 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I2(MUL2_OUT__59_carry__0),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_21 ),
        .I4(MUL2_OUT__59_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_26 [2]));
  LUT5 #(
    .INIT(32'h8C733F3F)) 
    MUL2_OUT__59_carry__0_i_7
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_18 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_19 ),
        .I2(MUL2_OUT__59_carry__0),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_20 ),
        .I4(MUL2_OUT__59_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_26 [1]));
  LUT5 #(
    .INIT(32'h8C733F3F)) 
    MUL2_OUT__59_carry__0_i_8
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_18 ),
        .I2(MUL2_OUT__59_carry__0),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_19 ),
        .I4(MUL2_OUT__59_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_26 [0]));
  LUT6 #(
    .INIT(64'h0000757F757F757F)) 
    MUL2_OUT__59_carry__1_i_1
       (.I0(MUL2_OUT__59_carry__0),
        .I1(A1[6]),
        .I2(input_select),
        .I3(A3[6]),
        .I4(MUL2_OUT__59_carry__0_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_7 ));
  LUT6 #(
    .INIT(64'hFEAE555503F3FFFF)) 
    MUL2_OUT__59_carry__1_i_2
       (.I0(MUL2_OUT__59_carry__0_0),
        .I1(A3[6]),
        .I2(input_select),
        .I3(A1[6]),
        .I4(MUL2_OUT__59_carry__0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_8 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_43 ));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__59_carry_i_1
       (.I0(DOADO[3]),
        .I1(DOADO[1]),
        .I2(MUL2_OUT__59_carry[31]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[15]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_9 [1]));
  LUT5 #(
    .INIT(32'h335FFF5F)) 
    MUL2_OUT__59_carry_i_3
       (.I0(A3[0]),
        .I1(A1[0]),
        .I2(MUL2_OUT__59_carry[31]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[15]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_9 [0]));
  LUT5 #(
    .INIT(32'h9F606060)) 
    MUL2_OUT__59_carry_i_4
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .I1(\ramb_bl.ramb36_sin_bl.ram36_bl_17 ),
        .I2(MUL2_OUT__59_carry__0),
        .I3(\ramb_bl.ramb36_sin_bl.ram36_bl_18 ),
        .I4(MUL2_OUT__59_carry__0_0),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_41 [3]));
  LUT6 #(
    .INIT(64'h9A955A5595955555)) 
    MUL2_OUT__59_carry_i_5
       (.I0(\ramb_bl.ramb36_sin_bl.ram36_bl_9 [1]),
        .I1(MUL2_OUT__59_carry[14]),
        .I2(input_select),
        .I3(MUL2_OUT__59_carry[30]),
        .I4(A1[2]),
        .I5(A3[2]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_41 [2]));
  LUT6 #(
    .INIT(64'h8A80757F757F757F)) 
    MUL2_OUT__59_carry_i_6
       (.I0(MUL2_OUT__59_carry__0),
        .I1(A1[0]),
        .I2(input_select),
        .I3(A3[0]),
        .I4(MUL2_OUT__59_carry__0_0),
        .I5(\ramb_bl.ramb36_sin_bl.ram36_bl_16 ),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_41 [1]));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    MUL2_OUT__59_carry_i_7
       (.I0(A3[0]),
        .I1(A1[0]),
        .I2(MUL2_OUT__59_carry[30]),
        .I3(input_select),
        .I4(MUL2_OUT__59_carry[14]),
        .O(\ramb_bl.ramb36_sin_bl.ram36_bl_41 [0]));
  (* box_type = "PRIMITIVE" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h38AD3D02FCFC000F0714EE3BD416B8CFE506B71715EB20D8543C15E9F6ACD4F7),
    .INIT_01(256'hF2B5B40E3422F84626B9EE2DEADCFF3A884F2D2231053B0B376643E8C1193DF6),
    .INIT_02(256'h13F84DE6FDEB5338DF07232132B952BE6AF3CA6A0B02BC0029A1EA51EE8C8A6A),
    .INIT_03(256'hAF3913CA28CCFFA895DEAA4EF55AE0447901F897533938D6B8D5260EA21F1A67),
    .INIT_04(256'hC4C4AB4CBC8EE79916960342F488E5FFD0FE065200C7703EF3D5B2353CE50A3D),
    .INIT_05(256'h1FFC926F242C0C50EDFB465158EF26343B9B2B18E4D11B2111A4D75841EC832B),
    .INIT_06(256'hF123EC36EE2852FE409DF91FD3BB371D3AB93E8BBAFFFE3811864AE60C281438),
    .INIT_07(256'hA5D7612B474BEFA29650FDF2E4D37A6FF6BF8789EE21CF3610E8482104D1DEA3),
    .INIT_08(256'h3C2308E64BF96E050C0C0AD878C955D4042FBDE18A8D2B40D1FD20FAB54B41F3),
    .INIT_09(256'hE502EC06187863A3EC8DF20002DBE8BCA33BC90318BCA1B00455450BE147B842),
    .INIT_0A(256'h2E27AD17D618006F24294702E12ECE3BA0542977D5FF08D22249BA9A2ADDD939),
    .INIT_0B(256'h12BC35FEBF05E2F6322106299F3038F91F47B739227906239F85C0F3D4D004C1),
    .INIT_0C(256'h00E9D01BB1072D0E10BC15A6EF0804082EFED2657DFC892303C11E5F4FCDFD52),
    .INIT_0D(256'h7A20E63046BAF713B43D51EC8E78FFA908B4674205F6F24E714D47ADB189FA41),
    .INIT_0E(256'h8F8347594214A15CDA7DF904DB7D1809039F56FBB10302536BEC91AE3E084F86),
    .INIT_0F(256'h105D2C1098E5CD7ED171D4D4CA9DB9F63A4B278C8567FAEDC78A316DD103E03B),
    .INIT_10(256'hCA1BC1773904C451FA1159FD4A20976F58D1F44651FA512E554E1533A7E01C55),
    .INIT_11(256'hFD2E64D9DC26F8766FABA8DA030B16B2C021E8F12FE98EFCA217B836DC0DFB9F),
    .INIT_12(256'hF238ECB15D4495049CE2C84F6971CE1F1655BD2AAD584B91F0B6D0509B2AB90B),
    .INIT_13(256'hBF9C06272C4FFEB0C0396DB02CE2AFFADD025A3BFAC322E14C1C98E2F12E0BBE),
    .INIT_14(256'hFA841A2AADB36E8AC3ACBF35A9233A5A570009E2651D9F3667C451E224399F04),
    .INIT_15(256'h150AAB9598DB27D379E32A322ACFA8B80A9A20F7CC38480283E357EAA8C2300A),
    .INIT_16(256'h1644091AFF2719ADF7330DDCFBEBD00308B22184F702E506D939483A8E6E4175),
    .INIT_17(256'hEC3DF6FCB692B6E85D30DFF02D923122E8C000833074E879230623CFCDE9E682),
    .INIT_18(256'hCF0131703204C14B8B04DA63FD07B80FBBA7F21D8DA8D909F52A297A00A80F5C),
    .INIT_19(256'h84FB4F12295B04EAFD0C99F9C3F87006D628C03AAD2D7B730C3CB6EE92D3AFC9),
    .INIT_1A(256'hEDF266301004E241AFEC84212C5559FA1CD3B5DDBE0CED0126D601AAA31DC1E9),
    .INIT_1B(256'hBB16F395F7B0C544AFF8BDE514F0FE326B4869AB4A264964D2DEFEF973351618),
    .INIT_1C(256'h30D86519D81219440D1AEF8211F34541E3C2F246BED6E6594EA570E1FBFFA99D),
    .INIT_1D(256'h4D9ED6E0D6DAD645DAA103DD125E05EAFB8BDACEA69E06C414F24614F71EC808),
    .INIT_1E(256'h661071DFE75D08FAA013C80416E66485F5F53A9E361C0316045B54004132780F),
    .INIT_1F(256'hA0EA084D3ABC00E129AED95EF3544CAB32B60420661DDFC36B79FE0E4D40FCF8),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .INIT_FILE("NONE"),
    .IS_CLKARDCLK_INVERTED(1'b0),
    .IS_CLKBWRCLK_INVERTED(1'b0),
    .IS_ENARDEN_INVERTED(1'b0),
    .IS_ENBWREN_INVERTED(1'b0),
    .IS_RSTRAMARSTRAM_INVERTED(1'b0),
    .IS_RSTRAMB_INVERTED(1'b0),
    .IS_RSTREGARSTREG_INVERTED(1'b0),
    .IS_RSTREGB_INVERTED(1'b0),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("PERFORMANCE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("NONE"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(36),
    .WRITE_WIDTH_B(0)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl 
       (.ADDRARDADDR({1'b1,1'b0,1'b0,out,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .CASCADEINA(1'b0),
        .CASCADEINB(1'b0),
        .CASCADEOUTA(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(CLK),
        .CLKBWRCLK(1'b0),
        .DBITERR(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO({A3[7:2],DOADO[3],A3[0],A2[7:2],DOADO[2],A2[0],A1[7:2],DOADO[1],A1[0],A0[7:2],DOADO[0],A0[0]}),
        .DOBDO(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED [31:0]),
        .DOPADOP(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(1'b1),
        .ENBWREN(1'b0),
        .INJECTDBITERR(1'b0),
        .INJECTSBITERR(1'b0),
        .RDADDRECC(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED ),
        .WEA({1'b0,1'b0,1'b0,1'b0}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
endmodule

(* ORIG_REF_NAME = "unimacro_BRAM_SINGLE_MACRO" *) 
module unimacro_BRAM_SINGLE_MACRO__parameterized1
   (DOADO,
    CLK,
    addr_omemc,
    DIADI,
    WEA);
  output [31:0]DOADO;
  input CLK;
  input [3:0]addr_omemc;
  input [20:0]DIADI;
  input [0:0]WEA;

  wire CLK;
  wire [20:0]DIADI;
  wire [31:0]DOADO;
  wire [0:0]WEA;
  wire [3:0]addr_omemc;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED ;
  wire \NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED ;

  (* box_type = "PRIMITIVE" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h000000000000000000000000000000000F0E0D0C0B0A09080706050403020100),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .INIT_FILE("NONE"),
    .IS_CLKARDCLK_INVERTED(1'b0),
    .IS_CLKBWRCLK_INVERTED(1'b0),
    .IS_ENARDEN_INVERTED(1'b0),
    .IS_ENBWREN_INVERTED(1'b0),
    .IS_RSTRAMARSTRAM_INVERTED(1'b0),
    .IS_RSTRAMB_INVERTED(1'b0),
    .IS_RSTREGARSTREG_INVERTED(1'b0),
    .IS_RSTREGB_INVERTED(1'b0),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("PERFORMANCE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("NONE"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(36),
    .WRITE_WIDTH_B(0)) 
    \ramb_bl.ramb36_sin_bl.ram36_bl 
       (.ADDRARDADDR({1'b1,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addr_omemc,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .CASCADEINA(1'b0),
        .CASCADEINB(1'b0),
        .CASCADEOUTA(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(CLK),
        .CLKBWRCLK(1'b0),
        .DBITERR(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,DIADI}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(DOADO),
        .DOBDO(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOBDO_UNCONNECTED [31:0]),
        .DOPADOP(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(1'b1),
        .ENBWREN(1'b0),
        .INJECTDBITERR(1'b0),
        .INJECTSBITERR(1'b0),
        .RDADDRECC(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_ramb_bl.ramb36_sin_bl.ram36_bl_SBITERR_UNCONNECTED ),
        .WEA({WEA,WEA,WEA,WEA}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
